package ix.app.health.ui

import ix.app.health.data.FastRecord
import ix.app.health.data.HOUR_MS
import ix.app.health.data.addDays
import ix.app.health.data.dayStart
import ix.app.health.data.weekStart

/** 0 = Flexi. 16 -> "16 : 8". 36 -> "36h". */
fun planLabel(goal: Int): String = when {
    goal <= 0 -> "Flexi"
    goal < 24 -> "$goal : ${24 - goal}"
    else -> "${goal}h"
}

/** Second line of a plan tile. */
fun planDetail(goal: Int): String = when {
    goal <= 0 -> "Fast as long as you want"
    goal < 24 -> "${goal}h fast · ${24 - goal}h eating"
    else -> "${goal}h fast"
}

val planGroups: List<Pair<String, List<Int>>> = listOf(
    "Beginner" to listOf(11, 12, 13, 14, 15),
    "Intermediate" to listOf(16, 17, 18, 19),
    "Advanced" to listOf(20, 21, 22, 23),
    "Long fasts" to listOf(24, 36, 42, 48, 72),
)

data class Stage(
    val hour: Int,
    val name: String,
    val short: String,
    val text: String,
    val feel: List<String>,
    val helps: List<String>,
)

/** A general, typical timeline. It differs from person to person. */
val fastingStages = listOf(
    Stage(
        0, "Digesting", "Fed",
        "Your body is processing your last meal and blood sugar is higher.",
        listOf("Full", "Energy from your meal"), listOf("Water", "Light walk"),
    ),
    Stage(
        4, "Sugar settling", "Sugar",
        "Insulin falls and blood sugar starts to come back down.",
        listOf("Calmer energy", "First hunger signals"), listOf("Water", "Tea or black coffee"),
    ),
    Stage(
        8, "Using stored sugar", "Stored",
        "Your body draws on stored glycogen for energy.",
        listOf("Hunger waves", "A small energy dip"), listOf("Water", "Pinch of salt", "Short walk"),
    ),
    Stage(
        12, "Switching to fat", "Fat",
        "Glycogen runs lower and fat burning picks up.",
        listOf("Hunger waves", "Steadier energy", "Cooler hands"),
        listOf("Water", "Pinch of salt", "Short walk"),
    ),
    Stage(
        16, "Ketones rising", "Ketones",
        "Your liver makes more ketones from fat.",
        listOf("Less hunger", "Clearer head", "Light-headed when standing"),
        listOf("Water and salts", "Stand up slowly", "Gentle movement"),
    ),
    Stage(
        24, "Deep fast", "Deep",
        "Ketones climb further. Cells step up routine cleanup (mostly shown in animal studies).",
        listOf("Low energy", "Feeling cold", "Headache"),
        listOf("Water and salts", "Rest", "Stop if you feel unwell"),
    ),
    Stage(
        48, "Extended fast", "Extended",
        "A long fast. Stay hydrated and listen to your body.",
        listOf("Tiredness", "Dizziness"),
        listOf("Water and salts", "Rest", "Talk to a doctor"),
    ),
)

fun stageIndexFor(elapsedMs: Long): Int {
    var idx = 0
    for (i in fastingStages.indices) {
        if (elapsedMs >= fastingStages[i].hour * HOUR_MS) idx = i
    }
    return idx
}

data class Streak(val days: Int, val graceLeft: Int)

/**
 * Days in a row (ending today or yesterday) with a fast that reached its goal.
 * One missed day per week is forgiven (a "grace day") and does not break the streak.
 */
fun streakInfo(fasts: List<FastRecord>, now: Long): Streak {
    val done = fasts.filter { it.completed }.map { dayStart(it.end) }.toSet()
    if (done.isEmpty()) return Streak(0, 1)
    val first = done.min()
    val today = dayStart(now)
    var d = if (today in done) today else addDays(today, -1)
    var n = 0
    val usedWeeks = HashSet<Long>()
    while (d >= first) {
        if (d in done) {
            n++
        } else if (!usedWeeks.add(weekStart(d))) {
            break
        }
        d = addDays(d, -1)
    }
    return Streak(n, if (weekStart(today) in usedWeeks) 0 else 1)
}

/** Days in a row with a fast that reached its goal, without grace days. */
fun fastStreak(fasts: List<FastRecord>, now: Long): Int {
    val done = fasts.filter { it.completed }.map { dayStart(it.end) }.toSet()
    val today = dayStart(now)
    var d = if (today in done) today else addDays(today, -1)
    var n = 0
    while (d in done) {
        n++
        d = addDays(d, -1)
    }
    return n
}
