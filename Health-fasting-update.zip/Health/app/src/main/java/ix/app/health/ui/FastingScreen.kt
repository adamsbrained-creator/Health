package ix.app.health.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ix.app.health.data.Repo
import ix.app.health.data.planGoalFor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Route { Main, Plans, Stages, Program }

@Composable
fun FastingScreen(repo: Repo) {
    var route by rememberSaveable { mutableStateOf(Route.Main) }
    var sub by rememberSaveable { mutableStateOf(0) }
    var logKind by remember { mutableStateOf<LogKind?>(null) }

    when (route) {
        Route.Main -> FastingMain(
            repo = repo,
            sub = sub,
            onSub = { sub = it },
            onPlans = { route = Route.Plans },
            onStages = { route = Route.Stages },
            onLog = { logKind = it },
        )
        Route.Plans -> {
            BackHandler { route = Route.Main }
            PlansScreen(repo, onBack = { route = Route.Main }, onProgram = { route = Route.Program })
        }
        Route.Stages -> {
            BackHandler { route = Route.Main }
            StagesScreen(repo) { route = Route.Main }
        }
        Route.Program -> {
            BackHandler { route = Route.Plans }
            ProgramScreen(repo) { route = Route.Plans }
        }
    }

    val k = logKind
    if (k != null) FastLogSheet(repo, k) { logKind = null }
}

@Composable
private fun FastingMain(
    repo: Repo,
    sub: Int,
    onSub: (Int) -> Unit,
    onPlans: () -> Unit,
    onStages: () -> Unit,
    onLog: (LogKind) -> Unit,
) {
    val start by repo.fastStart.collectAsState()
    val goalCur by repo.goalHours.collectAsState()
    val base by repo.baseGoal.collectAsState()
    val same by repo.samePlan.collectAsState()
    val plans by repo.plans.collectAsState()
    val program by repo.program.collectAsState()

    val now = System.currentTimeMillis()
    val goal = if (start > 0L) goalCur else planGoalFor(now, base, same, plans, program)
    val dateText = SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(Date(now))

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 24.dp).padding(top = 16.dp)) {
            ScreenHeader(dateText, "Fasting") {
                Box(Modifier.padding(top = 6.dp)) { PlanPill(planLabel(goal), onPlans) }
            }
            Spacer(Modifier.height(14.dp))
            Segmented(listOf("Timer", "Journal", "Insights"), sub, onSub)
            Spacer(Modifier.height(8.dp))
        }
        when (sub) {
            0 -> TimerTab(repo, onStages, onLog)
            1 -> HistoryScreen(repo, part = 1)
            else -> HistoryScreen(repo, part = 2)
        }
    }
}
