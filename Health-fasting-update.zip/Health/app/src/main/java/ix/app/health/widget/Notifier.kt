package ix.app.health.widget

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ix.app.health.MainActivity
import ix.app.health.R
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.ui.planLabel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The ongoing "Fasting" notification with a live timer, plus the alert when the goal is reached. */
object Notifier {
    private const val CHANNEL_RUNNING = "fasting_running"
    private const val CHANNEL_GOAL = "fasting_goal"
    private const val ID_RUNNING = 1
    private const val ID_GOAL = 2
    private const val ID_NUDGE = 3
    private const val CHANNEL_NUDGE = "fasting_nudge"
    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    /** Schedules the last-meal reminder and a planned fast start. */
    private fun scheduleExtras(app: Context, am: AlarmManager?) {
        try {
            val repo = Repo.get(app)
            val now = System.currentTimeMillis()
            val running = repo.fastStart.value > 0L

            val nudge = PendingIntent.getBroadcast(app, 23, Intent(app, NudgeReceiver::class.java), FLAGS)
            val lastEnd = repo.fasts.value.maxOfOrNull { it.end } ?: 0L
            val plan = repo.goalFor(now)
            var nudgeAt = 0L
            if (!running && repo.reminderOn.value && lastEnd > 0L && plan in 1..23) {
                nudgeAt = lastEnd + (24 - plan) * HOUR_MS - repo.reminderLead.value * 60_000L
            }
            if (nudgeAt > now) am?.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nudgeAt, nudge) else am?.cancel(nudge)

            val begin = PendingIntent.getBroadcast(app, 24, Intent(app, ScheduledStartReceiver::class.java), FLAGS)
            val at = repo.scheduledStart.value
            if (!running && at > now) am?.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, begin) else am?.cancel(begin)
        } catch (e: Exception) {
            // never crash because of a reminder
        }
    }

    fun postNudge(context: Context) {
        try {
            val app = context.applicationContext
            val repo = Repo.get(app)
            if (repo.fastStart.value > 0L || !repo.reminderOn.value) return
            val nm = app.getSystemService(NotificationManager::class.java) ?: return
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_NUDGE, "Last-meal reminder", NotificationManager.IMPORTANCE_DEFAULT)
            )
            val open = PendingIntent.getActivity(
                app, 25,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                FLAGS,
            )
            val lastEnd = repo.fasts.value.maxOfOrNull { it.end } ?: 0L
            val plan = repo.goalFor(System.currentTimeMillis())
            val startsAt = if (lastEnd > 0L && plan in 1..23) lastEnd + (24 - plan) * HOUR_MS else 0L
            val text = if (startsAt > 0L) {
                "Time to wrap up your last meal. Your fast starts at " +
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(startsAt)) + "."
            } else {
                "Time to wrap up your last meal."
            }
            val n = Notification.Builder(app, CHANNEL_NUDGE)
                .setSmallIcon(R.drawable.ic_fasting)
                .setContentTitle("Last-meal reminder")
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(ID_NUDGE, n)
        } catch (e: Exception) {
        }
    }

    fun update(context: Context) {
        try {
            scheduleExtras(context.applicationContext, context.applicationContext.getSystemService(AlarmManager::class.java))
        } catch (e: Exception) {
        }
        try {
            val app = context.applicationContext
            val nm = app.getSystemService(NotificationManager::class.java) ?: return
            val am = app.getSystemService(AlarmManager::class.java)
            val repo = Repo.get(app)
            val start = repo.fastStart.value
            val goal = repo.goalHours.value
            val alarm = PendingIntent.getBroadcast(app, 20, Intent(app, GoalReceiver::class.java), FLAGS)

            if (start <= 0L) {
                nm.cancel(ID_RUNNING)
                am?.cancel(alarm)
                return
            }

            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_RUNNING, "Fasting timer", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                app, 21,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                FLAGS,
            )
            val text = if (goal > 0) {
                "Goal at " + SimpleDateFormat("EEE HH:mm", Locale.getDefault()).format(Date(start + goal * HOUR_MS))
            } else {
                "No goal"
            }
            val n = Notification.Builder(app, CHANNEL_RUNNING)
                .setSmallIcon(R.drawable.ic_fasting)
                .setContentTitle("Fasting · " + planLabel(goal))
                .setContentText(text)
                .setUsesChronometer(true)
                .setShowWhen(true)
                .setWhen(start)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .build()
            nm.notify(ID_RUNNING, n)

            val at = start + goal * HOUR_MS
            if (goal > 0 && at > System.currentTimeMillis()) {
                am?.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarm)
            } else {
                am?.cancel(alarm)
            }
        } catch (e: Exception) {
            // notifications are a bonus, never crash because of them
        }
    }

    fun postGoalReached(context: Context) {
        try {
            val app = context.applicationContext
            val repo = Repo.get(app)
            if (repo.fastStart.value <= 0L) return
            val nm = app.getSystemService(NotificationManager::class.java) ?: return
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_GOAL, "Goal reached", NotificationManager.IMPORTANCE_DEFAULT)
            )
            val open = PendingIntent.getActivity(
                app, 22,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                FLAGS,
            )
            val n = Notification.Builder(app, CHANNEL_GOAL)
                .setSmallIcon(R.drawable.ic_fasting)
                .setContentTitle("Goal reached")
                .setContentText("You've finished your " + planLabel(repo.goalHours.value) + " fast. Nice work!")
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(ID_GOAL, n)
        } catch (e: Exception) {
        }
    }
}

class GoalReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.postGoalReached(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Widgets.updateAll(context)
    }
}

class NudgeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.postNudge(context)
    }
}

/** Starts the fast when its planned time comes. */
class ScheduledStartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            Repo.get(context.applicationContext).applyScheduledStart()
        } catch (e: Exception) {
        }
    }
}
