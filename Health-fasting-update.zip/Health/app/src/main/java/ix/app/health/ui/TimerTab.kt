package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.DAY_MS
import ix.app.health.data.Entry
import ix.app.health.data.FastRecord
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.Targets
import ix.app.health.data.Types
import ix.app.health.data.addDays
import ix.app.health.data.dayStart
import ix.app.health.data.planGoalFor
import ix.app.health.data.weekStart
import kotlinx.coroutines.delay
import java.util.Locale

/** Everything the timer sections need, so each section can be a small composable. */
private class T(
    val repo: Repo,
    val now: Long,
    val start: Long,
    val goal: Int,
    val plan: Int,
    val fasts: List<FastRecord>,
    val entries: List<Entry>,
    val targets: Targets,
    val waterGoal: Int,
    val reason: String,
    val remOn: Boolean,
    val remLead: Int,
    val scheduled: Long,
    val onStages: () -> Unit,
    val onLog: (LogKind) -> Unit,
    val onEnd: () -> Unit,
    val onEditStart: () -> Unit,
    val onEditReason: () -> Unit,
    val onCheckIn: () -> Unit,
) {
    val fasting get() = start > 0L
    val flexi get() = goal <= 0
    val goalMs get() = goal * HOUR_MS
    val elapsed get() = if (start > 0L) (now - start).coerceAtLeast(0L) else 0L
    val left get() = goalMs - elapsed
}

private fun d1(v: Double): String = String.format(Locale.US, "%.1f", v)
private fun d2(v: Double): String = fmtNum(Math.round(v * 100.0) / 100.0)

@Composable
fun TimerTab(repo: Repo, onStages: () -> Unit, onLog: (LogKind) -> Unit) {
    val start by repo.fastStart.collectAsState()
    val goalCur by repo.goalHours.collectAsState()
    val base by repo.baseGoal.collectAsState()
    val same by repo.samePlan.collectAsState()
    val plans by repo.plans.collectAsState()
    val program by repo.program.collectAsState()
    val fasts by repo.fasts.collectAsState()
    val entries by repo.entries.collectAsState()
    val targets by repo.targets.collectAsState()
    val waterGoal by repo.waterGoal.collectAsState()
    val reason by repo.reason.collectAsState()
    val remOn by repo.reminderOn.collectAsState()
    val remLead by repo.reminderLead.collectAsState()
    val scheduled by repo.scheduledStart.collectAsState()
    val layout by repo.layout.collectAsState()

    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(1000L)
            value = System.currentTimeMillis()
        }
    }

    val due = scheduled > 0L && now >= scheduled
    LaunchedEffect(due) { if (due) repo.applyScheduledStart() }

    var confirmEnd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var hunger by remember { mutableStateOf(false) }
    var editReason by remember { mutableStateOf(false) }
    var guide by remember { mutableStateOf(false) }

    val fasting = start > 0L
    val plan = planGoalFor(now, base, same, plans, program)
    val goal = if (fasting) goalCur else plan

    fun endNow() {
        val dur = now - start
        repo.endFast()
        if (dur >= 24 * HOUR_MS) guide = true
    }

    val t = T(
        repo, now, start, goal, plan, fasts, entries, targets, waterGoal, reason, remOn, remLead, scheduled,
        onStages = onStages,
        onLog = onLog,
        onEnd = {
            val left = goal * HOUR_MS - (now - start)
            if (goal > 0 && left > 0) confirmEnd = true else endNow()
        },
        onEditStart = { editing = true },
        onEditReason = { editReason = true },
        onCheckIn = { hunger = true },
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 8.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        when {
            !fasting -> IdleContent(t)
            layout == 1 -> FocusContent(t)
            else -> RingContent(t)
        }
        Spacer(Modifier.height(12.dp))
        WeekSection(t)
    }

    // ---- confirm ending early ----
    if (confirmEnd) {
        AlertDialog(
            onDismissRequest = { confirmEnd = false },
            title = { Text("End this fast?") },
            text = {
                Text(
                    "You're at ${fmtHm(t.elapsed)} of $goal:00. " +
                        "Ending now saves it as ended early. You can edit it later in the Journal."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmEnd = false
                    endNow()
                }) { Text("End fast") }
            },
            dismissButton = { TextButton(onClick = { confirmEnd = false }) { Text("Keep fasting") } },
        )
    }

    // ---- break-the-fast guide after a long fast ----
    if (guide) {
        AlertDialog(
            onDismissRequest = { guide = false },
            title = { Text("Break your fast gently") },
            text = {
                Text(
                    "Start with water and a pinch of salt. After a while, have a small, light meal and eat slowly. " +
                        "Build up over a few hours. Large or heavy meals can wait until you feel steady. " +
                        "If you feel unwell, rest and get medical advice."
                )
            },
            confirmButton = { TextButton(onClick = { guide = false }) { Text("Got it") } },
        )
    }

    // ---- edit start time ----
    if (editing && fasting) {
        AlertDialog(
            onDismissRequest = { editing = false },
            confirmButton = { TextButton(onClick = { editing = false }) { Text("Done") } },
            title = { Text("Fast started") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(fmtFull(start), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("−12 h", false) { repo.startFast(start - 12 * HOUR_MS) }
                        Pill("−3 h", false) { repo.startFast(start - 3 * HOUR_MS) }
                        Pill("−1 h", false) { repo.startFast(start - HOUR_MS) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("−15 m", false) { repo.startFast(start - 15 * 60_000L) }
                        Pill("+15 m", false) { repo.startFast(start + 15 * 60_000L) }
                        Pill("+1 h", false) { repo.startFast(start + HOUR_MS) }
                    }
                }
            },
        )
    }

    // ---- hunger check-in ----
    if (hunger) {
        AlertDialog(
            onDismissRequest = { hunger = false },
            title = { Text("How hungry are you?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for (i in 1..5) HungerButton(i) {
                            repo.addEntry(Types.HUNGER, i.toDouble())
                            hunger = false
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Sub("Not at all", size = 11)
                        Sub("Very hungry", size = 11)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { hunger = false }) { Text("Cancel") } },
        )
    }

    // ---- reason ----
    if (editReason) {
        var text by remember { mutableStateOf(reason) }
        AlertDialog(
            onDismissRequest = { editReason = false },
            title = { Text("Why I'm fasting") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("A reason that keeps you going") },
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    repo.setReason(text)
                    editReason = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editReason = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun HungerButton(n: Int, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text("$n", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

// =====================================================================
// Idle: eating window
// =====================================================================

@Composable
private fun IdleContent(t: T) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val lastEnd = t.fasts.maxOfOrNull { it.end } ?: 0L
    val last = t.fasts.maxByOrNull { it.end }
    val plan = t.plan
    val windowHours = if (plan in 1..23) 24 - plan else 0
    val windowEnd = if (lastEnd > 0L && windowHours > 0) lastEnd + windowHours * HOUR_MS else 0L
    val inWindow = windowEnd > t.now
    val progress = if (inWindow) ((windowEnd - t.now).toFloat() / (windowHours * HOUR_MS).toFloat()).coerceIn(0f, 1f) else 0f

    FastRing(progress = progress, color = onSurface, modifier = Modifier.size(272.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            FIcon(R.drawable.ic_fork, size = 22.dp, tint = muted)
            Spacer(Modifier.height(6.dp))
            Text(
                if (inWindow || lastEnd == 0L) "Eating window" else "Last fast ended",
                fontSize = 13.sp,
                color = muted,
            )
            Text(
                when {
                    inWindow -> fmtDur(windowEnd - t.now + 59_999L)
                    lastEnd > 0L -> fmtHm(t.now - lastEnd)
                    else -> "Ready"
                },
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = onSurface,
            )
            Text(
                when {
                    inWindow -> "Next fast from ${fmtClock(windowEnd)}"
                    lastEnd > 0L -> "ago · start when you are"
                    else -> "Start when you are"
                },
                fontSize = 13.sp,
                color = muted,
            )
        }
    }

    Spacer(Modifier.height(20.dp))

    val nudgeAt = windowEnd - t.remLead * 60_000L
    if (inWindow) {
        SoftCard(Modifier.fillMaxWidth().clickable { t.repo.setReminderOn(!t.remOn) }) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                IconCircle(
                    R.drawable.ic_bell,
                    box = 40.dp,
                    size = 20.dp,
                    tint = if (t.remOn) MaterialTheme.colorScheme.primary else muted,
                )
                Column(Modifier.weight(1f)) {
                    Text(
                        if (t.remOn) "Reminder at ${fmtClock(nudgeAt)}" else "Reminder off",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = onSurface,
                    )
                    Sub(
                        if (t.remOn) "A last-meal nudge, then your fast starts at ${fmtClock(windowEnd)}"
                        else "Tap to get a nudge before your fast starts at ${fmtClock(windowEnd)}",
                        size = 12,
                    )
                }
                FIcon(R.drawable.ic_chev_right, size = 18.dp, tint = muted)
            }
        }
        Spacer(Modifier.height(12.dp))
    }

    // ---- last fast + streak ----
    val streak = streakInfo(t.fasts, t.now)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SoftCard(Modifier.weight(1f)) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Sub("Last fast")
                Text(
                    if (last == null) "—" else fmtDur(last.duration),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = onSurface,
                )
                Sub(
                    if (last == null) "Nothing yet"
                    else (if (last.completed) "Goal reached" else "Ended early") + " · ended " + fmtClock(last.end),
                    size = 11,
                )
            }
        }
        SoftCard(Modifier.weight(1f)) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Sub("Streak")
                Text(
                    if (streak.days == 1) "1 day" else "${streak.days} days",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = onSurface,
                )
                Sub(if (streak.graceLeft > 0) "1 grace day left" else "No grace day left", size = 11)
            }
        }
    }

    Spacer(Modifier.height(16.dp))
    BlackButton("Start fast now") { t.repo.startFast() }
    if (t.scheduled > 0L) {
        TextButton(onClick = { t.repo.cancelScheduledStart() }) {
            Text("Planned start ${fmtClock(t.scheduled)} · Cancel", color = muted, fontSize = 14.sp)
        }
    } else if (inWindow) {
        TextButton(onClick = { t.repo.scheduleStart(windowEnd) }) {
            Text("Or start at ${fmtClock(windowEnd)} as planned", color = muted, fontSize = 14.sp)
        }
    }

    // ---- eating window checklist ----
    if (inWindow) {
        val meals = t.entries.filter { it.type == Types.MEAL && it.time >= lastEnd }.sortedBy { it.time }
        val water = t.repo.sum(Types.WATER, lastEnd, meals.firstOrNull()?.time ?: Long.MAX_VALUE)
        val waterDone = water >= 500.0
        val firstDone = meals.isNotEmpty()
        val lastDone = meals.size >= 2
        val doneCount = listOf(waterDone, firstDone, lastDone).count { it }
        Spacer(Modifier.height(4.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CardTitle("Eating window")
                    Sub("$doneCount of 3 done", size = 13)
                }
                Spacer(Modifier.height(8.dp))
                CheckRow("Water before the first meal", "500 ml", waterDone, "Log water") { t.onLog(LogKind.Water) }
                CheckRow(
                    "First meal logged",
                    if (firstDone) fmtClock(meals.first().time) else "Not yet",
                    firstDone, "Log meal",
                ) { t.onLog(LogKind.Meal) }
                CheckRow(
                    "Last meal before ${fmtClock(nudgeAt)}",
                    if (lastDone) fmtClock(meals.last().time) else "Log it when you finish eating",
                    lastDone, "Log meal",
                ) { t.onLog(LogKind.Meal) }
            }
        }
    }
}

@Composable
private fun CheckRow(title: String, sub: String, done: Boolean, action: String, onAction: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (done) {
            Box(
                Modifier.size(26.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) { FIcon(R.drawable.ic_check, size = 14.dp, tint = MaterialTheme.colorScheme.onPrimary) }
        } else {
            Box(Modifier.size(26.dp).clip(CircleShape).border(2.dp, MaterialTheme.colorScheme.outline, CircleShape))
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Sub(sub, size = 12)
        }
        if (!done) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.outlineVariant)
                    .clickable(onClick = onAction)
                    .padding(horizontal = 12.dp, vertical = 7.dp),
            ) { Text(action, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface) }
        }
    }
}

// =====================================================================
// Fasting: ring layout
// =====================================================================

private fun nodesFor(t: T): List<RingNode> {
    if (t.flexi) return emptyList()
    val cur = stageIndexFor(t.elapsed)
    val out = ArrayList<RingNode>()
    for (i in fastingStages.indices) {
        val h = fastingStages[i].hour
        if (h * HOUR_MS >= t.goalMs) continue
        out.add(RingNode(h.toFloat() / t.goal, if (i < cur) 0 else if (i == cur) 1 else 2))
    }
    return out
}

@Composable
private fun RingContent(t: T) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val stageIdx = stageIndexFor(t.elapsed)
    val stage = fastingStages[stageIdx]
    val progress = if (t.flexi) {
        ((t.elapsed % DAY_MS).toFloat() / DAY_MS.toFloat()).coerceIn(0f, 1f)
    } else {
        (t.elapsed.toFloat() / t.goalMs.toFloat()).coerceIn(0f, 1f)
    }

    FastRing(
        progress = progress,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(272.dp),
        nodes = nodesFor(t),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(stage.name, fontSize = 13.sp, color = muted)
            Text(fmtHms(t.elapsed), fontSize = 40.sp, fontWeight = FontWeight.Bold, color = onSurface)
            Text(
                when {
                    t.flexi -> "No goal"
                    t.left > 0 -> "${fmtDur(t.left + 59_999L)} left"
                    else -> "Goal reached · +${fmtHm(-t.left)}"
                },
                fontSize = 13.sp,
                color = muted,
            )
        }
    }

    Spacer(Modifier.height(16.dp))
    NextUpCard(t, stageIdx)

    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SoftCard(Modifier.weight(1f).clickable { t.onEditStart() }) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Sub("Started · tap to edit")
                Text(fmtDayClock(t.start), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = onSurface)
            }
        }
        SoftCard(Modifier.weight(1f)) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Sub(if (t.flexi) "Goal" else "Goal at")
                Text(
                    if (t.flexi) "No goal" else fmtDayClock(t.start + t.goalMs),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = onSurface,
                )
            }
        }
    }

    Spacer(Modifier.height(16.dp))
    BlackButton("End fast") { t.onEnd() }

    Spacer(Modifier.height(16.dp))
    QuickLogRow(t)

    Spacer(Modifier.height(12.dp))
    SoftCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Sub("Right now")
                    Text(stage.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = onSurface)
                }
                TextButton(onClick = t.onStages) {
                    Text("All stages", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(Modifier.height(4.dp))
            Sub(stage.text, size = 14)
            Spacer(Modifier.height(12.dp))
            StageDetails(stage)
        }
    }

    Spacer(Modifier.height(12.dp))
    DuringFastCard(t)

    Spacer(Modifier.height(12.dp))
    ReasonCard(t)
}

@Composable
private fun NextUpCard(t: T, stageIdx: Int) {
    val next = fastingStages.getOrNull(stageIdx + 1)
    val cur = fastingStages[stageIdx]
    SoftCard(Modifier.fillMaxWidth().clickable { t.onStages() }) {
        Column(Modifier.padding(16.dp)) {
            if (next == null) {
                Sub("Last stage")
                Text(cur.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            } else {
                val nextMs = next.hour * HOUR_MS
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Sub("Next up · stage ${stageIdx + 2} of ${fastingStages.size}")
                    Sub("at ${fmtClock(t.start + nextMs)}")
                }
                Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    Text(next.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        "in ${fmtDur(nextMs - t.elapsed)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
                Spacer(Modifier.height(10.dp))
                val span = (next.hour - cur.hour) * HOUR_MS
                Bar(((t.elapsed - cur.hour * HOUR_MS).toFloat() / span.toFloat()), MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun QuickLogRow(t: T) {
    val today = dayStart(t.now)
    val tomorrow = today + DAY_MS
    val water = t.repo.sum(Types.WATER, today, tomorrow)
    val salts = t.repo.count(Types.SODIUM, today, tomorrow)
    val cups = t.repo.sum(Types.COFFEE, today, tomorrow)
    val lastHunger = t.entries.lastOrNull { it.type == Types.HUNGER && it.time >= t.start }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        QuickTile(R.drawable.ic_drop, TrackBlue, "${fmtL(water)} L", "Water", Modifier.weight(1f)) { t.onLog(LogKind.Water) }
        QuickTile(R.drawable.ic_bolt, TrackAmber, "$salts of 3", "Salts", Modifier.weight(1f)) { t.onLog(LogKind.Electrolytes) }
        QuickTile(
            R.drawable.ic_cup, MaterialTheme.colorScheme.onSurfaceVariant,
            if (cups == 1.0) "1 cup" else "${fmtNum(cups)} cups", "Coffee", Modifier.weight(1f),
        ) { t.onLog(LogKind.Coffee) }
        QuickTile(
            R.drawable.ic_face, MaterialTheme.colorScheme.primary,
            if (lastHunger == null) "Add" else "Hunger ${fmtNum(lastHunger.value)}", "Check-in", Modifier.weight(1f),
        ) { t.onCheckIn() }
    }
}

@Composable
private fun QuickTile(icon: Int, tint: Color, value: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    SoftCard(modifier.clickable(onClick = onClick)) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            FIcon(icon, size = 22.dp, tint = tint)
            Spacer(Modifier.height(6.dp))
            Text(
                value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Sub(label, size = 11)
        }
    }
}

@Composable
private fun DuringFastCard(t: T) {
    val days = ((t.elapsed + DAY_MS - 1) / DAY_MS).toInt().coerceAtLeast(1)
    val water = t.repo.sum(Types.WATER, t.start)
    val na = t.repo.sum(Types.SODIUM, t.start)
    val k = t.repo.sum(Types.POTASSIUM, t.start)
    val mg = t.repo.sum(Types.MAGNESIUM, t.start)
    val goalMl = t.waterGoal.toDouble() * days
    val checks = t.entries.filter { it.type == Types.HUNGER && it.time >= t.start }.takeLast(3)

    SoftCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                CardTitle("During this fast")
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.primary)
                        .clickable { t.onLog(LogKind.Water) }
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                ) { Text("Log", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary) }
            }
            LabeledBar("Water", "${fmtL(water)} / ${fmtL(goalMl)} L", (if (goalMl > 0.0) (water / goalMl).toFloat() else 0f), TrackBlue)
            LabeledBar("Sodium", "${d1(na)} / ${d1(t.targets.sodium * days)} g", (na / (t.targets.sodium * days)).toFloat(), TrackBlue)
            LabeledBar("Potassium", "${d1(k)} / ${d1(t.targets.potassium * days)} g", (k / (t.targets.potassium * days)).toFloat(), TrackAmber)
            LabeledBar("Magnesium", "${d2(mg)} / ${d2(t.targets.magnesium * days)} g", (mg / (t.targets.magnesium * days)).toFloat(), TrackPurple)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Sub("Check-ins", size = 13)
                Sub(
                    if (checks.isEmpty()) "None yet"
                    else checks.mapIndexed { i, e ->
                        fmtClock(e.time) + " · " + (if (i == 0) "hunger " else "") + fmtNum(e.value)
                    }.joinToString("   "),
                    size = 12,
                )
            }
        }
    }
}

@Composable
private fun ReasonCard(t: T) {
    SoftCard(Modifier.fillMaxWidth().clickable { t.onEditReason() }) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Sub("Why I'm fasting")
                Text(
                    if (t.reason.isBlank()) "Add a reason that keeps you going" else t.reason,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (t.reason.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
            IconCircle(R.drawable.ic_pencil, box = 36.dp, size = 16.dp)
        }
    }
}

// =====================================================================
// Fasting: focus layout
// =====================================================================

@Composable
private fun FocusContent(t: T) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val primary = MaterialTheme.colorScheme.primary
    val stageIdx = stageIndexFor(t.elapsed)
    val stage = fastingStages[stageIdx]

    Spacer(Modifier.height(8.dp))
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { t.onStages() }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(primary))
        Text(stage.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = onSurface)
    }

    Spacer(Modifier.height(18.dp))
    Text(fmtHm(t.elapsed), fontSize = 88.sp, fontWeight = FontWeight.Bold, color = onSurface)
    Sub("hours fasted · ${(t.elapsed / 1000L) % 60} s", size = 14)

    // ---- stage track ----
    if (!t.flexi) {
        Spacer(Modifier.height(24.dp))
        val frac = (t.elapsed.toFloat() / t.goalMs.toFloat()).coerceIn(0f, 1f)
        BoxWithConstraints(Modifier.fillMaxWidth().height(62.dp)) {
            val w = maxWidth
            val r = 11.dp
            Box(
                Modifier
                    .offset(y = 9.dp)
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.outlineVariant),
            )
            Box(
                Modifier
                    .offset(y = 9.dp)
                    .width(w * frac)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(primary),
            )
            for (i in fastingStages.indices) {
                val st = fastingStages[i]
                if (st.hour * HOUR_MS >= t.goalMs) continue
                val f = st.hour.toFloat() / t.goal
                val x = (w * f - r).coerceIn(0.dp, w - r * 2)
                val reached = i <= stageIdx
                val current = i == stageIdx
                Box(
                    Modifier
                        .offset(x = x, y = if (current) 0.dp else 3.dp)
                        .size(if (current) r * 2 else 16.dp)
                        .clip(CircleShape)
                        .background(if (reached) primary else MaterialTheme.colorScheme.surfaceVariant)
                        .border(
                            if (current) 3.dp else 2.dp,
                            if (current) onSurface else if (reached) MaterialTheme.colorScheme.background else NodeStroke,
                            CircleShape,
                        ),
                )
                Column(
                    Modifier
                        .offset(x = (x + r - 24.dp).coerceIn(0.dp, w - 48.dp), y = 28.dp)
                        .width(48.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("${st.hour}h", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (reached) onSurface else muted)
                    Sub(st.short, size = 10)
                }
            }
            FIcon(
                R.drawable.ic_flag,
                modifier = Modifier.offset(x = w - 22.dp, y = 0.dp),
                size = 22.dp,
                tint = if (t.left <= 0) primary else muted,
            )
        }
    }

    // ---- anchors ----
    Spacer(Modifier.height(16.dp))
    val water = t.repo.sum(Types.WATER, dayStart(t.now))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        AnchorTile(if (t.left > 0 && !t.flexi) "Left" else "Over", if (t.flexi) "—" else fmtDur(kotlin.math.abs(t.left)), Modifier.weight(1f))
        AnchorTile("Goal at", if (t.flexi) "No goal" else fmtDayClock(t.start + t.goalMs), Modifier.weight(1f))
        AnchorTile("Water", "${fmtL(water)} L", Modifier.weight(1f))
    }

    Spacer(Modifier.height(12.dp))
    NextUpCard(t, stageIdx)

    // ---- inline check-in ----
    Spacer(Modifier.height(12.dp))
    SoftCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            CardTitle("How hungry are you?")
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for (i in 1..5) HungerButton(i) { t.repo.addEntry(Types.HUNGER, i.toDouble()) }
            }
        }
    }

    Spacer(Modifier.height(16.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        BlackButton("End fast", Modifier.weight(1f)) { t.onEnd() }
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable { t.onLog(LogKind.Water) },
            contentAlignment = Alignment.Center,
        ) { Text("+", fontSize = 26.sp, color = onSurface) }
    }

    if (t.reason.isNotBlank()) {
        Spacer(Modifier.height(14.dp))
        Sub("“${t.reason}”", Modifier.clickable { t.onEditReason() }, size = 13)
    }
}

@Composable
private fun AnchorTile(label: String, value: String, modifier: Modifier) {
    SoftCard(modifier) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 12.dp)) {
            Sub(label, size = 11)
            Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

// =====================================================================
// This week
// =====================================================================

@Composable
private fun WeekSection(t: T) {
    val today = dayStart(t.now)
    val monday = weekStart(t.now)
    val days = (0..6).map { addDays(monday, it) }
    val done = t.fasts.filter { it.completed }.map { dayStart(it.end) }.toSet()
    val sofar = days.count { it <= today }
    val got = days.count { it <= today && it in done }
    val streak = streakInfo(t.fasts, t.now)
    WeekCard(
        done = done,
        days = days,
        today = today,
        trailing = if (t.fasting) {
            if (streak.days == 1) "1 day streak" else "${streak.days} day streak"
        } else {
            "$got of $sofar so far"
        },
    )
}
