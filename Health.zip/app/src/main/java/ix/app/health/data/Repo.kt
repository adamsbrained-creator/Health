package ix.app.health.data

import android.content.Context
import ix.app.health.widget.Widgets
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

object Types {
    const val WEIGHT = "weight"
    const val WATER = "water"
    const val SLEEP = "sleep"
    const val WORKOUT = "workout"

    val all = listOf(WEIGHT, WATER, SLEEP, WORKOUT)

    fun label(type: String): String = when (type) {
        WEIGHT -> "Weight"
        WATER -> "Water"
        SLEEP -> "Sleep"
        else -> "Workout"
    }

    fun unit(type: String): String = when (type) {
        WEIGHT -> "kg"
        WATER -> "ml"
        SLEEP -> "h"
        else -> "min"
    }
}

data class Entry(
    val id: Long,
    val type: String,
    val value: Double,
    val note: String,
    val time: Long,
    val source: String, // "app" or "widget"
)

data class FastRecord(val start: Long, val end: Long)

const val HOUR_MS = 3_600_000L
const val DAY_MS = 24L * HOUR_MS

fun dayStart(time: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = time
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun addDays(time: Long, days: Int): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = time
    c.add(Calendar.DAY_OF_YEAR, days)
    return c.timeInMillis
}

/**
 * Single source of truth. Everything is saved in SharedPreferences as small JSON strings.
 * The app screens and the home-screen widgets both go through this class,
 * so data logged from a widget shows up in the app straight away.
 */
class Repo private constructor(context: Context) {

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("health", Context.MODE_PRIVATE)

    private val _entries = MutableStateFlow(readEntries())
    val entries: StateFlow<List<Entry>> = _entries

    private val _fastStart = MutableStateFlow(prefs.getLong(K_FAST_START, 0L))
    val fastStart: StateFlow<Long> = _fastStart

    private val _fasts = MutableStateFlow(readFasts())
    val fasts: StateFlow<List<FastRecord>> = _fasts

    private val _goalHours = MutableStateFlow(prefs.getInt(K_GOAL, 23))
    val goalHours: StateFlow<Int> = _goalHours

    private val _waterGoal = MutableStateFlow(prefs.getInt(K_WATER_GOAL, 2500))
    val waterGoal: StateFlow<Int> = _waterGoal

    // ---- entries -------------------------------------------------------

    fun addEntry(type: String, value: Double, note: String = "", source: String = "app") {
        val now = System.currentTimeMillis()
        val entry = Entry(now, type, value, note, now, source)
        _entries.value = (_entries.value + entry).sortedBy { it.time }
        saveEntries()
        Widgets.updateAll(app)
    }

    fun deleteEntry(id: Long) {
        _entries.value = _entries.value.filter { it.id != id }
        saveEntries()
        Widgets.updateAll(app)
    }

    fun latest(type: String): Entry? = _entries.value.lastOrNull { it.type == type }

    fun waterToday(): Int {
        val from = dayStart(System.currentTimeMillis())
        var sum = 0.0
        for (e in _entries.value) {
            if (e.type == Types.WATER && e.time >= from) sum += e.value
        }
        return sum.toInt()
    }

    // ---- fasting -------------------------------------------------------

    fun startFast(at: Long = System.currentTimeMillis()) {
        val start = minOf(at, System.currentTimeMillis())
        _fastStart.value = start
        prefs.edit().putLong(K_FAST_START, start).apply()
        Widgets.updateAll(app)
    }

    fun endFast() {
        val start = _fastStart.value
        if (start > 0L) {
            val list = (_fasts.value + FastRecord(start, System.currentTimeMillis())).takeLast(400)
            _fasts.value = list
            saveFasts()
        }
        _fastStart.value = 0L
        prefs.edit().putLong(K_FAST_START, 0L).apply()
        Widgets.updateAll(app)
    }

    fun toggleFast() {
        if (_fastStart.value > 0L) endFast() else startFast()
    }

    fun setGoalHours(hours: Int) {
        val h = hours.coerceIn(12, 23)
        _goalHours.value = h
        prefs.edit().putInt(K_GOAL, h).apply()
        Widgets.updateAll(app)
    }

    fun setWaterGoal(ml: Int) {
        val v = ml.coerceIn(1000, 6000)
        _waterGoal.value = v
        prefs.edit().putInt(K_WATER_GOAL, v).apply()
        Widgets.updateAll(app)
    }

    // ---- storage -------------------------------------------------------

    private fun readEntries(): List<Entry> {
        val raw = prefs.getString(K_ENTRIES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Entry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Entry(
                        id = o.getLong("id"),
                        type = o.getString("type"),
                        value = o.getDouble("value"),
                        note = o.optString("note", ""),
                        time = o.getLong("time"),
                        source = o.optString("source", "app"),
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveEntries() {
        val arr = JSONArray()
        for (e in _entries.value) {
            val o = JSONObject()
            o.put("id", e.id)
            o.put("type", e.type)
            o.put("value", e.value)
            o.put("note", e.note)
            o.put("time", e.time)
            o.put("source", e.source)
            arr.put(o)
        }
        prefs.edit().putString(K_ENTRIES, arr.toString()).apply()
    }

    private fun readFasts(): List<FastRecord> {
        val raw = prefs.getString(K_FASTS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<FastRecord>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(FastRecord(o.getLong("start"), o.getLong("end")))
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveFasts() {
        val arr = JSONArray()
        for (f in _fasts.value) {
            val o = JSONObject()
            o.put("start", f.start)
            o.put("end", f.end)
            arr.put(o)
        }
        prefs.edit().putString(K_FASTS, arr.toString()).apply()
    }

    companion object {
        private const val K_ENTRIES = "entries"
        private const val K_FASTS = "fasts"
        private const val K_FAST_START = "fast_start"
        private const val K_GOAL = "goal_hours"
        private const val K_WATER_GOAL = "water_goal_ml"

        @Volatile
        private var instance: Repo? = null

        fun get(context: Context): Repo {
            return instance ?: synchronized(this) {
                instance ?: Repo(context).also { instance = it }
            }
        }
    }
}
