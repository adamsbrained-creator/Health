package ix.app.health.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.DAY_MS
import ix.app.health.data.Entry
import ix.app.health.data.Repo
import ix.app.health.data.Types
import java.util.Locale

@Composable
fun StatsScreen(repo: Repo, onAdd: () -> Unit) {
    val entries by repo.entries.collectAsState()
    val fasts by repo.fasts.collectAsState()
    val waterGoal by repo.waterGoal.collectAsState()
    var range by remember { mutableIntStateOf(0) }

    val ranges = listOf("Week" to 7, "Month" to 30, "Year" to 365)
    val names = listOf("week", "month", "year")
    val days = ranges[range].second
    val now = System.currentTimeMillis()
    val from = now - days * DAY_MS

    val weights = entries.filter { it.type == Types.WEIGHT && it.time >= from }
    val latestWeight = entries.lastOrNull { it.type == Types.WEIGHT }
    val latestSleep = entries.lastOrNull { it.type == Types.SLEEP }
    val workouts = entries.count { it.type == Types.WORKOUT && it.time >= from }
    val fastCount = fasts.count { it.end >= from }
    val waterToday = repo.waterToday()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 16.dp, bottom = 24.dp),
    ) {
        ScreenHeader("Your numbers", "Stats") {
            Box(
                modifier = Modifier
                    .padding(top = 6.dp)
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .clickable(onClick = onAdd),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painterResource(R.drawable.ic_plus),
                    contentDescription = "Add entry",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(20.dp),
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- range selector ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(3.dp),
        ) {
            for ((i, r) in ranges.withIndex()) {
                val selected = i == range
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .clickable { range = i }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        r.first,
                        fontSize = 13.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        color = if (selected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---- weight card ----
        SoftCard(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
                Text("Weight", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    Text(
                        if (latestWeight != null) String.format(Locale.US, "%.1f", latestWeight.value) else "—",
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        "  kg",
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 6.dp),
                    )
                    Spacer(Modifier.weight(1f))
                    if (weights.size >= 2) {
                        val diff = weights.last().value - weights.first().value
                        val sign = if (diff > 0.05) "+" else if (diff < -0.05) "−" else ""
                        Text(
                            sign + String.format(Locale.US, "%.1f", Math.abs(diff)) + " this " + names[range],
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (weights.size >= 2) {
                    WeightChart(
                        points = weights,
                        from = from,
                        to = now,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                    )
                } else {
                    Text(
                        "Log your weight at least twice in this period to see the trend.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---- small cards ----
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                "Water today",
                String.format(Locale.US, "%.1f / %.1f L", waterToday / 1000.0, waterGoal / 1000.0),
                Modifier.weight(1f),
            )
            StatCard(
                "Last sleep",
                if (latestSleep != null) fmtSleep(latestSleep.value) else "—",
                Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Workouts", workouts.toString(), Modifier.weight(1f))
            StatCard("Fasts done", fastCount.toString(), Modifier.weight(1f))
        }

        Spacer(Modifier.height(24.dp))

        // ---- recent entries ----
        Text(
            "Recent entries",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.height(4.dp))

        val recent = entries.takeLast(20).reversed()
        if (recent.isEmpty()) {
            Text(
                "Nothing logged yet. Use the + button or the home-screen widgets.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
        for (e in recent) {
            EntryRow(e) { repo.deleteEntry(e.id) }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    SoftCard(modifier = modifier) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                value,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
private fun EntryRow(e: Entry, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                describe(e),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                fmtDateTime(e.time),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (e.source == "widget") {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(50))
                    .padding(horizontal = 9.dp, vertical = 3.dp),
            ) {
                Text(
                    "Widget",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .clickable(onClick = onDelete),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painterResource(R.drawable.ic_close),
                contentDescription = "Delete entry",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

@Composable
private fun WeightChart(points: List<Entry>, from: Long, to: Long, modifier: Modifier) {
    val line = MaterialTheme.colorScheme.onSurface
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val padV = 10.dp.toPx()
        val padH = 6.dp.toPx()
        for (i in 0..2) {
            val y = padV + (h - 2f * padV) * i / 2f
            drawLine(grid, Offset(0f, y), Offset(w, y), 1.dp.toPx())
        }

        var lo = points.minOf { it.value }
        var hi = points.maxOf { it.value }
        if (hi - lo < 0.5) {
            val mid = (hi + lo) / 2.0
            lo = mid - 0.25
            hi = mid + 0.25
        }
        val span = (to - from).toFloat()

        fun pointFor(e: Entry): Offset {
            val x = ((e.time - from).toFloat() / span) * (w - 2f * padH) + padH
            val t = ((e.value - lo) / (hi - lo)).toFloat()
            val y = padV + (h - 2f * padV) * (1f - t)
            return Offset(x, y)
        }

        val path = Path()
        points.forEachIndexed { i, e ->
            val p = pointFor(e)
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
        }
        drawPath(
            path = path,
            color = line,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
        drawCircle(color = line, radius = 5.dp.toPx(), center = pointFor(points.last()))
    }
}
