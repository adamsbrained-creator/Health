package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.data.Repo
import java.util.Locale

@Composable
fun SettingsScreen(repo: Repo) {
    val goal by repo.goalHours.collectAsState()
    val water by repo.waterGoal.collectAsState()
    val accent by repo.accent.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 16.dp, bottom = 24.dp),
    ) {
        ScreenHeader("Preferences", "Settings")
        Spacer(Modifier.height(24.dp))

        SectionTitle("Goals")
        SettingRow(
            label = "Fasting window",
            value = "$goal h fast · ${24 - goal} h eating",
            onMinus = { repo.setGoalHours(goal - 1) },
            onPlus = { repo.setGoalHours(goal + 1) },
        )
        Spacer(Modifier.height(10.dp))
        SettingRow(
            label = "Daily water",
            value = String.format(Locale.US, "%.2f L", water / 1000.0),
            onMinus = { repo.setWaterGoal(water - 250) },
            onPlus = { repo.setWaterGoal(water + 250) },
        )

        Spacer(Modifier.height(28.dp))
        SectionTitle("Accent colour")
        SoftCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Accents.forEachIndexed { i, a ->
                    val fill = a.color ?: MaterialTheme.colorScheme.onSurface
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(fill)
                            .clickable { repo.setAccent(i) },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (i == accent) {
                            Box(
                                Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                            )
                        }
                    }
                }
            }
        }
        Text(
            Accents.getOrNull(accent)?.name ?: "",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp, start = 4.dp),
        )

        Spacer(Modifier.height(28.dp))
        SectionTitle("Widgets")
        Text(
            "Long-press your home screen, open Widgets and pick Health. " +
                "Quick log saves water in one tap and opens a small pop-up for weight, sleep and workouts. " +
                "Everything you log there appears in Stats with a Widget tag.",
            fontSize = 14.sp,
            lineHeight = 20.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(28.dp))
        SectionTitle("About")
        Text(
            "Health 0.1 · Your data stays on this phone.",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(bottom = 10.dp),
    )
}

@Composable
private fun SettingRow(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    SoftCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    label,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    value,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallStep("−", onMinus)
                SmallStep("+", onPlus)
            }
        }
    }
}

@Composable
private fun SmallStep(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}
