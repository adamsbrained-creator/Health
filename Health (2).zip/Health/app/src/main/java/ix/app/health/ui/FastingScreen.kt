package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.addDays
import ix.app.health.data.dayStart
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun FastingScreen(repo: Repo) {
    val start by repo.fastStart.collectAsState()
    val goal by repo.goalHours.collectAsState()
    val fasts by repo.fasts.collectAsState()
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(1000L)
            value = System.currentTimeMillis()
        }
    }
    var editing by remember { mutableStateOf(false) }

    val fasting = start > 0L
    val goalMs = goal * HOUR_MS
    val elapsed = if (fasting) (now - start).coerceAtLeast(0L) else 0L
    val progress = if (fasting) (elapsed.toFloat() / goalMs.toFloat()).coerceIn(0f, 1f) else 0f
    val left = goalMs - elapsed

    val timeFmt = SimpleDateFormat("EEE HH:mm", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 16.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val dateText = SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(Date(now))
        ScreenHeader(dateText, "Fasting") {
            Box(
                modifier = Modifier
                    .padding(top = 6.dp)
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) {
                Text(
                    "$goal : ${24 - goal}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimary,
                )
            }
        }

        Spacer(Modifier.height(28.dp))

        Ring(progress = progress, modifier = Modifier.size(248.dp), strokeWidth = 14.dp) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (fasting) {
                    Text("Elapsed", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        fmtHm(elapsed),
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        if (left > 0) "${fmtHm(left)} left" else "Goal reached · +${fmtHm(-left)}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Text("Eating window", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "Ready",
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text("Start when you are", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SoftCard(
                modifier = Modifier
                    .weight(1f)
                    .clickable(enabled = fasting) { editing = true },
            ) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                    Text("Started", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        if (fasting) timeFmt.format(Date(start)) else "—",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
            SoftCard(modifier = Modifier.weight(1f)) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                    Text(
                        if (fasting) "Goal at" else "Goal",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        if (fasting) timeFmt.format(Date(start + goalMs)) else "$goal h",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        BlackButton(if (fasting) "End fast" else "Start fast") { repo.toggleFast() }

        Spacer(Modifier.height(16.dp))

        // ---- this week ----
        val today = dayStart(now)
        val cal = Calendar.getInstance()
        cal.firstDayOfWeek = Calendar.MONDAY
        cal.timeInMillis = now
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val weekStart = dayStart(cal.timeInMillis)
        val days = (0..6).map { addDays(weekStart, it) }
        val done = fasts
            .filter { it.end - it.start >= goalMs - 30 * 60_000L }
            .map { dayStart(it.end) }
            .toSet()
        var streak = 0
        var d = if (today in done) today else addDays(today, -1)
        while (d in done) {
            streak++
            d = addDays(d, -1)
        }
        val letters = listOf("M", "T", "W", "T", "F", "S", "S")

        SoftCard(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        "This week",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        if (streak == 1) "1 day streak" else "$streak day streak",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    for (i in 0..6) {
                        val day = days[i]
                        val isDone = day in done
                        val isToday = day == today
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            val dot = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                            when {
                                isDone -> Box(dot.background(MaterialTheme.colorScheme.onSurface))
                                isToday -> Box(
                                    dot.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                )
                                else -> Box(dot.background(MaterialTheme.colorScheme.outlineVariant))
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                letters[i],
                                fontSize = 12.sp,
                                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                                color = if (isToday) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }

    if (editing && fasting) {
        AlertDialog(
            onDismissRequest = { editing = false },
            confirmButton = { TextButton(onClick = { editing = false }) { Text("Done") } },
            title = { Text("Fast started") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(timeFmt.format(Date(start)), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val steps = listOf(
                            "−1 h" to -HOUR_MS,
                            "−15 m" to -15 * 60_000L,
                            "+15 m" to 15 * 60_000L,
                            "+1 h" to HOUR_MS,
                        )
                        for ((label, delta) in steps) {
                            Pill(label, false) { repo.startFast(start + delta) }
                        }
                    }
                }
            },
        )
    }
}
