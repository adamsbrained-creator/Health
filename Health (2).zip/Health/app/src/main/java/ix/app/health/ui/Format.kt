package ix.app.health.ui

import ix.app.health.data.Entry
import ix.app.health.data.Types
import ix.app.health.data.dayStart
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 78.40 -> "78.4", 250.0 -> "250" */
fun fmtNum(v: Double): String {
    return String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
}

/** Milliseconds as H:MM */
fun fmtHm(ms: Long): String {
    val minutes = (ms / 60_000L).coerceAtLeast(0L)
    return String.format(Locale.US, "%d:%02d", minutes / 60, minutes % 60)
}

fun fmtDateTime(time: Long): String {
    val now = System.currentTimeMillis()
    val hm = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))
    return if (dayStart(time) == dayStart(now)) {
        "Today $hm"
    } else {
        SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(time)) + " " + hm
    }
}

fun fmtSleep(hours: Double): String {
    val totalMin = Math.round(hours * 60).toInt()
    return "${totalMin / 60}h ${String.format(Locale.US, "%02d", totalMin % 60)}m"
}

fun describe(e: Entry): String {
    val main = when (e.type) {
        Types.WEIGHT -> "Weight " + String.format(Locale.US, "%.1f", e.value) + " kg"
        Types.WATER -> "Water +" + fmtNum(e.value) + " ml"
        Types.SLEEP -> "Sleep " + fmtSleep(e.value)
        else -> "Workout " + fmtNum(e.value) + " min"
    }
    return if (e.note.isNotBlank()) "$main · ${e.note}" else main
}
