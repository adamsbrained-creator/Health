# Health

Personal Android app (Kotlin, Jetpack Compose). Package: `ix.app.health`.

- **Fasting**: 23:1 tracker with a ring timer, editable start time, weekly streak
- **Stats**: weight chart, water / sleep / workouts / fasts, recent entries (widget entries are tagged)
- **Exercises**: built-in exercise base with search, categories and how-to steps
- **Widgets**: Quick log, Water, Fasting (long-press home screen > Widgets > Health)
- **Settings**: fasting window, daily water goal

## Build on GitHub

1. Put these files in a repo (the `.github/workflows/build.yml` file must be in the repo),
   or upload `Health.zip` to the repo root next to `.github/workflows/build.yml`.
2. Push to `main` (or run the workflow by hand from the Actions tab).
3. Download `Health.apk` from the Releases page and install it.

## About the signing key

`keystore/health.jks` is a **temporary** key, committed on purpose, with the password `healthtemp`
(alias `health`). It only exists so that every new build is signed the same way and installs over
the previous one. If this app is ever published, generate a new private key, keep it out of the
repo, store it as GitHub secrets, and delete this one. Note that apps signed with a different key
cannot be updated in place, so the old install would have to be removed first.
