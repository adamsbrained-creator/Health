package ix.app.health.widget

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Icon
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import ix.app.health.MainActivity
import ix.app.health.R
import ix.app.health.data.DAY_MS
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.Types
import ix.app.health.ui.fastingStages
import ix.app.health.ui.planLabel
import ix.app.health.ui.stageIndexFor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Everything that reaches you outside the app: the ongoing timer notification and the alerts
 * (stages, halfway and goal, check-ins, hydration, eating window, meals, last-meal nudge).
 *
 * One alarm is always set for the next alert. When it fires, [tick] posts what is due and sets the next one.
 */
object Notifier {
    private const val CH_RUNNING = "fasting_running"
    private const val CH_ALERTS = "fasting_alerts"

    private const val ID_RUNNING = 1
    private const val ID_GOAL = 2
    private const val ID_NUDGE = 3
    private const val ID_STAGE = 4
    private const val ID_CHECKIN = 5
    private const val ID_HYDRATE = 6
    private const val ID_WINDOW = 7
    private const val ID_MEAL = 8

    private const val ALARM_CODE = 40
    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    private const val MIN = 60_000L

    const val ACTION_WATER = "ix.app.health.N_WATER"
    const val ACTION_HUNGER = "ix.app.health.N_HUNGER"
    const val ACTION_END = "ix.app.health.N_END"
    const val ACTION_START = "ix.app.health.N_START"
    const val EXTRA_LEVEL = "level"
    const val EXTRA_NOTIF = "notif"

    private class Ev(val key: String, val at: Long, val kind: String, val arg: Int = 0)

    // ------------------------------------------------------------------
    // what is coming up
    // ------------------------------------------------------------------

    private fun events(repo: Repo, now: Long): List<Ev> {
        val out = ArrayList<Ev>()
        val r = repo.reminders.value
        val start = repo.fastStart.value
        if (start > 0L) {
            val goal = repo.goalHours.value
            val p = "f$start"
            for (st in fastingStages) {
                if (st.hour > 0) out.add(Ev("$p:stage${st.hour}", start + st.hour * HOUR_MS, "stage", st.hour))
            }
            if (goal > 0) {
                out.add(Ev("$p:half", start + goal * HOUR_MS / 2, "half"))
                out.add(Ev("$p:goal", start + goal * HOUR_MS, "goal"))
            }
            if (r.checkIns) {
                for (h in r.checkInOn) out.add(Ev("$p:ci$h", start + h * HOUR_MS, "checkin", h))
            }
            if (r.hydration) {
                val every = r.hydrationEvery.coerceAtLeast(1)
                val step = every * HOUR_MS
                val first = ((now - start) / step).toInt().coerceAtLeast(1)
                for (k in first..first + 2) out.add(Ev("$p:hy$k", start + k * step, "hydrate", k * every))
            }
        } else {
            val lastEnd = repo.fasts.value.maxOfOrNull { it.end } ?: 0L
            val plan = repo.goalFor(now)
            if (lastEnd > 0L && plan in 1..23) {
                val windowEnd = lastEnd + (24 - plan) * HOUR_MS
                val p = "w$lastEnd"
                if (r.windowClosing) out.add(Ev("$p:close", windowEnd - 30 * MIN, "close"))
                if (repo.reminderOn.value) out.add(Ev("$p:nudge", windowEnd - repo.reminderLead.value * MIN, "nudge"))
                if (r.mealReminders) {
                    out.add(Ev("$p:meal1", lastEnd + 60 * MIN, "meal1"))
                    out.add(Ev("$p:meal2", windowEnd - 45 * MIN, "meal2"))
                }
            }
            val sched = repo.scheduledStart.value
            if (sched > 0L) out.add(Ev("sched:$sched", sched, "start"))
        }
        return out
    }

    /** Called by the alarm: posts what is due, refreshes the timer notification, sets the next alarm. */
    fun tick(context: Context) {
        try {
            val app = context.applicationContext
            val repo = Repo.get(app)
            repo.applyScheduledStart()
            val now = System.currentTimeMillis()
            for (ev in events(repo, now)) {
                if (ev.kind == "start") continue
                if (ev.at > now + 30_000L || ev.at < now - 3 * HOUR_MS) continue
                if (repo.hasFired(ev.key)) continue
                repo.markFired(ev.key)
                if (repo.reminders.value.isQuiet(now)) continue
                fire(app, repo, ev, now)
            }
        } catch (e: Exception) {
            // alerts are a bonus, never crash because of them
        }
        update(context)
    }

    private fun schedule(app: Context, repo: Repo) {
        val am = app.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(app, ALARM_CODE, Intent(app, TickReceiver::class.java), FLAGS)
        val now = System.currentTimeMillis()
        var next = Long.MAX_VALUE
        for (ev in events(repo, now)) {
            if (ev.kind != "start" && repo.hasFired(ev.key)) continue
            if (ev.at > now && ev.at < next) next = ev.at
        }
        if (repo.reminders.value.timerNotif) {
            // keep the rings and bars in the timer notification fresh
            if (repo.fastStart.value > 0L) {
                val refresh = now + 15 * MIN
                if (refresh < next) next = refresh
            } else {
                val windowEnd = nextFastStart(repo, now)
                if (windowEnd > now) {
                    val refresh = minOf(now + 15 * MIN, windowEnd)
                    if (refresh < next) next = refresh
                }
            }
        }
        if (next == Long.MAX_VALUE) am.cancel(pi) else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
    }

    // ------------------------------------------------------------------
    // the ongoing timer notification
    // ------------------------------------------------------------------

    fun update(context: Context) {
        try {
            val app = context.applicationContext
            val nm = app.getSystemService(NotificationManager::class.java) ?: return
            val repo = Repo.get(app)
            val r = repo.reminders.value
            val start = repo.fastStart.value

            try {
                schedule(app, repo)
            } catch (e: Exception) {
            }

            if (start <= 0L) {
                for (id in listOf(ID_STAGE, ID_CHECKIN, ID_HYDRATE)) nm.cancel(id)
                if (r.timerNotif) postEating(app, repo, nm) else nm.cancel(ID_RUNNING)
                return
            }
            nm.cancel(ID_NUDGE)
            nm.cancel(ID_WINDOW)
            nm.cancel(ID_MEAL)
            if (!r.timerNotif) {
                nm.cancel(ID_RUNNING)
                return
            }
            postRunning(app, repo, nm, start)
        } catch (e: Exception) {
            // notifications are a bonus, never crash because of them
        }
    }

    private fun dp(app: Context, v: Float): Int = (v * app.resources.displayMetrics.density).roundToInt()

    private fun dayClock(t: Long): String = SimpleDateFormat("EEE HH:mm", Locale.getDefault()).format(Date(t))

    /**
     * Sets the big clock and the line under it. [fmtLeft], [fmtDone] and [fmtNone] are the Chronometer formats
     * for "goal still ahead", "goal passed" and "no goal"; %s is the running time.
     */
    private fun setClock(
        v: RemoteViews, clockId: Int, subId: Int, elapsed: Long, goal: Int, goalMs: Long, left: Long,
        fmtLeft: String, fmtDone: String, fmtNone: String,
    ) {
        val rt = SystemClock.elapsedRealtime()
        v.setChronometerCountDown(clockId, false)
        v.setChronometer(clockId, rt - elapsed, null, true)
        when {
            goal > 0 && left > 0 -> {
                v.setChronometerCountDown(subId, true)
                v.setChronometer(subId, rt + left, fmtLeft, true)
            }
            goal > 0 -> {
                v.setChronometerCountDown(subId, false)
                v.setChronometer(subId, rt - (elapsed - goalMs), fmtDone, true)
            }
            else -> {
                v.setChronometerCountDown(subId, false)
                v.setChronometer(subId, rt, fmtNone, false)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun postRunning(app: Context, repo: Repo, nm: NotificationManager, start: Long) {
        channels(nm)
        val now = System.currentTimeMillis()
        val goal = repo.goalHours.value
        val elapsed = (now - start).coerceAtLeast(0L)
        val idx = stageIndexFor(elapsed)
        val stage = fastingStages[idx]
        val next = fastingStages.getOrNull(idx + 1)
        val goalMs = goal * HOUR_MS
        val left = goalMs - elapsed
        val reached = goal > 0 && left <= 0
        val nothing = repo.style.value == 1
        val dark = NotifArt.isDark(app)
        val accent = NotifArt.accent(nothing)
        val frac = if (goal > 0) (elapsed.toFloat() / goalMs).coerceIn(0f, 1f) else (elapsed.toFloat() / DAY_MS).coerceIn(0f, 1f)
        val hours = (elapsed / HOUR_MS).toInt()

        // collapsed: ring, clock, one line
        val c = RemoteViews(app.packageName, if (nothing) R.layout.notif_collapsed_nothing else R.layout.notif_collapsed_classic)
        setClock(
            c, R.id.n_chrono, R.id.n_sub, elapsed, goal, goalMs, left,
            "${stage.name} · %s left", "Goal reached · +%s", "${stage.name} · no goal",
        )
        val ringPx = dp(app, 40f)
        if (nothing) {
            c.setImageViewBitmap(R.id.n_ring, NotifArt.dotRing(ringPx, frac, dark))
            c.setTextViewText(R.id.n_pct, "${hours}h")
        } else {
            c.setImageViewBitmap(R.id.n_ring, NotifArt.ring(ringPx, frac, accent))
            c.setTextViewText(R.id.n_pct, if (goal > 0) "${(frac * 100).toInt()}%" else "${hours}h")
        }

        // expanded: clock, stage, bar, what is next, why
        val x = RemoteViews(app.packageName, if (nothing) R.layout.notif_expanded_nothing else R.layout.notif_expanded_classic)
        if (nothing) {
            setClock(x, R.id.n_chrono, R.id.n_sub, elapsed, goal, goalMs, left, "%s", "+%s", "")
            x.setInt(R.id.n_pill, "setBackgroundResource", if (dark) R.drawable.widget_pill_white else R.drawable.widget_pill_black)
            val pillInk = if (dark) Color.BLACK else Color.WHITE
            x.setTextColor(R.id.n_sub, pillInk)
            x.setTextColor(R.id.n_pill_l, pillInk)
            x.setTextViewText(R.id.n_pill_l, if (reached) "OVER" else "LEFT")
            x.setViewVisibility(R.id.n_pill, if (goal > 0) View.VISIBLE else View.GONE)
            x.setTextViewText(R.id.n_label, if (reached) "GOAL REACHED" else "FASTED SO FAR")
        } else {
            setClock(x, R.id.n_chrono, R.id.n_sub, elapsed, goal, goalMs, left, "%s left", "Goal reached · +%s", "No goal")
        }
        x.setTextViewText(R.id.n_stage, stage.name)
        x.setTextViewText(R.id.n_next, if (next != null) "${next.name} · ${clock(start + next.hour * HOUR_MS)}" else "Last stage reached")
        x.setTextViewText(R.id.n_goal, if (goal > 0) dayClock(start + goalMs) else "No goal")
        val barW = dp(app, 340f)
        if (goal > 0) {
            val blocks = if (goal <= 24) goal else (goal + 1) / 2
            val bar = if (nothing) {
                val mark = when {
                    reached -> 35
                    next != null && next.hour < goal -> (next.hour.toFloat() / goal * 36).toInt().coerceIn(0, 35)
                    else -> -1
                }
                NotifArt.dotBar(barW, dp(app, 12f), frac, 36, mark, dark)
            } else {
                NotifArt.hourBar(barW, dp(app, 8f), frac, blocks, accent)
            }
            x.setImageViewBitmap(R.id.n_bar, bar)
            x.setTextViewText(R.id.n_end, if (nothing) "GOAL ${goal}H" else "${goal}h goal")
            for (id in listOf(R.id.n_bar, R.id.n_start, R.id.n_end)) x.setViewVisibility(id, View.VISIBLE)
        } else {
            for (id in listOf(R.id.n_bar, R.id.n_start, R.id.n_end)) x.setViewVisibility(id, View.GONE)
        }
        val reason = repo.reason.value
        val showWhy = repo.reminders.value.showReason && reason.isNotBlank()
        x.setViewVisibility(R.id.n_why, if (showWhy) View.VISIBLE else View.GONE)
        if (showWhy) x.setTextViewText(R.id.n_why, if (nothing) reason else "Why: $reason")
        if (nothing) x.setViewVisibility(R.id.n_why_l, if (showWhy) View.VISIBLE else View.GONE)

        val n = Notification.Builder(app, CH_RUNNING)
            .setSmallIcon(NotifArt.smallIcon(nothing, frac, if (reached) IconState.GOAL else IconState.RUN))
            .setColor(accent)
            .setSubText("Fasting " + planLabel(goal) + " · ongoing")
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(c)
            .setCustomBigContentView(x)
            .setShowWhen(false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPi(app, null))
            .addAction(0, "+ Water", actionPi(app, ACTION_WATER, ID_RUNNING))
            .addAction(0, "Check-in", openPi(app, "checkin"))
            .addAction(0, "End fast", actionPi(app, ACTION_END, ID_RUNNING))
            .build()
        nm.notify(ID_RUNNING, n)
    }

    /** While you are not fasting and the eating window is open, the same card shows how long is left. */
    @Suppress("DEPRECATION")
    private fun postEating(app: Context, repo: Repo, nm: NotificationManager) {
        val now = System.currentTimeMillis()
        val lastEnd = repo.fasts.value.maxOfOrNull { it.end } ?: 0L
        val windowEnd = nextFastStart(repo, now)
        if (lastEnd <= 0L || windowEnd <= now) {
            nm.cancel(ID_RUNNING)
            return
        }
        channels(nm)
        val nothing = repo.style.value == 1
        val dark = NotifArt.isDark(app)
        val accent = NotifArt.accent(nothing)
        val windowMs = windowEnd - lastEnd
        val windowH = (windowMs / HOUR_MS).toInt()
        val remaining = windowEnd - now
        val frac = ((now - lastEnd).toFloat() / windowMs).coerceIn(0f, 1f)
        val hoursLeft = (remaining / HOUR_MS).toInt()
        val rt = SystemClock.elapsedRealtime()
        val startsAt = clock(windowEnd)

        val c = RemoteViews(app.packageName, if (nothing) R.layout.notif_collapsed_nothing else R.layout.notif_collapsed_classic)
        c.setChronometerCountDown(R.id.n_chrono, true)
        c.setChronometer(R.id.n_chrono, rt + remaining, null, true)
        c.setChronometerCountDown(R.id.n_sub, false)
        c.setChronometer(R.id.n_sub, rt, "Eating window · next fast at $startsAt", false)
        val ringPx = dp(app, 40f)
        if (nothing) c.setImageViewBitmap(R.id.n_ring, NotifArt.dotRing(ringPx, frac, dark))
        else c.setImageViewBitmap(R.id.n_ring, NotifArt.ring(ringPx, frac, NotifArt.ink(dark)))
        c.setTextViewText(R.id.n_pct, "${hoursLeft}h")

        val x = RemoteViews(app.packageName, if (nothing) R.layout.notif_expanded_nothing else R.layout.notif_expanded_classic)
        x.setChronometerCountDown(R.id.n_chrono, true)
        x.setChronometer(R.id.n_chrono, rt + remaining, null, true)
        x.setTextViewText(R.id.n_stage, "Eating window")
        x.setTextViewText(R.id.n_next, startsAt)
        x.setTextViewText(R.id.n_goal, "${windowH}h")
        val barW = dp(app, 340f)
        if (nothing) {
            x.setTextViewText(R.id.n_label, "EATING WINDOW")
            x.setTextViewText(R.id.n_next_l, "FAST STARTS")
            x.setViewVisibility(R.id.n_pill, View.GONE)
            x.setViewVisibility(R.id.n_why, View.GONE)
            x.setViewVisibility(R.id.n_why_l, View.GONE)
            x.setImageViewBitmap(R.id.n_bar, NotifArt.dotBar(barW, dp(app, 12f), frac, 36, -1, dark))
            x.setTextViewText(R.id.n_end, "${windowH}H WINDOW")
        } else {
            x.setChronometerCountDown(R.id.n_sub, false)
            x.setChronometer(R.id.n_sub, rt, "Next fast at $startsAt", false)
            x.setTextViewText(R.id.n_next_l, "Fast starts")
            x.setTextViewText(R.id.n_goal_l, "Window")
            x.setViewVisibility(R.id.n_why, View.GONE)
            x.setImageViewBitmap(R.id.n_bar, NotifArt.hourBar(barW, dp(app, 8f), frac, windowH.coerceIn(1, 36), NotifArt.ink(dark)))
            x.setTextViewText(R.id.n_end, "${windowH}h window")
        }

        val n = Notification.Builder(app, CH_RUNNING)
            .setSmallIcon(NotifArt.smallIcon(nothing, frac, IconState.EAT))
            .setColor(accent)
            .setSubText("Eating window · ongoing")
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(c)
            .setCustomBigContentView(x)
            .setShowWhen(false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPi(app, null))
            .addAction(0, "Log meal", openPi(app, "log:Meal"))
            .addAction(0, "Start fast", actionPi(app, ACTION_START, ID_RUNNING))
            .build()
        nm.notify(ID_RUNNING, n)
    }

    // ------------------------------------------------------------------
    // alerts
    // ------------------------------------------------------------------

    private fun fire(app: Context, repo: Repo, ev: Ev, now: Long) {
        val r = repo.reminders.value
        val start = repo.fastStart.value
        when (ev.kind) {
            "stage" -> if (r.stageAlerts && start > 0L) {
                val st = fastingStages.lastOrNull { it.hour == ev.arg } ?: return
                val why = whyLine(repo)
                alert(
                    app, ID_STAGE, "${st.name} · ${st.hour} hours in",
                    st.text + " What helps: " + st.helps.joinToString(", ").lowercase() + "." + why,
                    listOf(Triple("Log salts", openPi(app, "log:Electrolytes"), 0), Triple("See stage", openPi(app, "stages"), 0)),
                    NotifArt.glyphFor(st.hour),
                )
            }
            "half" -> if (r.halfwayGoal && start > 0L) {
                alert(app, ID_GOAL, "Halfway there", "You're ${repo.goalHours.value / 2} hours into your ${planLabel(repo.goalHours.value)} fast." + whyLine(repo), emptyList())
            }
            "goal" -> if (r.halfwayGoal && start > 0L) {
                alert(app, ID_GOAL, "Goal reached", "You've finished your " + planLabel(repo.goalHours.value) + " fast. Nice work!" + whyLine(repo), emptyList())
            }
            "checkin" -> if (start > 0L) {
                alert(
                    app, ID_CHECKIN, "Hour ${ev.arg}. How hungry are you?", "",
                    listOf(
                        Triple("Not much", actionPi(app, ACTION_HUNGER, ID_CHECKIN, 1), 0),
                        Triple("Some", actionPi(app, ACTION_HUNGER, ID_CHECKIN, 3), 0),
                        Triple("A lot", actionPi(app, ACTION_HUNGER, ID_CHECKIN, 5), 0),
                    ),
                )
            }
            "hydrate" -> if (start > 0L) {
                val today = System.currentTimeMillis() - DAY_MS
                val water = repo.sum(Types.WATER, maxOf(start, today))
                val sodium = repo.sum(Types.SODIUM, start)
                val elapsedDays = (now - start) / DAY_MS.toDouble()
                val behind = sodium < repo.targets.value.sodium * elapsedDays * 0.8
                alert(
                    app, ID_HYDRATE, "Time for water",
                    String.format(Locale.US, "%.1f of %.1f L so far.", water / 1000.0, repo.waterGoal.value / 1000.0) +
                        (if (behind) " You're behind on salts too." else ""),
                    listOf(
                        Triple("+ 250 ml", actionPi(app, ACTION_WATER, ID_HYDRATE), 0),
                        Triple("Log salts", openPi(app, "log:Electrolytes"), 0),
                    ),
                )
            }
            "close" -> if (start <= 0L) {
                val startsAt = nextFastStart(repo, now)
                alert(
                    app, ID_WINDOW, "Window closes in 30 minutes",
                    (if (startsAt > 0L) "Your fast starts at ${clock(startsAt)}. " else "") + "Finish eating, then log your last meal.",
                    listOf(Triple("Log last meal", openPi(app, "log:Meal"), 0), Triple("Start now", actionPi(app, ACTION_START, ID_WINDOW), 0)),
                )
            }
            "nudge" -> if (start <= 0L) {
                val startsAt = nextFastStart(repo, now)
                alert(
                    app, ID_NUDGE, "Last-meal reminder",
                    if (startsAt > 0L) "Time to wrap up your last meal. Your fast starts at ${clock(startsAt)}." else "Time to wrap up your last meal.",
                    listOf(Triple("Log last meal", openPi(app, "log:Meal"), 0)),
                )
            }
            "meal1", "meal2" -> if (start <= 0L) {
                val lastEnd = repo.fasts.value.maxOfOrNull { it.end } ?: 0L
                val meals = repo.count(Types.MEAL, lastEnd)
                val need = if (ev.kind == "meal1") meals == 0 else meals < 2
                if (need) {
                    alert(
                        app, ID_MEAL,
                        if (ev.kind == "meal1") "Log your first meal" else "Log your last meal",
                        "It helps your journal and your insights.",
                        listOf(Triple("Log meal", openPi(app, "log:Meal"), 0)),
                    )
                }
            }
        }
    }

    private fun nextFastStart(repo: Repo, now: Long): Long {
        val lastEnd = repo.fasts.value.maxOfOrNull { it.end } ?: 0L
        val plan = repo.goalFor(now)
        return if (lastEnd > 0L && plan in 1..23) lastEnd + (24 - plan) * HOUR_MS else 0L
    }

    private fun whyLine(repo: Repo): String {
        val reason = repo.reason.value
        return if (repo.reminders.value.showReason && reason.isNotBlank()) "\nWhy: $reason" else ""
    }

    @Suppress("DEPRECATION")
    private fun alert(
        app: Context, id: Int, title: String, text: String, actions: List<Triple<String, PendingIntent, Int>>,
        glyph: String? = null,
    ) {
        try {
            val nm = app.getSystemService(NotificationManager::class.java) ?: return
            channels(nm)
            val repo = Repo.get(app)
            val nothing = repo.style.value == 1
            val b = Notification.Builder(app, CH_ALERTS)
                .setSmallIcon(alertIcon(repo, nothing))
                .setColor(NotifArt.accent(nothing))
                .setContentTitle(title)
                .setAutoCancel(true)
                .setContentIntent(openPi(app, null))
            if (glyph != null) b.setLargeIcon(NotifArt.glyphBitmap(app, nothing, glyph))
            if (text.isNotEmpty()) {
                b.setContentText(text.lineSequence().first())
                b.setStyle(Notification.BigTextStyle().bigText(text))
            }
            for ((label, pi, _) in actions) b.addAction(0, label, pi)
            nm.notify(id, b.build())
        } catch (e: Exception) {
        }
    }

    /** The status bar icon for an alert: the ring as it stands now, or the eating-window ring. */
    private fun alertIcon(repo: Repo, nothing: Boolean): Icon {
        val start = repo.fastStart.value
        if (start <= 0L) return NotifArt.smallIcon(nothing, 0f, IconState.EAT)
        val goal = repo.goalHours.value
        val elapsed = (System.currentTimeMillis() - start).coerceAtLeast(0L)
        val goalMs = goal * HOUR_MS
        val reached = goal > 0 && elapsed >= goalMs
        val frac = if (goal > 0) (elapsed.toFloat() / goalMs).coerceIn(0f, 1f) else (elapsed.toFloat() / DAY_MS).coerceIn(0f, 1f)
        return NotifArt.smallIcon(nothing, frac, if (reached) IconState.GOAL else IconState.RUN)
    }

    private fun channels(nm: NotificationManager) {
        nm.createNotificationChannel(NotificationChannel(CH_RUNNING, "Fasting timer", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, "Fasting alerts", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun clock(t: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))

    // ------------------------------------------------------------------
    // intents
    // ------------------------------------------------------------------

    /** Opens the app, optionally straight to something ("stages", "checkin", "log:Meal"). */
    fun openPi(app: Context, what: String?): PendingIntent {
        val intent = Intent(app, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (what != null) intent.putExtra(MainActivity.EXTRA_OPEN, what)
        return PendingIntent.getActivity(app, 1000 + (what?.hashCode() ?: 0).and(0xFFFF), intent, FLAGS)
    }

    private fun actionPi(app: Context, action: String, notifId: Int, level: Int = 0): PendingIntent {
        val intent = Intent(app, NotifActionReceiver::class.java)
            .setAction(action)
            .putExtra(EXTRA_NOTIF, notifId)
            .putExtra(EXTRA_LEVEL, level)
        return PendingIntent.getBroadcast(app, 2000 + action.hashCode().and(0xFFF) * 8 + level, intent, FLAGS)
    }
}

/** Fires when the next alert is due. */
class TickReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.tick(context)
    }
}

/** The buttons on notifications that save something without opening the app. */
class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val app = context.applicationContext
            val repo = Repo.get(app)
            when (intent.action) {
                Notifier.ACTION_WATER -> repo.addEntry(Types.WATER, 250.0, source = "notification")
                Notifier.ACTION_HUNGER -> repo.addEntry(Types.HUNGER, intent.getIntExtra(Notifier.EXTRA_LEVEL, 3).toDouble(), source = "notification")
                Notifier.ACTION_END -> repo.endFast()
                Notifier.ACTION_START -> repo.startFast()
            }
            val id = intent.getIntExtra(Notifier.EXTRA_NOTIF, 0)
            if (id != 1) {
                app.getSystemService(NotificationManager::class.java)?.cancel(id)
            }
        } catch (e: Exception) {
        }
    }
}

/** Kept so alarms set by older versions still land somewhere. */
class GoalReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.tick(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Widgets.updateAll(context)
    }
}
