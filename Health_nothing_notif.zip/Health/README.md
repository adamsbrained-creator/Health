# Health

Personal Android app (Kotlin, Jetpack Compose). Package: `ix.app.health`.

- **Fasting**: any plan (11:13 to 72h, or Flexi), ring timer with fasting stages, notification with live timer and goal alert, editable start, weekly streak, History (stats, chart, add/edit/delete fasts)
- **Stats**: weight chart, water / sleep / workouts / fasts, recent entries (widget entries are tagged)
- **Exercises**: built-in exercise base with search, categories and how-to steps
- **Widgets**: Quick log, Water, Fasting (long-press home screen > Widgets > Health)
- **Settings**: accent colour, daily water goal, add-widget buttons

## Build on GitHub

1. Put these files in a repo (the `.github/workflows/build.yml` file must be in the repo),
   or upload `Health.zip` to the repo root next to `.github/workflows/build.yml`.
2. Push to `main` (or run the workflow by hand from the Actions tab).
3. Download `Health.apk` from the Releases page and install it.

## About the signing key

`keystore/health.jks` is a **temporary** key, committed on purpose, with the password `healthtemp`
(alias `health`). It only exists so that every new build is signed the same way and installs over
the previous one. If this app is ever published, generate a new private key, keep it out of the
repo, store it as GitHub secrets, and delete this one. Note that apps signed with a different key
cannot be updated in place, so the old install would have to be removed first.


## Fasting update

The Fasting tab follows the new mock-ups:

- **Timer / Journal / Insights** tabs. Journal and Insights reuse the old History screen (fast list and logs, stats and chart).
- **Eating window** view with a last-meal reminder, planned start, last fast, streak with a weekly grace day, and a three-step checklist.
- **Fasting ring** with stage markers, next-up card, quick log tiles, "Right now" with what you may feel and what helps, a "During this fast" tracker for water and electrolytes, and a reason card. A **Focus** layout is available in Settings.
- **Stages** screen, **Plans** screen (custom plans per weekday, programs, plan groups, safety check for long fasts) and **Program** screen.
- **Log sheet**: water, electrolytes, coffee and tea, ketones, glucose, weight, waist, sleep, meal and note.

### Second batch (mock-ups 8 to 13)

- **Check-in** sheet: hunger, energy, mood, symptoms, and an "end fast gently" suggestion when you feel dizzy.
- **Fast complete** summary after a fast ends: totals, averages, how it felt, a note, streak and a break-the-fast guide.
- **Journal**: week strip with daily bars, a month calendar, and a day view with fasts, check-ins, meals, water and electrolytes, body and blood, workouts and notes.
- **Insights**: week, month and year ranges, hours chart, hunger and energy by hour, next-day energy by fast length, a 12-week heat map and "what we noticed".
- **Reminders** (Settings): nudges, stage alerts, check-in prompts, hydration, quiet hours, meal reminders, safety options and widgets.
- **Notifications**: a live timer notification with buttons, plus stage, check-in, hydration and eating-window alerts.
- **Widgets**: new Timer ring, and Fasting, Water and Quick log restyled to the mock-ups.


## Nothing style

Settings > Style > **Nothing** switches the whole app to a style based on the Nothing OS Weather app. Pick **Classic** to go back.

- Always black with off-white ink and grey cards, whatever the phone's light or dark setting. The accent colour is not used.
- Big numbers (timer, time left, plan ratio, totals, weight) are drawn as **dot-matrix numerals**. No font file is needed.
- Page titles are light serif. Cards and buttons are rounder, the tab bar is a floating pill.
- The fasting ring is a **ring of dots**. Stage markers sit on it and the current stage is the one red dot.
- "Why I'm fasting" becomes the one light tile on the Fasting screen, so your reason is always in sight.
- Not changed yet: the home-screen widgets keep their current look.

## Notification and status bar icon

Both follow Settings > Style, so Classic and Nothing each get their own look.

- **Status bar icon** (drawn in `widget/NotifArt.kt`): a progress ring that fills toward your goal. Nothing style uses a ring of 12 dots. It shows three states: running, goal reached (full ring with a check) and eating window (dashed ring / alternate dots). Faded parts are see-through, because the status bar only draws shapes in white.
- **Collapsed card**: ring, clock and one line ("Switching to fat · 4:52:03 left"). It stays within the height Android allows for the collapsed card.
- **Expanded card** (pull it open): clock, stage, hour blocks (Classic) or a dotted bar with a red dot on the next stage (Nothing), next stage, goal time and your reason. The buttons (Water, Check-in, End fast) are the system's own buttons under the card.
- **Eating window**: when you are not fasting and a window is open, the same card shows the time left in it, with Log meal and Start fast. It follows the "Fasting timer" switch on the Reminders screen.
- **Stage alerts** show a small picture: a fork, drop, bolt or flame (dots in Nothing style).
- The clock in the Nothing card uses a small dot-matrix font, `res/font/healthdot.ttf`, made for this app (digits, `:`, `+`, `-`, `.`, `h`, `m`, `s`).
- The rings and bars are pictures, refreshed about every 15 minutes. The clock itself ticks live.
