package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.Types
import kotlinx.coroutines.delay

@Composable
fun StagesScreen(repo: Repo, onBack: () -> Unit) {
    val start by repo.fastStart.collectAsState()
    val entries by repo.entries.collectAsState()
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(1000L)
            value = System.currentTimeMillis()
        }
    }
    val fasting = start > 0L
    val elapsed = if (fasting) (now - start).coerceAtLeast(0L) else 0L
    val cur = if (fasting) stageIndexFor(elapsed) else -1
    val total = fastingStages.size
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.outlineVariant
    val line = MaterialTheme.colorScheme.outline

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 8.dp, bottom = 24.dp),
    ) {
        Box(Modifier.offset(x = (-12).dp)) { BackRow(onBack) }
        Sub(if (fasting) "You are at ${fmtDur(elapsed)}" else "You are not fasting right now")
        NTitle("Fasting stages")

        Spacer(Modifier.height(16.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        if (fasting) "Stage ${cur + 1} of $total" else "$total stages",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    val nxt = fastingStages.getOrNull(cur + 1)
                    if (fasting && nxt != null) {
                        Sub("Next at ${nxt.hour}h · in ${fmtDur(nxt.hour * HOUR_MS - elapsed)}", size = 13)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (i in 0 until total) {
                        Box(
                            Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (i <= cur) primary else track),
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        for (i in 0 until total) {
            val st = fastingStages[i]
            val reached = i <= cur
            val current = i == cur
            val isLast = i == total - 1
            val stageStart = start + st.hour * HOUR_MS
            val stageEnd = if (isLast) Long.MAX_VALUE else start + fastingStages[i + 1].hour * HOUR_MS

            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Column(
                    modifier = Modifier.width(24.dp).fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    when {
                        current -> Box(
                            Modifier
                                .size(28.dp)
                                .offset(y = (-2).dp)
                                .clip(CircleShape)
                                .background(primary)
                                .border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape),
                        )
                        reached -> Box(
                            Modifier.size(24.dp).clip(CircleShape).background(primary),
                            contentAlignment = Alignment.Center,
                        ) { FIcon(R.drawable.ic_check, size = 14.dp, tint = MaterialTheme.colorScheme.onPrimary) }
                        else -> Box(
                            Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .border(2.5.dp, if (i == cur + 1) NodeStroke else line, CircleShape),
                        )
                    }
                    if (!isLast) {
                        Box(
                            Modifier
                                .width(3.dp)
                                .weight(1f)
                                .background(if (i < cur) primary else track),
                        )
                    }
                }
                Column(Modifier.weight(1f).padding(bottom = 18.dp)) {
                    if (current) {
                        SoftCard(Modifier.fillMaxWidth().offset(y = (-6).dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Bottom,
                                ) {
                                    Text(st.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                    Sub("${st.hour}h", size = 13)
                                }
                                Spacer(Modifier.height(6.dp))
                                Box(
                                    Modifier
                                        .clip(RoundedCornerShape(50))
                                        .background(primary)
                                        .padding(horizontal = 10.dp, vertical = 3.dp),
                                ) {
                                    Text("You are here", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                                }
                                Spacer(Modifier.height(10.dp))
                                Sub(st.text, size = 14)
                                Spacer(Modifier.height(12.dp))
                                StageDetails(st)
                            }
                        }
                    } else {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom,
                        ) {
                            Text(
                                st.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (reached) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Sub("${st.hour}h", size = 13)
                        }
                        val extra = StringBuilder()
                        if (reached) {
                            extra.append("Reached ").append(fmtDayClock(stageStart))
                            val hunger = entries.filter { it.type == Types.HUNGER && it.time >= stageStart && it.time < stageEnd }
                            if (hunger.isNotEmpty()) {
                                extra.append(" · hunger check-in logged ").append(fmtNum(hunger.last().value))
                            }
                            val asleep = entries.any {
                                it.type == Types.SLEEP &&
                                    it.time - (it.value * HOUR_MS).toLong() <= stageStart && stageStart <= it.time
                            }
                            if (asleep) extra.append(" · asleep")
                        } else {
                            extra.append(st.text)
                            if (fasting && i == cur + 1) extra.append(" In ").append(fmtDur(st.hour * HOUR_MS - elapsed)).append(".")
                        }
                        Sub(extra.toString(), Modifier.padding(top = 2.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top,
            ) {
                FIcon(R.drawable.ic_warn, size = 22.dp, tint = TrackAmber)
                Text(
                    "Long fasts need care. Past 24 hours, talk to a doctor first, keep up water and salts, and break the fast gently.",
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Sub("A general timeline. It varies from person to person and is not medical advice.", size = 11)
    }
}
