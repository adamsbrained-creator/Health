package ix.app.health.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.Reminders
import ix.app.health.data.planGoalFor
import ix.app.health.widget.FastingWidget
import ix.app.health.widget.QuickLogWidget
import ix.app.health.widget.RingWidget
import ix.app.health.widget.WaterWidget
import ix.app.health.widget.Widgets

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RemindersScreen(repo: Repo, onBack: () -> Unit) {
    val rem by repo.reminders.collectAsState()
    val nudgeOn by repo.reminderOn.collectAsState()
    val lead by repo.reminderLead.collectAsState()
    val reason by repo.reason.collectAsState()
    val fasts by repo.fasts.collectAsState()
    val base by repo.baseGoal.collectAsState()
    val same by repo.samePlan.collectAsState()
    val plans by repo.plans.collectAsState()
    val program by repo.program.collectAsState()
    val ctx = LocalContext.current

    var addHour by remember { mutableStateOf<Int?>(null) }
    var quiet by remember { mutableStateOf(false) }
    var editReason by remember { mutableStateOf(false) }
    var widgets by remember { mutableStateOf(false) }
    var pinMessage by remember { mutableStateOf<String?>(null) }

    val now = System.currentTimeMillis()
    val plan = planGoalFor(now, base, same, plans, program)
    val lastEnd = fasts.maxOfOrNull { it.end } ?: 0L
    val startsAt = if (lastEnd > 0L && plan in 1..23) lastEnd + (24 - plan) * HOUR_MS else 0L
    val startText = if (startsAt > 0L) fmtClock(startsAt) else "20:00"
    val onSurface = MaterialTheme.colorScheme.onSurface

    fun upd(f: (Reminders) -> Reminders) = repo.updateReminders(f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 8.dp, bottom = 32.dp),
    ) {
        Box(Modifier.offset(x = (-12).dp)) { BackRow(onBack) }
        Sub("Settings · Fasting")
        NTitle("Reminders")

        // ---- before ----
        Header("Before a fast")
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                ToggleRow("Last-meal nudge", "$lead min before your fast starts", nudgeOn) { repo.setReminderOn(it) }
                if (nudgeOn) {
                    Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (m in listOf(5, 10, 15, 30)) Pill("$m min", lead == m) { repo.setReminderLead(m) }
                    }
                }
                Divider()
                ValueRow(
                    "Fast starts",
                    if (plan in 1..23) "Follows your plan: ${24 - plan}h after your last fast ends" else "Set a plan with an eating window to see this",
                    startText,
                )
            }
        }

        // ---- during ----
        Header("During a fast")
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                ToggleRow("Timer on lock screen", "A live notification with time, stage and quick buttons", rem.timerNotif) { v -> upd { it.copy(timerNotif = v) } }
                Divider()
                ToggleRow("New stage reached", "A short note on what is happening in your body", rem.stageAlerts) { v -> upd { it.copy(stageAlerts = v) } }
                Divider()
                ToggleRow(
                    "Halfway and goal reached",
                    if (plan > 0) "At ${plan / 2}h and at ${plan}h for this plan" else "Once you set a goal",
                    rem.halfwayGoal,
                ) { v -> upd { it.copy(halfwayGoal = v) } }
                Divider()
                ToggleRow("Check-in prompts", "Hunger, energy and mood at these hours", rem.checkIns) { v -> upd { it.copy(checkIns = v) } }
                FlowRow(
                    Modifier.padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for (h in rem.checkInChoices.sorted()) {
                        Pill("${h}h", h in rem.checkInOn) {
                            upd { r -> r.copy(checkInOn = if (h in r.checkInOn) r.checkInOn - h else r.checkInOn + h) }
                        }
                    }
                    Box(
                        Modifier
                            .height(40.dp)
                            .clip(RoundedCornerShape(50))
                            .border(1.5.dp, NodeStroke, RoundedCornerShape(50))
                            .clickable { addHour = 8 }
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center,
                    ) { Sub("Add", size = 14) }
                }
                Divider()
                ToggleRow("Hydration nudge", "Water, plus salts if you are behind your target", rem.hydration) { v -> upd { it.copy(hydration = v) } }
                Row(Modifier.padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Sub("Every", size = 13)
                    for (e in listOf(1, 2, 3)) Pill("${e}h", rem.hydrationEvery == e) { upd { it.copy(hydrationEvery = e) } }
                }
                Divider()
                ValueRow(
                    "Quiet hours", "No nudges while you sleep; the timer stays",
                    if (rem.quietOn) fmtMinOfDay(rem.quietStart) + " – " + fmtMinOfDay(rem.quietEnd) else "Off",
                ) { quiet = true }
            }
        }

        // ---- after ----
        Header("After a fast")
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                ToggleRow("Break-your-fast guide", "Show the gentle-eating tips when a fast ends", rem.breakGuide) { v -> upd { it.copy(breakGuide = v) } }
                Divider()
                ToggleRow("Eating window closing", "30 min before the window ends", rem.windowClosing) { v -> upd { it.copy(windowClosing = v) } }
                Divider()
                ToggleRow("Remind me to log meals", "First and last meal of the window", rem.mealReminders) { v -> upd { it.copy(mealReminders = v) } }
            }
        }

        // ---- keep it in sight ----
        Header("Keep it in sight")
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Column(Modifier.fillMaxWidth().clickable { editReason = true }.padding(vertical = 12.dp)) {
                    Sub("Why I'm fasting", size = 13)
                    Box(
                        Modifier
                            .padding(top = 6.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.outlineVariant)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    ) {
                        Text(
                            if (reason.isBlank()) "Add a reason that keeps you going" else reason,
                            fontSize = 14.sp,
                            color = if (reason.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else onSurface,
                        )
                    }
                }
                Divider()
                ToggleRow("Show it in notifications", "Under the timer and on stage alerts", rem.showReason) { v -> upd { it.copy(showReason = v) } }
                Divider()
                Row(
                    Modifier.fillMaxWidth().clickable { widgets = true }.padding(vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Widgets", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = onSurface)
                        Sub("Timer ring, quick log and water", size = 12)
                    }
                    FIcon(R.drawable.ic_chev_right, size = 18.dp, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // ---- safety ----
        Header("Safety")
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                ToggleRow("Safety check before long fasts", "Quick questions before any fast of 24h or more", rem.safetyCheck) { v -> upd { it.copy(safetyCheck = v) } }
                Divider()
                ToggleRow("Suggest ending when dizzy", "If a check-in reports dizziness or fainting", rem.suggestEnd) { v -> upd { it.copy(suggestEnd = v) } }
            }
        }
        Spacer(Modifier.height(14.dp))
        Sub(
            "This app is not medical advice. Check with a doctor before fasting, especially if you take medication, are pregnant, or have a health condition.",
            size = 11,
        )
    }

    // ---- dialogs ----
    val ah = addHour
    if (ah != null) {
        AlertDialog(
            onDismissRequest = { addHour = null },
            title = { Text("Add a check-in hour") },
            text = {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    RepeatStepButton("−") { addHour = (ah - 1).coerceAtLeast(1) }
                    Text("${ah}h", fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.width(96.dp))
                    RepeatStepButton("+") { addHour = (ah + 1).coerceAtMost(72) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    upd { r ->
                        r.copy(
                            checkInChoices = (r.checkInChoices + ah).distinct().sorted(),
                            checkInOn = (r.checkInOn + ah).distinct().sorted(),
                        )
                    }
                    addHour = null
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { addHour = null }) { Text("Cancel") } },
        )
    }

    if (quiet) {
        AlertDialog(
            onDismissRequest = { quiet = false },
            title = { Text("Quiet hours") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("On", rem.quietOn) { upd { it.copy(quietOn = true) } }
                        Pill("Off", !rem.quietOn) { upd { it.copy(quietOn = false) } }
                    }
                    if (rem.quietOn) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Sub("From")
                                Text(fmtMinOfDay(rem.quietStart), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                RepeatStepButton("−") { upd { it.copy(quietStart = (it.quietStart - 30 + 1440) % 1440) } }
                                RepeatStepButton("+") { upd { it.copy(quietStart = (it.quietStart + 30) % 1440) } }
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Sub("Until")
                                Text(fmtMinOfDay(rem.quietEnd), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                RepeatStepButton("−") { upd { it.copy(quietEnd = (it.quietEnd - 30 + 1440) % 1440) } }
                                RepeatStepButton("+") { upd { it.copy(quietEnd = (it.quietEnd + 30) % 1440) } }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { quiet = false }) { Text("Done") } },
        )
    }

    if (editReason) {
        var text by remember { mutableStateOf(reason) }
        AlertDialog(
            onDismissRequest = { editReason = false },
            title = { Text("Why I'm fasting") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    placeholder = { Text("A reason that keeps you going") },
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    repo.setReason(text)
                    editReason = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editReason = false }) { Text("Cancel") } },
        )
    }

    if (widgets) {
        AlertDialog(
            onDismissRequest = { widgets = false },
            title = { Text("Add a widget") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    WidgetOption(ctx, "Timer ring", "2 × 2", RingWidget::class.java) { widgets = false; pinMessage = it }
                    WidgetOption(ctx, "Fasting", "4 × 2, with stage and buttons", FastingWidget::class.java) { widgets = false; pinMessage = it }
                    WidgetOption(ctx, "Water", "2 × 2, +250 ml", WaterWidget::class.java) { widgets = false; pinMessage = it }
                    WidgetOption(ctx, "Quick log", "2 × 2, four buttons", QuickLogWidget::class.java) { widgets = false; pinMessage = it }
                }
            },
            confirmButton = { TextButton(onClick = { widgets = false }) { Text("Close") } },
        )
    }

    val pm = pinMessage
    if (pm != null) {
        AlertDialog(
            onDismissRequest = { pinMessage = null },
            text = { Text(pm) },
            confirmButton = { TextButton(onClick = { pinMessage = null }) { Text("OK") } },
        )
    }
}

@Composable
private fun WidgetOption(ctx: Context, name: String, sub: String, cls: Class<*>, done: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable {
                val ok = Widgets.requestPin(ctx, cls)
                done(if (ok) "Your launcher will ask where to place it." else "Your launcher can't add widgets from here. Long-press the home screen and pick Health.")
            }
            .padding(vertical = 10.dp),
    ) {
        Text(name, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Sub(sub, size = 12)
    }
}

@Composable
private fun Header(text: String) {
    Text(
        text.uppercase(),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 22.dp, bottom = 8.dp),
    )
}

@Composable
private fun Divider() {
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Sub(sub, size = 12)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
            ),
        )
    }
}

@Composable
private fun ValueRow(title: String, sub: String, value: String, onClick: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Sub(sub, size = 12)
        }
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.outlineVariant)
                .padding(horizontal = 12.dp, vertical = 7.dp),
        ) { Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface) }
    }
}
