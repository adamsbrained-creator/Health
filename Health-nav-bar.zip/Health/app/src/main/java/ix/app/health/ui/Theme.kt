package ix.app.health.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import ix.app.health.data.Repo
import androidx.compose.ui.graphics.Color

val HealthRed = Color(0xFFFF2D3F)

val TrackBlue = Color(0xFF2F86F0)
val TrackAmber = Color(0xFFD97706)
val TrackPurple = Color(0xFFA855E0)
val DarkRed = Color(0xFF7A1F2A)
val NodeStroke = Color(0xFF636366)

/** Nothing style: the one red, used for "you are here" marks and warnings only. */
val NothingRed = Color(0xFFD71921)
/** Nothing style: off-white used for inverted tiles and selected pills. */
val NothingInk = Color(0xFFF0F0F0)

/** True while the Nothing style is selected in Settings. */
val LocalNothing = compositionLocalOf { false }

@Composable
fun isNothing(): Boolean = LocalNothing.current

/** Accent colours you can pick in Settings. Index 0 (red, the icon's heart) is the default. */
data class Accent(val name: String, val color: Color?)

val Accents = listOf(
    Accent("Red", HealthRed),
    Accent("Orange", Color(0xFFFF9500)),
    Accent("Green", Color(0xFF30B350)),
    Accent("Blue", Color(0xFF0A84FF)),
    Accent("Purple", Color(0xFFAF52DE)),
    Accent("Pink", Color(0xFFFF4F9A)),
    Accent("Mono", null),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF000000),
    onPrimary = Color(0xFFFFFFFF),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF000000),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF000000),
    surfaceVariant = Color(0xFFF2F2F7),
    onSurfaceVariant = Color(0xFF6C6C70),
    outline = Color(0xFFC7C7CC),
    outlineVariant = Color(0xFFE5E5EA),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFFFFF),
    onPrimary = Color(0xFF000000),
    background = Color(0xFF000000),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF1C1C1E),
    onSurfaceVariant = Color(0xFF98989D),
    outline = Color(0xFF48484A),
    outlineVariant = Color(0xFF2C2C2E),
)

/** Nothing style: always black, off-white ink, grey cards. Sheets and dialogs use the card grey. */
private val NothingColors = darkColorScheme(
    primary = NothingInk,
    onPrimary = Color(0xFF000000),
    background = Color(0xFF000000),
    onBackground = NothingInk,
    surface = Color(0xFF1C1C1C),
    onSurface = NothingInk,
    surfaceVariant = Color(0xFF1C1C1C),
    onSurfaceVariant = Color(0xFF9A9A9A),
    outline = Color(0xFF5A5A5A),
    outlineVariant = Color(0xFF2E2E2E),
)

@Composable
fun HealthTheme(content: @Composable () -> Unit) {
    val repo = Repo.get(LocalContext.current)
    val index by repo.accent.collectAsState()
    val style by repo.style.collectAsState()
    val nothing = style == 1
    val dark = nothing || isSystemInDarkTheme()
    val scheme = if (nothing) {
        NothingColors
    } else {
        val base = if (dark) DarkColors else LightColors
        val accent = Accents.getOrNull(index)?.color
        if (accent == null) base else base.copy(primary = accent, onPrimary = Color.White)
    }

    // Keep the clock and battery icons readable: Nothing style is dark even when the phone is light.
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val bars = WindowCompat.getInsetsController(window, view)
            bars.isAppearanceLightStatusBars = !dark
            bars.isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(LocalNothing provides nothing) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** Fill of the selected tab in a segmented control. */
@Composable
fun segmentSelected(): Color =
    if (isNothing()) NothingInk
    else if (isSystemInDarkTheme()) Color(0xFF3A3A3C)
    else Color.White
