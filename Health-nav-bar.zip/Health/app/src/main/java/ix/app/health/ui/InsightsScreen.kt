package ix.app.health.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.Entry
import ix.app.health.data.FastRecord
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.Types
import ix.app.health.data.addDays
import ix.app.health.data.dayStart
import ix.app.health.data.weekStart
import ix.app.health.data.weekdayIndex
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val MidRed = Color(0xFFB02634)
private val LowRed = Color(0xFF6B1E27)

fun insightsRangeText(range: Int): String = when (range) {
    0 -> "Last 7 days"
    1 -> "Last 30 days"
    else -> "Last 12 months"
}

private fun hourSeries(type: String, fasts: List<FastRecord>, entries: List<Entry>): List<Double?> {
    val sums = DoubleArray(11)
    val cnt = IntArray(11)
    for (e in entries) {
        if (e.type != type) continue
        val f = fasts.firstOrNull { e.time >= it.start && e.time <= it.end } ?: continue
        val h = (e.time - f.start) / HOUR_MS.toDouble()
        if (h > 21.0) continue
        val b = Math.round(h / 2.0).toInt().coerceIn(0, 10)
        sums[b] += e.value
        cnt[b]++
    }
    return (0..10).map { if (cnt[it] == 0) null else sums[it] / cnt[it] }
}

private val buckets = listOf("Under 14h" to 0..13, "14–16h" to 14..15, "16–18h" to 16..17, "18–20h" to 18..19, "20h +" to 20..999)

@Composable
fun InsightsScreen(repo: Repo, range: Int, onRange: (Int) -> Unit) {
    val fasts by repo.fasts.collectAsState()
    val entries by repo.entries.collectAsState()
    val start by repo.fastStart.collectAsState()
    val goalCur by repo.goalHours.collectAsState()
    val base by repo.baseGoal.collectAsState()
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(60_000L)
            value = System.currentTimeMillis()
        }
    }

    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val today = dayStart(now)
    val live = if (start > 0L) FastRecord(start, now, goalCur) else null
    val all = if (live != null) fasts + live else fasts
    val goalLine = if (base > 0) minOf(base, 24) else 16

    val days = when (range) { 0 -> 7; 1 -> 30; else -> 365 }
    val from = addDays(today, -(days - 1))
    val prevFrom = addDays(from, -days)
    val inPeriod = fasts.filter { it.end >= from && it.end <= now }
    val inPrev = fasts.filter { it.end >= prevFrom && it.end < from }
    val avg = if (inPeriod.isEmpty()) 0L else inPeriod.sumOf { it.duration } / inPeriod.size
    val avgPrev = if (inPrev.isEmpty()) 0L else inPrev.sumOf { it.duration } / inPrev.size
    val hit = inPeriod.count { it.completed }
    val longest = inPeriod.maxByOrNull { it.duration }
    val prevWord = when (range) { 0 -> "last week"; 1 -> "last month"; else -> "last year" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 8.dp, bottom = 24.dp),
    ) {
        Box(Modifier.width(240.dp)) { Segmented(listOf("Week", "Month", "Year"), range, onRange) }

        // ---- tiles ----
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InsightTile("Fasts", if (inPeriod.isEmpty()) "—" else "${inPeriod.size}", "of $days days", Modifier.weight(1f))
            InsightTile(
                "Average fast", if (inPeriod.isEmpty()) "—" else fmtDur(avg),
                if (inPeriod.isEmpty() || inPrev.isEmpty()) "No earlier data"
                else (if (avg >= avgPrev) "+" else "−") + fmtDur(kotlin.math.abs(avg - avgPrev)) + " vs $prevWord",
                Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InsightTile(
                "Goal hit", if (inPeriod.isEmpty()) "—" else "${(hit * 100f / inPeriod.size).roundToInt()}%",
                "$hit of ${inPeriod.size} fasts", Modifier.weight(1f),
            )
            InsightTile(
                "Longest fast", if (longest == null) "—" else fmtDur(longest.duration),
                if (longest == null) "" else SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(longest.end)),
                Modifier.weight(1f),
            )
        }

        // ---- hours chart ----
        Spacer(Modifier.height(12.dp))
        val bars: List<Triple<String, Float, Boolean>> = when (range) {
            2 -> (11 downTo 0).map { back ->
                val c = Calendar.getInstance()
                c.timeInMillis = today
                c.set(Calendar.DAY_OF_MONTH, 1)
                c.add(Calendar.MONTH, -back)
                val ms = dayStart(c.timeInMillis)
                val me = c.apply { add(Calendar.MONTH, 1) }.timeInMillis
                val n = ((minOf(me, addDays(today, 1)) - ms) / (24 * HOUR_MS)).toInt().coerceAtLeast(1)
                var tot = 0f
                var d = ms
                while (d < minOf(me, addDays(today, 1))) {
                    tot += hoursOnDay(all, d)
                    d = addDays(d, 1)
                }
                Triple(SimpleDateFormat("MMM", Locale.getDefault()).format(Date(ms)), tot / n, false)
            }
            else -> {
                val n = if (range == 0) 7 else 14
                (n - 1 downTo 0).map { back ->
                    val d = addDays(today, -back)
                    Triple(SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(d)), hoursOnDay(all, d), live != null && d == today)
                }
            }
        }
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CardTitle(if (range == 2) "Average hours per day" else "Hours fasted per day")
                    Sub(if (range == 2) "12 months" else "Last ${bars.size} days")
                }
                Spacer(Modifier.height(12.dp))
                HoursChart(bars, goalLine, primary)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth().padding(start = 32.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Sub(bars.first().first, size = 10)
                    Sub(bars[bars.size / 2].first, size = 10)
                    Sub(bars.last().first, size = 10)
                }
                if (live != null) Sub("Today is still counting: ${fmtDur(now - start)} so far.", Modifier.padding(top = 8.dp), size = 13)
            }
        }

        // ---- hunger and energy by hour ----
        val periodFasts = all.filter { it.end >= from }
        val hunger = hourSeries(Types.HUNGER, periodFasts, entries)
        val energy = hourSeries(Types.ENERGY, periodFasts, entries)
        val points = hunger.count { it != null } + energy.count { it != null }
        Spacer(Modifier.height(12.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CardTitle("Hunger and energy by hour")
                    Sub("From check-ins")
                }
                Spacer(Modifier.height(12.dp))
                if (points < 3) {
                    Sub("Log a few check-ins during your fasts to see how hunger and energy move by hour.", size = 13)
                } else {
                    HungerEnergyChart(hunger, energy, primary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
                        LineLegend(primary, "Hunger")
                        LineLegend(TrackBlue, "Energy")
                    }
                }
            }
        }

        // ---- next-day energy by fast length ----
        val bucketAvg: List<Double?> = buckets.map { (_, r) ->
            val vals = ArrayList<Double>()
            for (f in inPeriod) {
                if ((f.duration / HOUR_MS).toInt() !in r) continue
                val d = addDays(dayStart(f.end), 1)
                val es = entries.filter { it.type == Types.ENERGY && it.time >= d && it.time < addDays(d, 1) }
                if (es.isNotEmpty()) vals.add(es.sumOf { it.value } / es.size)
            }
            if (vals.isEmpty()) null else vals.sum() / vals.size
        }
        val bestIdx = bucketAvg.withIndex().filter { it.value != null }.maxByOrNull { it.value!! }?.index
        Spacer(Modifier.height(12.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CardTitle("Next-day energy by fast length")
                    Sub("Average, 1–5")
                }
                Spacer(Modifier.height(12.dp))
                if (bestIdx == null) {
                    Sub("Check your energy the day after a fast and this fills in.", size = 13)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        buckets.forEachIndexed { i, (label, _) ->
                            val v = bucketAvg[i]
                            val best = i == bestIdx
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    label, fontSize = 12.sp, modifier = Modifier.width(62.dp),
                                    fontWeight = if (best) FontWeight.Bold else FontWeight.Normal,
                                    color = if (best) onSurface else muted,
                                )
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .height(14.dp)
                                        .clip(RoundedCornerShape(7.dp))
                                        .background(MaterialTheme.colorScheme.outlineVariant),
                                ) {
                                    if (v != null) {
                                        Box(
                                            Modifier
                                                .fillMaxWidth((v / 5.0).toFloat().coerceIn(0f, 1f))
                                                .height(14.dp)
                                                .clip(RoundedCornerShape(7.dp))
                                                .background(primary)
                                                .then(if (best) Modifier.border(2.dp, onSurface, RoundedCornerShape(7.dp)) else Modifier),
                                        )
                                    }
                                }
                                Text(
                                    if (v == null) "–" else String.format(Locale.US, "%.1f", v),
                                    fontSize = 12.sp, fontWeight = FontWeight.Bold, color = onSurface,
                                    textAlign = TextAlign.End, modifier = Modifier.width(28.dp),
                                )
                            }
                        }
                    }
                }
            }
        }

        // ---- consistency heat map ----
        val thisMonday = weekStart(today)
        val firstMonday = addDays(thisMonday, -7 * 11)
        SoftCard(Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CardTitle("Consistency")
                    Sub("Last 12 weeks")
                }
                Spacer(Modifier.height(10.dp))
                Row {
                    Column(Modifier.padding(top = 18.dp, end = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        for (l in listOf("M", "", "W", "", "F", "", "S")) {
                            Box(Modifier.size(width = 12.dp, height = 20.dp), contentAlignment = Alignment.Center) {
                                Text(l, fontSize = 10.sp, color = muted)
                            }
                        }
                    }
                    Column {
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            var lastMonth = -1
                            for (w in 0 until 12) {
                                val c = Calendar.getInstance()
                                c.timeInMillis = addDays(firstMonday, w * 7)
                                val m = c.get(Calendar.MONTH)
                                Box(Modifier.width(20.dp).height(15.dp)) {
                                    if (m != lastMonth) {
                                        Text(
                                            SimpleDateFormat("MMM", Locale.getDefault()).format(c.time),
                                            fontSize = 10.sp, color = muted, maxLines = 1, softWrap = false,
                                        )
                                    }
                                }
                                lastMonth = m
                            }
                        }
                        Spacer(Modifier.height(3.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            for (w in 0 until 12) {
                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    for (d in 0..6) {
                                        val day = addDays(firstMonday, w * 7 + d)
                                        val h = hoursOnDay(all, day)
                                        val color = when {
                                            day > today -> Color.Transparent
                                            h <= 0.05f -> MaterialTheme.colorScheme.outlineVariant
                                            h < 12f -> LowRed
                                            h < 18f -> MidRed
                                            else -> primary
                                        }
                                        Box(Modifier.size(20.dp).clip(RoundedCornerShape(5.dp)).background(color))
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Sub("No fast", size = 11)
                    for (c in listOf(MaterialTheme.colorScheme.outlineVariant, LowRed, MidRed, primary)) {
                        Box(Modifier.size(14.dp).clip(RoundedCornerShape(4.dp)).background(c))
                    }
                    Sub("18h +", size = 11)
                }
            }
        }

        // ---- what we noticed ----
        Spacer(Modifier.height(20.dp))
        Text("What we noticed", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = onSurface)
        Spacer(Modifier.height(10.dp))
        val notes = ArrayList<Pair<Int, String>>()

        val peakIdx = hunger.withIndex().filter { it.value != null }.maxByOrNull { it.value!! }?.index
        if (peakIdx != null && hunger.count { it != null } >= 3) {
            val peakH = peakIdx * 2
            val peakV = hunger[peakIdx]!!
            var ease = -1
            for (i in peakIdx + 1..10) {
                val v = hunger[i]
                if (v != null && v <= peakV - 0.8) {
                    ease = i * 2
                    break
                }
            }
            notes.add(
                R.drawable.ic_trend to
                    "Hunger peaks around hour $peakH" + (if (ease > 0) " and eases after ${ease}h." else ".") +
                    " Water with a pinch of salt around hour ${(peakH - 1).coerceAtLeast(1)} may take the edge off."
            )
        }
        if (bestIdx != null && bucketAvg.count { it != null } >= 2) {
            val longerBetter = (bestIdx + 1 until buckets.size).any { bucketAvg[it] != null && bucketAvg[it]!! > bucketAvg[bestIdx]!! }
            val longerExists = (bestIdx + 1 until buckets.size).any { bucketAvg[it] != null }
            notes.add(
                R.drawable.ic_bolt to
                    "You feel best the day after ${buckets[bestIdx].first.lowercase().replace(" +", "+")} fasts." +
                    (if (longerExists && !longerBetter) " Longer fasts did not add energy." else "")
            )
        }
        val missed = inPeriod.filter { !it.completed }
        val weekendMissed = missed.count { weekdayIndex(it.end) >= 5 }
        if (missed.size >= 2 && weekendMissed >= 2 && weekendMissed * 2 >= missed.size) {
            notes.add(
                R.drawable.ic_clock to
                    "$weekendMissed of your ${missed.size} missed goals fell on a weekend. Try a lighter 14 : 10 plan for Saturdays."
            )
        }
        if (notes.isEmpty()) {
            Sub("Nothing stands out yet. Keep logging fasts and check-ins and patterns will show up here.", size = 13)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for ((icon, text) in notes) {
                    SoftCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                            FIcon(icon, size = 22.dp, tint = primary)
                            Text(text, fontSize = 14.sp, lineHeight = 20.sp, color = onSurface)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Sub("Insights need about two weeks of check-ins to be useful.", size = 11)
    }
}

@Composable
private fun InsightTile(label: String, value: String, sub: String, modifier: Modifier) {
    SoftCard(modifier) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Sub(label)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 2.dp))
            Sub(sub, size = 11)
        }
    }
}

@Composable
private fun LineLegend(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.width(14.dp).height(3.dp).background(color))
        Sub(label, size = 11)
    }
}

/** Bars per day with a goal line. Values are hours, 0 to 24. */
@Composable
private fun HoursChart(bars: List<Triple<String, Float, Boolean>>, goal: Int, primary: Color) {
    val h: Dp = 140.dp
    val grid = MaterialTheme.colorScheme.outlineVariant
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Box(Modifier.fillMaxWidth().height(h)) {
        for (v in listOf(0, 6, 12, 24)) {
            val y = h * (1f - v / 24f)
            Box(Modifier.padding(start = 32.dp).fillMaxWidth().height(1.dp).offset(y = y - 1.dp).background(grid))
        }
        for (v in listOf(0, 6, 12, 18, 24)) {
            Text(
                "${v}h", fontSize = 10.sp, color = muted,
                modifier = Modifier.offset(y = h * (1f - v / 24f) - 8.dp).width(28.dp),
                textAlign = TextAlign.End,
            )
        }
        Row(
            Modifier.padding(start = 32.dp).fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom,
        ) {
            for ((_, v, isLive) in bars) {
                val color = when {
                    isLive -> DarkRed
                    v >= goal -> primary
                    else -> MidRed
                }
                Box(
                    Modifier
                        .width(if (bars.size > 12) 10.dp else 16.dp)
                        .height((h * (v / 24f).coerceIn(0f, 1f)).coerceAtLeast(2.dp))
                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                        .background(color),
                )
            }
        }
        Box(
            Modifier
                .padding(start = 32.dp)
                .fillMaxWidth()
                .height(1.dp)
                .offset(y = h * (1f - goal / 24f))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)),
        )
        Text(
            "Goal ${goal}h", fontSize = 11.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.align(Alignment.TopEnd).offset(y = h * (1f - goal / 24f) - 16.dp),
        )
    }
}

/** Two lines over 0 to 20 hours, values 1 to 5, with the peak hunger marked. */
@Composable
private fun HungerEnergyChart(hunger: List<Double?>, energy: List<Double?>, primary: Color) {
    val h = 150.dp
    val grid = MaterialTheme.colorScheme.outlineVariant
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val onSurface = MaterialTheme.colorScheme.onSurface
    val peakIdx = hunger.withIndex().filter { it.value != null }.maxByOrNull { it.value!! }?.index
    val stageOfPeak = if (peakIdx != null) fastingStages[stageIndexFor(peakIdx * 2 * HOUR_MS)] else null
    val bandFrom = stageOfPeak?.hour ?: 0
    val bandTo = if (stageOfPeak != null) (fastingStages.getOrNull(fastingStages.indexOf(stageOfPeak) + 1)?.hour ?: 24) else 0

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val plotW = maxWidth - 28.dp
        Column {
            Box(Modifier.fillMaxWidth().height(h)) {
                for (v in 1..5) {
                    val y = h * (1f - (v - 1) / 4f)
                    Box(Modifier.padding(start = 28.dp).fillMaxWidth().height(1.dp).offset(y = y - 1.dp).background(grid))
                    Text("$v", fontSize = 10.sp, color = muted, modifier = Modifier.offset(y = y - 8.dp).width(22.dp), textAlign = TextAlign.End)
                }
                Canvas(Modifier.padding(start = 28.dp).fillMaxSize()) {
                    val w = size.width
                    val ph = size.height
                    // shaded stage band (12-16h etc.)
                    if (bandTo > bandFrom && bandFrom < 20) {
                        val x0 = w * (bandFrom / 20f)
                        val x1 = w * (minOf(bandTo, 20) / 20f)
                        drawRect(Color.White.copy(alpha = 0.06f), Offset(x0, 0f), androidx.compose.ui.geometry.Size(x1 - x0, ph))
                    }
                    fun line(series: List<Double?>, color: Color) {
                        val path = Path()
                        var started = false
                        for (i in series.indices) {
                            val v = series[i] ?: continue
                            val x = w * (i / 10f)
                            val y = ph * (1f - ((v.toFloat() - 1f) / 4f).coerceIn(0f, 1f))
                            if (!started) {
                                path.moveTo(x, y)
                                started = true
                            } else {
                                path.lineTo(x, y)
                            }
                        }
                        drawPath(path, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                    line(energy, TrackBlue)
                    line(hunger, primary)
                    if (peakIdx != null) {
                        val v = hunger[peakIdx]!!
                        val c = Offset(w * (peakIdx / 10f), ph * (1f - ((v.toFloat() - 1f) / 4f).coerceIn(0f, 1f)))
                        drawCircle(primary, 5.dp.toPx(), c)
                        drawCircle(Color.Black.copy(alpha = 0.35f), 5.dp.toPx(), c, style = Stroke(width = 1.5.dp.toPx()))
                    }
                }
                if (peakIdx != null) {
                    val v = hunger[peakIdx]!!
                    val x = plotW * (peakIdx / 10f) + 28.dp
                    val y = h * (1f - ((v.toFloat() - 1f) / 4f).coerceIn(0f, 1f))
                    Text(
                        "Peak " + String.format(Locale.US, "%.1f", v), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        color = onSurface,
                        modifier = Modifier.offset(x = (x - 26.dp).coerceAtLeast(28.dp), y = (y - 24.dp).coerceAtLeast(0.dp)),
                    )
                }
            }
            Row(Modifier.padding(start = 28.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for (t in listOf(0, 4, 8, 12, 16, 20)) Sub("${t}h", size = 10)
            }
            if (stageOfPeak != null && bandTo > bandFrom) {
                Sub(
                    "${stageOfPeak.name} (${bandFrom}–${minOf(bandTo, 24)}h) shaded",
                    Modifier.fillMaxWidth().padding(top = 4.dp), size = 10,
                )
            }
        }
    }
}
