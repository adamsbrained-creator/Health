package ix.app.health

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import ix.app.health.widget.Widgets
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import ix.app.health.data.Repo
import ix.app.health.data.Types
import ix.app.health.ui.BottomBar
import ix.app.health.ui.ExercisesScreen
import ix.app.health.ui.FastingScreen
import ix.app.health.ui.HealthTab
import ix.app.health.ui.HealthTheme
import ix.app.health.ui.LogForm
import ix.app.health.ui.SettingsScreen
import ix.app.health.ui.StatsScreen

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_OPEN = "open"
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra(EXTRA_OPEN)?.let { Repo.get(this).requestOpen(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = Repo.get(this)
        if (savedInstanceState == null) {
            intent?.getStringExtra(EXTRA_OPEN)?.let { repo.requestOpen(it) }
        }
        setContent {
            HealthTheme {
                HealthRoot(repo)
            }
        }
    }
}

private data class LogRequest(val type: String, val note: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HealthRoot(repo: Repo) {
    var tab by rememberSaveable { mutableStateOf(HealthTab.Fasting) }
    var log by remember { mutableStateOf<LogRequest?>(null) }
    val openRequest by repo.openRequest.collectAsState()
    LaunchedEffect(openRequest) {
        if (openRequest != null) tab = HealthTab.Fasting
    }

    val ctx = LocalContext.current
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        Widgets.updateAll(ctx)
    }
    LaunchedEffect(Unit) {
        val needs = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needs) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS) else Widgets.updateAll(ctx)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = { BottomBar(tab) { tab = it } },
    ) { inner ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .statusBarsPadding(),
        ) {
            when (tab) {
                HealthTab.Fasting -> FastingScreen(repo)
                HealthTab.Stats -> StatsScreen(repo) { log = LogRequest(Types.WEIGHT, "") }
                HealthTab.Exercises -> ExercisesScreen { name -> log = LogRequest(Types.WORKOUT, name) }
                HealthTab.Settings -> SettingsScreen(repo)
            }
        }
    }

    val request = log
    if (request != null) {
        ModalBottomSheet(
            onDismissRequest = { log = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface,
        ) {
            LogForm(
                initialType = request.type,
                initialNote = request.note,
                repo = repo,
                source = "app",
                onDone = { log = null },
            )
        }
    }
}
