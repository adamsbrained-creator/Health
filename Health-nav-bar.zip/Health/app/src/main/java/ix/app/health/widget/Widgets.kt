package ix.app.health.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import ix.app.health.MainActivity
import ix.app.health.QuickLogActivity
import ix.app.health.R
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.DAY_MS
import ix.app.health.data.Types
import ix.app.health.ui.fastingStages
import ix.app.health.ui.planLabel
import ix.app.health.ui.stageIndexFor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class QuickLogWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Widgets.render(context, manager, javaClass, ids)
    }
}

class RingWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Widgets.render(context, manager, javaClass, ids)
    }
}

class WaterWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Widgets.render(context, manager, javaClass, ids)
    }
}

class FastingWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Widgets.render(context, manager, javaClass, ids)
    }
}

/** Handles the buttons on the widgets that save data without opening anything. */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val repo = Repo.get(context)
        when (intent.action) {
            Widgets.ACTION_WATER -> repo.addEntry(Types.WATER, 250.0, source = "widget")
            Widgets.ACTION_TOGGLE_FAST -> repo.toggleFast()
        }
    }
}

object Widgets {
    const val ACTION_WATER = "ix.app.health.ACTION_WATER"
    const val ACTION_TOGGLE_FAST = "ix.app.health.ACTION_TOGGLE_FAST"

    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    /** Refresh every placed widget. Called whenever data changes. */
    fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val classes = listOf<Class<*>>(
            QuickLogWidget::class.java,
            WaterWidget::class.java,
            FastingWidget::class.java,
            RingWidget::class.java,
        )
        for (cls in classes) {
            val ids = manager.getAppWidgetIds(ComponentName(context, cls))
            if (ids.isNotEmpty()) render(context, manager, cls, ids)
        }
        Notifier.update(context)
    }

    /** Asks the launcher to place a widget on the home screen. False if it can't. */
    fun requestPin(context: Context, cls: Class<*>): Boolean {
        val manager = AppWidgetManager.getInstance(context)
        if (!manager.isRequestPinAppWidgetSupported) return false
        return manager.requestPinAppWidget(ComponentName(context, cls), null, null)
    }

    fun render(context: Context, manager: AppWidgetManager, cls: Class<*>, ids: IntArray) {
        val views = when (cls) {
            QuickLogWidget::class.java -> quickViews(context)
            WaterWidget::class.java -> waterViews(context)
            RingWidget::class.java -> ringViews(context)
            else -> fastingViews(context)
        }
        for (id in ids) {
            try {
                manager.updateAppWidget(id, views)
            } catch (e: Exception) {
                // never let a widget problem crash the app
            }
        }
    }

    // ---- Quick log 2x2 -------------------------------------------------

    private fun quickViews(context: Context): RemoteViews {
        val v = RemoteViews(context.packageName, R.layout.widget_quick)
        v.setOnClickPendingIntent(R.id.btn_water, actionIntent(context, ACTION_WATER, 4))
        v.setOnClickPendingIntent(R.id.btn_salts, Notifier.openPi(context, "log:Electrolytes"))
        v.setOnClickPendingIntent(R.id.btn_checkin, Notifier.openPi(context, "checkin"))
        v.setOnClickPendingIntent(R.id.btn_weight, logPopup(context, Types.WEIGHT, 1))
        v.setOnClickPendingIntent(R.id.quick_title, openApp(context, 5))
        return v
    }

    // ---- Water 2x2 -----------------------------------------------------

    private fun waterViews(context: Context): RemoteViews {
        val repo = Repo.get(context)
        val goal = repo.waterGoal.value
        val today = repo.waterToday()
        val v = RemoteViews(context.packageName, R.layout.widget_water)
        v.setTextViewText(R.id.water_value, String.format(Locale.US, "%.1f L", today / 1000.0))
        v.setTextViewText(R.id.water_goal, String.format(Locale.US, "of %.1f L", goal / 1000.0))
        v.setProgressBar(R.id.water_bar, goal, today.coerceAtMost(goal), false)
        v.setOnClickPendingIntent(R.id.water_add, actionIntent(context, ACTION_WATER, 6))
        v.setOnClickPendingIntent(R.id.water_value, openApp(context, 7))
        return v
    }

    // ---- Timer ring 2x2 ------------------------------------------------

    private fun ringViews(context: Context): RemoteViews {
        val repo = Repo.get(context)
        val start = repo.fastStart.value
        val v = RemoteViews(context.packageName, R.layout.widget_ring)
        val now = System.currentTimeMillis()
        if (start > 0L) {
            val goal = repo.goalHours.value
            val elapsed = (now - start).coerceAtLeast(0L)
            val progress = if (goal > 0) (elapsed.toFloat() / (goal * HOUR_MS)).coerceIn(0f, 1f)
            else ((elapsed % DAY_MS).toFloat() / DAY_MS).coerceIn(0f, 1f)
            v.setImageViewBitmap(R.id.ring_img, ringBitmap(progress, RED))
            v.setViewVisibility(R.id.ring_chrono, View.VISIBLE)
            v.setViewVisibility(R.id.ring_idle, View.GONE)
            v.setChronometer(R.id.ring_chrono, SystemClock.elapsedRealtime() - elapsed, null, true)
            val left = goal * HOUR_MS - elapsed
            v.setTextViewText(
                R.id.ring_sub,
                if (goal <= 0) "No goal" else if (left > 0) fmtLeft(left) + " left" else "Goal reached",
            )
        } else {
            val lastEnd = repo.fasts.value.maxOfOrNull { it.end } ?: 0L
            val plan = repo.goalFor(now)
            val windowEnd = if (lastEnd > 0L && plan in 1..23) lastEnd + (24 - plan) * HOUR_MS else 0L
            val inWindow = windowEnd > now
            val progress = if (inWindow) ((windowEnd - now).toFloat() / ((24 - plan) * HOUR_MS)).coerceIn(0f, 1f) else 0f
            v.setImageViewBitmap(R.id.ring_img, ringBitmap(progress, WHITE))
            v.setViewVisibility(R.id.ring_chrono, View.GONE)
            v.setViewVisibility(R.id.ring_idle, View.VISIBLE)
            v.setTextViewText(R.id.ring_idle, if (inWindow) fmtLeft(windowEnd - now) else "Ready")
            v.setTextViewText(R.id.ring_sub, if (inWindow) "Eating window" else "Start when you are")
        }
        v.setOnClickPendingIntent(R.id.ring_root, openApp(context, 10))
        return v
    }

    // ---- Fasting 4x2 ---------------------------------------------------

    private fun fastingViews(context: Context): RemoteViews {
        val repo = Repo.get(context)
        val start = repo.fastStart.value
        val goal = repo.goalHours.value
        val v = RemoteViews(context.packageName, R.layout.widget_fasting)
        v.setOnClickPendingIntent(R.id.fast_checkin, Notifier.openPi(context, "checkin"))

        if (start > 0L) {
            val now = System.currentTimeMillis()
            val elapsed = (now - start).coerceAtLeast(0L)
            val idx = stageIndexFor(elapsed)
            v.setTextViewText(R.id.fast_title, "Fasting · " + planLabel(goal))
            // The Chronometer ticks by itself, so the widget needs no constant updates.
            v.setViewVisibility(R.id.fast_chrono, View.VISIBLE)
            v.setViewVisibility(R.id.fast_idle, View.GONE)
            v.setChronometer(R.id.fast_chrono, SystemClock.elapsedRealtime() - elapsed, null, true)
            v.setTextViewText(R.id.fast_stage, fastingStages[idx].name)
            v.setTextViewText(
                R.id.fast_sub,
                if (goal > 0) "Goal at " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(start + goal * HOUR_MS)) else "No goal",
            )
            v.setViewVisibility(R.id.fast_track, View.VISIBLE)
            v.setImageViewBitmap(R.id.fast_track, trackBitmap(elapsed, goal))
            v.setTextViewText(R.id.fast_btn, "End fast")
            v.setViewVisibility(R.id.fast_checkin, View.VISIBLE)
        } else {
            v.setTextViewText(R.id.fast_title, "Fasting · " + planLabel(repo.goalFor(System.currentTimeMillis())))
            v.setViewVisibility(R.id.fast_chrono, View.GONE)
            v.setViewVisibility(R.id.fast_idle, View.VISIBLE)
            v.setTextViewText(R.id.fast_stage, "")
            v.setTextViewText(R.id.fast_sub, "Eating window")
            v.setViewVisibility(R.id.fast_track, View.GONE)
            v.setTextViewText(R.id.fast_btn, "Start fast")
            v.setViewVisibility(R.id.fast_checkin, View.GONE)
        }
        v.setOnClickPendingIntent(R.id.fast_btn, actionIntent(context, ACTION_TOGGLE_FAST, 8))
        v.setOnClickPendingIntent(R.id.fast_title, openApp(context, 9))
        return v
    }

    // ---- drawing -------------------------------------------------------

    private const val RED = 0xFFFF2D3F.toInt()
    private const val WHITE = 0xFFF2F2F7.toInt()
    private const val TRACK = 0xFF2C2C2E.toInt()
    private const val CARD = 0xFF1C1C1E.toInt()
    private const val NODE_STROKE = 0xFF636366.toInt()

    private fun fmtLeft(ms: Long): String {
        val m = (ms + 59_999L) / 60_000L
        return "${m / 60}h ${String.format(Locale.US, "%02d", m % 60)}m"
    }

    private fun ringBitmap(progress: Float, color: Int): Bitmap {
        val size = 320
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val stroke = 28f
        val rect = RectF(stroke, stroke, size - stroke, size - stroke)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = stroke
        p.color = TRACK
        c.drawArc(rect, 0f, 360f, false, p)
        if (progress > 0.005f) {
            p.color = color
            p.strokeCap = Paint.Cap.ROUND
            c.drawArc(rect, -90f, 360f * progress, false, p)
        }
        return bmp
    }

    /** The stage track: a line with a marker for every stage inside the goal. */
    private fun trackBitmap(elapsed: Long, goal: Int): Bitmap {
        val w = 720
        val h = 40
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val pad = 14f
        val len = w - 2 * pad
        val cy = h / 2f
        p.style = Paint.Style.FILL
        p.color = TRACK
        c.drawRoundRect(RectF(pad, cy - 3f, pad + len, cy + 3f), 3f, 3f, p)
        val frac = if (goal > 0) (elapsed.toFloat() / (goal * HOUR_MS)).coerceIn(0f, 1f) else 0f
        p.color = RED
        c.drawRoundRect(RectF(pad, cy - 3f, pad + len * frac, cy + 3f), 3f, 3f, p)
        if (goal > 0) {
            val cur = stageIndexFor(elapsed)
            for (i in fastingStages.indices) {
                val hr = fastingStages[i].hour
                if (hr * HOUR_MS >= goal * HOUR_MS) continue
                val x = pad + len * (hr.toFloat() / goal)
                when {
                    i < cur -> {
                        p.color = CARD; c.drawCircle(x, cy, 10f, p)
                        p.color = RED; c.drawCircle(x, cy, 7f, p)
                    }
                    i == cur -> {
                        p.color = WHITE; c.drawCircle(x, cy, 14f, p)
                        p.color = RED; c.drawCircle(x, cy, 10f, p)
                    }
                    else -> {
                        p.color = NODE_STROKE; c.drawCircle(x, cy, 10f, p)
                        p.color = CARD; c.drawCircle(x, cy, 7.5f, p)
                    }
                }
            }
        }
        return bmp
    }

    // ---- intents -------------------------------------------------------

    private fun logPopup(context: Context, type: String, code: Int): PendingIntent {
        val intent = Intent(context, QuickLogActivity::class.java)
            .putExtra(QuickLogActivity.EXTRA_TYPE, type)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(context, code, intent, FLAGS)
    }

    private fun actionIntent(context: Context, action: String, code: Int): PendingIntent {
        val intent = Intent(context, WidgetActionReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(context, code, intent, FLAGS)
    }

    private fun openApp(context: Context, code: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(context, code, intent, FLAGS)
    }
}
