package ix.app.health.widget

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.Icon
import androidx.core.content.ContextCompat
import androidx.core.graphics.PathParser
import ix.app.health.R
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Which picture the small status bar icon shows. */
enum class IconState { RUN, GOAL, EAT }

/**
 * Everything the notification draws itself: the status bar icon, the progress rings and bars,
 * and the pictures on alerts. Drawn into bitmaps because notifications can't run Compose.
 * Colours that must work on both light and dark notification backgrounds are picked with [isDark].
 */
object NotifArt {
    private val ACCENT: Int = Color.parseColor("#FF2D3F")
    private val NOTHING_RED: Int = Color.parseColor("#D71921")
    private val TRACK: Int = Color.argb(110, 160, 160, 168)

    /** Told to the system as the notification colour, so it does not pick one from the red launcher icon. */
    val NEUTRAL: Int = Color.parseColor("#8E8E93")

    fun accent(nothing: Boolean): Int = if (nothing) NOTHING_RED else ACCENT

    /**
     * Notification cards draw their own dark background, so the pictures on them are always made for dark.
     * (Asking the phone's theme does not work: many shades are dark even in a light theme.)
     */
    @Suppress("UNUSED_PARAMETER")
    fun isDark(c: Context): Boolean = true

    fun ink(dark: Boolean): Int = if (dark) Color.WHITE else Color.parseColor("#111111")

    // ------------------------------------------------------------------
    // status bar icon. White shapes; the system tints them. Kept bold and simple,
    // because it is shown at about 24dp: a thin dotted ring looks like a loading spinner.
    // ------------------------------------------------------------------

    @Suppress("UNUSED_PARAMETER")
    fun smallIcon(nothing: Boolean, frac: Float, state: IconState): Icon {
        val px = 96
        val s = px / 24f
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        when (state) {
            IconState.RUN -> pieIcon(c, s, frac, p)
            IconState.GOAL -> goalIcon(c, s, p)
            IconState.EAT -> eatIcon(c, s, p)
        }
        return Icon.createWithBitmap(bmp)
    }

    /** Fasting: a ring with a filled wedge that grows as the hours pass. */
    private fun pieIcon(c: Canvas, s: Float, frac: Float, p: Paint) {
        val mid = 12f * s
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.1f * s
        c.drawCircle(mid, mid, 9.6f * s, p)
        val r = 6.1f * s
        p.style = Paint.Style.FILL
        p.alpha = 70
        c.drawCircle(mid, mid, r, p)
        p.alpha = 255
        val sweep = 360f * frac.coerceIn(0f, 1f)
        if (sweep >= 359f) {
            c.drawCircle(mid, mid, r, p)
        } else if (sweep > 4f) {
            c.drawArc(RectF(mid - r, mid - r, mid + r, mid + r), -90f, sweep, true, p)
        }
    }

    /** Goal reached: a solid badge with a check cut out of it. */
    private fun goalIcon(c: Canvas, s: Float, p: Paint) {
        val mid = 12f * s
        p.style = Paint.Style.FILL
        c.drawCircle(mid, mid, 10.4f * s, p)
        val q = Paint(Paint.ANTI_ALIAS_FLAG)
        q.style = Paint.Style.STROKE
        q.strokeWidth = 2.5f * s
        q.strokeCap = Paint.Cap.ROUND
        q.strokeJoin = Paint.Join.ROUND
        q.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        val check = Path()
        check.moveTo(7.4f * s, 12.4f * s)
        check.lineTo(10.6f * s, 15.6f * s)
        check.lineTo(16.6f * s, 9.0f * s)
        c.drawPath(check, q)
    }

    /** Eating window: a fork and knife. */
    private fun eatIcon(c: Canvas, s: Float, p: Paint) {
        try {
            val path = PathParser.createPathFromPathData(
                "M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10M17 3c-2 1.5-3 4-3 7 0 2 1 3 3 3v8M17 3v10"
            )
            val m = Matrix()
            m.setScale(s, s)
            path.transform(m)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.3f * s
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            c.drawPath(path, p)
        } catch (e: Exception) {
            pieIcon(c, s, 0f, p)
        }
    }

    // ------------------------------------------------------------------
    // pictures inside the notification card
    // ------------------------------------------------------------------

    /** Classic: a round progress ring. The percent is a text view on top, so it follows the theme. */
    fun ring(sizePx: Int, frac: Float, color: Int): Bitmap {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sw = sizePx * 0.11f
        val r = (sizePx - sw) / 2f
        val mid = sizePx / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.strokeCap = Paint.Cap.ROUND
        p.color = TRACK
        c.drawCircle(mid, mid, r, p)
        p.color = color
        val sweep = 360f * frac.coerceIn(0f, 1f)
        if (sweep > 0.5f) c.drawArc(RectF(mid - r, mid - r, mid + r, mid + r), -90f, sweep, false, p)
        return bmp
    }

    /** Nothing: the same ring made of dots. */
    fun dotRing(sizePx: Int, frac: Float, dark: Boolean, n: Int = 24, mark: Boolean = false): Bitmap {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        val mid = sizePx / 2f
        val dotR = sizePx * 0.045f
        val ringR = mid - dotR - sizePx * 0.03f
        val lit = (frac.coerceIn(0f, 1f) * n).roundToInt()
        for (i in 0 until n) {
            val a = i * 2 * PI / n
            p.color = if (i < lit) ink(dark) else TRACK
            c.drawCircle(mid + (ringR * sin(a)).toFloat(), mid - (ringR * cos(a)).toFloat(), dotR, p)
        }
        if (mark) {
            p.color = NOTHING_RED
            c.drawCircle(mid, mid, dotR * 1.6f, p)
        }
        return bmp
    }

    /** Classic: one block per hour of the goal, filled as the hours pass. */
    fun hourBar(widthPx: Int, heightPx: Int, frac: Float, blocks: Int, color: Int): Bitmap {
        val bmp = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        val gap = heightPx * 0.4f
        val w = (widthPx - gap * (blocks - 1)) / blocks
        val rad = heightPx / 2f
        val f = frac.coerceIn(0f, 1f) * blocks
        for (i in 0 until blocks) {
            val x = i * (w + gap)
            val rect = RectF(x, 0f, x + w, heightPx.toFloat())
            p.color = TRACK
            c.drawRoundRect(rect, rad, rad, p)
            val fill = (f - i).coerceIn(0f, 1f)
            if (fill > 0f) {
                p.color = color
                c.save()
                c.clipRect(x, 0f, x + w * fill, heightPx.toFloat())
                c.drawRoundRect(rect, rad, rad, p)
                c.restore()
            }
        }
        return bmp
    }

    /** Nothing: a row of dots, one per half hour of an 18h goal. A red dot marks the next stage. */
    fun dotBar(widthPx: Int, heightPx: Int, frac: Float, n: Int, markIndex: Int, dark: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        val r = heightPx * 0.36f
        val sp = (widthPx - 2 * r) / (n - 1)
        val lit = (frac.coerceIn(0f, 1f) * n).roundToInt()
        for (i in 0 until n) {
            val x = r + i * sp
            if (i == markIndex) {
                p.color = NOTHING_RED
                c.drawCircle(x, heightPx / 2f, r * 1.2f, p)
            } else {
                p.color = if (i < lit) ink(dark) else TRACK
                c.drawCircle(x, heightPx / 2f, r, p)
            }
        }
        return bmp
    }

    // ------------------------------------------------------------------
    // the picture on a stage alert
    // ------------------------------------------------------------------

    private val DOT_GLYPHS = mapOf(
        "fork" to listOf("10101", "10101", "11111", "01110", "00100", "00100", "00100"),
        "drop" to listOf("00100", "00100", "01110", "01110", "11111", "11111", "01110"),
        "bolt" to listOf("00011", "00110", "01100", "11111", "00110", "01100", "11000"),
        "flame" to listOf("00100", "01100", "01110", "11110", "11111", "11111", "01110"),
    )

    fun glyphFor(stageHour: Int): String = when {
        stageHour < 4 -> "fork"
        stageHour < 12 -> "drop"
        stageHour < 16 -> "bolt"
        else -> "flame"
    }

    fun glyphBitmap(context: Context, nothing: Boolean, glyph: String): Bitmap {
        val size = 192
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.parseColor("#2A2A2A")
        c.drawCircle(size / 2f, size / 2f, size / 2f, p)
        if (nothing) {
            val rows = DOT_GLYPHS[glyph] ?: return bmp
            val cell = 16f
            val ox = (size - 5 * cell) / 2f
            val oy = (size - 7 * cell) / 2f
            p.color = Color.WHITE
            for ((r, row) in rows.withIndex()) {
                for ((col, ch) in row.withIndex()) {
                    if (ch == '1') c.drawCircle(ox + col * cell + cell / 2, oy + r * cell + cell / 2, 5.6f, p)
                }
            }
        } else {
            val res = when (glyph) {
                "fork" -> R.drawable.ic_fork
                "drop" -> R.drawable.ic_drop
                "bolt" -> R.drawable.ic_bolt
                else -> R.drawable.ic_flame
            }
            val d = ContextCompat.getDrawable(context, res) ?: return bmp
            d.setBounds(48, 48, 144, 144)
            d.draw(c)
        }
        return bmp
    }
}
