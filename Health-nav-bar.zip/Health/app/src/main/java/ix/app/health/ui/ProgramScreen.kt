package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.addDays
import ix.app.health.data.dayStart
import ix.app.health.data.programById
import ix.app.health.data.programDay
import ix.app.health.data.programHours
import ix.app.health.data.programIsLighter
import ix.app.health.data.weekdayIndex
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private fun minOfDay(t: Long): Int {
    val c = Calendar.getInstance()
    c.timeInMillis = t
    return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
}

@Composable
fun ProgramScreen(repo: Repo, onBack: () -> Unit) {
    val prog by repo.program.collectAsState()
    val fasts by repo.fasts.collectAsState()
    val start by repo.fastStart.collectAsState()
    val p = prog
    val def = p?.let { programById(it.id) }
    if (p == null || def == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val now = System.currentTimeMillis()
    val today = dayStart(now)
    val rawIdx = programDay(p, now)
    val idx = rawIdx.coerceIn(0, def.days - 1)
    val finished = rawIdx >= def.days
    var confirmEnd by remember { mutableStateOf(false) }

    // a day is done when a fast that ended that day reached the day's target
    fun dayStartOf(i: Int): Long = addDays(p.startDay, i)
    fun doneFast(i: Int) = fasts.firstOrNull {
        dayStart(it.end) == dayStartOf(i) &&
            it.duration >= programHours(def, p, i) * HOUR_MS - 30 * 60_000L
    }

    val doneDays = (0 until def.days).filter { doneFast(it) != null }.toSet()
    val dueDays = (0 until minOf(rawIdx, def.days)).filter { it !in p.skipped }
    val doneDue = dueDays.count { it in doneDays }
    val doneFasts = doneDays.mapNotNull { doneFast(it) }

    val avg = if (doneFasts.isEmpty()) 0L else doneFasts.sumOf { it.duration } / doneFasts.size
    val starts = doneFasts.map { (minOfDay(it.start) + 720) % 1440 }
    val meanStart = if (starts.isEmpty()) 0 else starts.sum() / starts.size
    val drift = if (starts.size < 2) -1 else starts.sumOf { abs(it - meanStart) } / starts.size
    val typicalStart = if (starts.isEmpty()) 20 * 60 else (meanStart + 720) % 1440

    val weeks = (def.days + 6) / 7
    val week = idx / 7 + 1
    val finish = dayStartOf(def.days - 1)
    val dateFmt = SimpleDateFormat("EEE d MMM", Locale.getDefault())
    val primary = MaterialTheme.colorScheme.primary

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 8.dp, bottom = 24.dp),
    ) {
        Box(Modifier.offset(x = (-12).dp)) { BackRow(onBack) }
        Sub(if (p.paused) "Program · paused" else "Program")
        NTitle(def.name)

        // ---- progress ----
        Spacer(Modifier.height(16.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                FastRing(
                    progress = (if (finished) def.days else idx + 1).toFloat() / def.days,
                    color = primary,
                    modifier = Modifier.size(104.dp),
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        BigNum(
                            "${if (finished) def.days else idx + 1}",
                            28.sp,
                            MaterialTheme.colorScheme.onSurface,
                        )
                        Sub("of ${def.days}", size = 11)
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        if (finished) "Program complete" else "Day ${idx + 1} of ${def.days}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Sub("Week ${minOf(week, weeks)} of $weeks", size = 13)
                    Sub("Finish line ${dateFmt.format(Date(finish))}", size = 13)
                    Sub("$doneDue of ${dueDays.size} fasts done", size = 13)
                }
            }
        }

        // ---- today ----
        if (!finished) {
            val target = programHours(def, p, idx)
            val skipped = idx in p.skipped
            val lighter = programIsLighter(def, p, idx)
            val hasLighter = def.lighterByDefault(2) || def.lighterByDefault(9)
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Column {
                            Sub("Today · Day ${idx + 1}")
                            Text(
                                if (skipped) "Skipped" else planLabel(target),
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                        if (lighter && !skipped) {
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(MaterialTheme.colorScheme.outlineVariant)
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                            ) { Text("Lighter day", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface) }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    when {
                        skipped -> Sub("No fast needed today. The program carries on tomorrow.", size = 13)
                        start > 0L -> Sub("Fast in progress, started ${fmtDayClock(start)}.", size = 13)
                        today in doneDays.map { dayStartOf(it) } -> Sub("Done for today. Nice work.", size = 13)
                        else -> Sub("Aim for ${target}h of fasting today.", size = 13)
                    }
                    if (!skipped && start == 0L) {
                        Spacer(Modifier.height(14.dp))
                        BlackButton("Start today's fast") { repo.startFast() }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        if (!skipped) {
                            TextButton(onClick = { repo.skipProgramDay(idx) }) {
                                Text("Skip today", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        if (hasLighter && (!lighter || skipped)) {
                            TextButton(onClick = { repo.lighterProgramDay(idx) }) {
                                Text("Swap with a lighter day", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // ---- calendar ----
        Spacer(Modifier.height(12.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                val letters = listOf("M", "T", "W", "T", "F", "S", "S")
                val off = weekdayIndex(p.startDay)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (c in 0..6) {
                        Text(
                            letters[(off + c) % 7],
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.size(36.dp),
                        )
                    }
                }
                for (w in 0 until weeks) {
                    val hrs = (w * 7 until minOf(w * 7 + 7, def.days)).map { def.baseHours(it) }
                    val label = if (hrs.min() == hrs.max()) planLabel(hrs.max()) else "${planLabel(hrs.min())} → ${planLabel(hrs.max())}"
                    Sub("Week ${w + 1} · $label", Modifier.padding(top = 10.dp, bottom = 6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for (c in 0..6) {
                            val i = w * 7 + c
                            if (i >= def.days) {
                                Spacer(Modifier.size(36.dp))
                                continue
                            }
                            val light = programIsLighter(def, p, i)
                            val isDone = i in doneDays
                            val isToday = i == rawIdx
                            val isSkipped = i in p.skipped
                            val past = i < rawIdx
                            val cell = Modifier.size(36.dp).clip(CircleShape)
                            when {
                                isDone -> Box(
                                    cell.background(if (light) DarkRed else primary),
                                    contentAlignment = Alignment.Center,
                                ) { FIcon(R.drawable.ic_check, size = 16.dp, tint = MaterialTheme.colorScheme.onPrimary) }
                                isSkipped -> Box(
                                    cell.background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center,
                                ) { Sub("–", size = 13) }
                                isToday -> Box(
                                    cell.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape),
                                    contentAlignment = Alignment.Center,
                                ) { Text("${i + 1}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface) }
                                else -> Box(
                                    cell.border(
                                        1.5.dp,
                                        if (light) NodeStroke else MaterialTheme.colorScheme.outlineVariant,
                                        CircleShape,
                                    ),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        "${i + 1}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (past) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(primary))
                        Sub("Done", size = 11)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(DarkRed))
                        Sub("Lighter day", size = 11)
                    }
                }
            }
        }

        // ---- summary ----
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SoftCard(Modifier.weight(1f)) {
                Column(Modifier.padding(14.dp)) {
                    Sub("Average fast")
                    Text(
                        if (doneFasts.isEmpty()) "—" else fmtDur(avg),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
            SoftCard(Modifier.weight(1f)) {
                Column(Modifier.padding(14.dp)) {
                    Sub("Start time drift")
                    Text(
                        if (drift < 0) "—" else "±$drift min",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }

        if (!finished) {
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                    FIcon(R.drawable.ic_bulb, size = 22.dp, tint = TrackAmber)
                    Column {
                        Text("Next week's focus", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Sub(
                            if (drift > 30) {
                                "Keep your start time within 30 minutes of ${fmtMinOfDay(typicalStart)}. A steady start makes the early hours easier."
                            } else {
                                "Your start time is steady. Keep it near ${fmtMinOfDay(typicalStart)} and let the hours do the work."
                            },
                            Modifier.padding(top = 2.dp),
                            size = 13,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { repo.pauseProgram(!p.paused) }) {
                Text(if (p.paused) "Resume program" else "Pause program", color = MaterialTheme.colorScheme.onSurface)
            }
            TextButton(onClick = { confirmEnd = true }) {
                Text("End program", color = primary)
            }
        }
    }

    if (confirmEnd) {
        AlertDialog(
            onDismissRequest = { confirmEnd = false },
            title = { Text("End this program?") },
            text = { Text("Your fasts stay in your journal. Plans go back to what you had set before.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmEnd = false
                    repo.endProgram()
                    onBack()
                }) { Text("End program") }
            },
            dismissButton = { TextButton(onClick = { confirmEnd = false }) { Text("Keep going") } },
        )
    }
}
