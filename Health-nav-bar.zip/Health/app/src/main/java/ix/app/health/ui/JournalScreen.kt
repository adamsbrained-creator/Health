package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.DAY_MS
import ix.app.health.data.Entry
import ix.app.health.data.FastRecord
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.Types
import ix.app.health.data.addDays
import ix.app.health.data.dayStart
import ix.app.health.data.programById
import ix.app.health.data.programDay
import ix.app.health.data.programIsLighter
import ix.app.health.data.weekStart
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/** Hours of [fasts] that fall on the day starting at [day]. */
fun hoursOnDay(fasts: List<FastRecord>, day: Long): Float {
    val e = addDays(day, 1)
    var ms = 0L
    for (f in fasts) {
        val a = maxOf(f.start, day)
        val b = minOf(f.end, e)
        if (b > a) ms += b - a
    }
    return ms.toFloat() / HOUR_MS.toFloat()
}

private fun timeOfDayWord(t: Long): String {
    val c = Calendar.getInstance()
    c.timeInMillis = t
    val h = c.get(Calendar.HOUR_OF_DAY)
    return when {
        h < 5 -> "Night"
        h < 12 -> "Morning"
        h < 17 -> "Afternoon"
        h < 22 -> "Evening"
        else -> "Night"
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JournalScreen(repo: Repo, day: Long, onDay: (Long) -> Unit, showCalendar: Boolean, onCalendarClose: () -> Unit) {
    val fasts by repo.fasts.collectAsState()
    val entries by repo.entries.collectAsState()
    val start by repo.fastStart.collectAsState()
    val goalCur by repo.goalHours.collectAsState()
    val program by repo.program.collectAsState()
    val targets by repo.targets.collectAsState()
    val waterGoal by repo.waterGoal.collectAsState()
    val mgdl by repo.glucoseMgdl.collectAsState()
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(30_000L)
            value = System.currentTimeMillis()
        }
    }

    var editor by remember { mutableStateOf<FastRecord?>(null) }
    var adding by remember { mutableStateOf(false) }

    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val today = dayStart(now)
    val sel = dayStart(day)
    val live = if (start > 0L) FastRecord(start, now, goalCur) else null
    val all = if (live != null) fasts + live else fasts
    val monday = weekStart(sel)
    val week = (0..6).map { addDays(monday, it) }
    val dayEnd = addDays(sel, 1)
    val prog = program
    val progDef = prog?.let { programById(it.id) }

    fun lighterDay(d: Long): Boolean {
        if (prog == null || progDef == null) return false
        val i = programDay(prog, d)
        return i in 0 until progDef.days && programIsLighter(progDef, prog, i)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 8.dp, bottom = 24.dp),
    ) {
        // ---- week strip ----
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 12.dp)) {
                val names = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                Row(Modifier.fillMaxWidth()) {
                    for (i in 0..6) {
                        Text(
                            names[i], fontSize = 11.sp, textAlign = TextAlign.Center,
                            fontWeight = if (week[i] == sel) FontWeight.Bold else FontWeight.Normal,
                            color = if (week[i] == sel) onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth()) {
                    for (i in 0..6) {
                        val d = week[i]
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            val base = Modifier.size(36.dp).clip(CircleShape).clickable { onDay(d) }
                            val cell = when {
                                d == sel -> base.background(primary)
                                d == today -> base.border(2.dp, NodeStroke, CircleShape)
                                else -> base
                            }
                            Box(cell, contentAlignment = Alignment.Center) {
                                Text(
                                    SimpleDateFormat("d", Locale.getDefault()).format(Date(d)),
                                    fontSize = 15.sp,
                                    fontWeight = if (d == sel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (d == sel) MaterialTheme.colorScheme.onPrimary else onSurface,
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    for (i in 0..6) {
                        val d = week[i]
                        val h = hoursOnDay(all, d)
                        val isLive = live != null && d == today
                        Column(
                            Modifier.weight(1f).clickable { onDay(d) },
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box(
                                Modifier
                                    .width(22.dp)
                                    .height(64.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.outlineVariant),
                                contentAlignment = Alignment.BottomCenter,
                            ) {
                                val fillH = (h / 24f).coerceIn(0f, 1f) * 64f
                                if (fillH > 0.5f) {
                                    val barColor = if (lighterDay(d)) DarkRed else primary
                                    var m = Modifier.width(22.dp).height(fillH.dp).clip(RoundedCornerShape(6.dp))
                                    m = if (isLive) {
                                        m.drawBehind {
                                            drawRoundRect(
                                                barColor,
                                                cornerRadius = CornerRadius(6.dp.toPx()),
                                                style = Stroke(
                                                    width = 2.dp.toPx(),
                                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)),
                                                ),
                                            )
                                        }
                                    } else {
                                        m.background(barColor)
                                    }
                                    if (d == sel) m = m.border(2.dp, onSurface, RoundedCornerShape(6.dp))
                                    Box(m)
                                }
                            }
                            Spacer(Modifier.height(3.dp))
                            Text(
                                if (isLive) "live" else if (h > 0.05f) "${h.roundToInt()}h" else "",
                                fontSize = 10.sp,
                                fontWeight = if (d == sel) FontWeight.Bold else FontWeight.Normal,
                                color = if (d == sel) onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally)) {
                    LegendDot(primary, "Fasted hours")
                    if (prog != null) LegendDot(DarkRed, "Lighter day")
                }
            }
        }

        // ---- selected day ----
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Text(
                SimpleDateFormat("EEEE d MMM", Locale.getDefault()).format(Date(sel)),
                fontSize = 20.sp, fontWeight = FontWeight.Bold, color = onSurface,
            )
            if (prog != null && progDef != null) {
                val i = programDay(prog, sel)
                if (i in 0 until progDef.days) Sub("Day ${i + 1} of ${progDef.days} · ${progDef.name.substringAfter(' ')}", size = 13)
            }
        }

        // ---- fasts ----
        val dayFasts = all.filter { it.end > sel && it.start < dayEnd }.sortedBy { it.start }
        val dayHours = hoursOnDay(all, sel)
        Spacer(Modifier.height(10.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    CardTitle("Fasts")
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.outlineVariant).clickable { adding = true },
                        contentAlignment = Alignment.Center,
                    ) { FIcon(R.drawable.ic_plus, size = 16.dp) }
                }
                Sub(
                    if (dayFasts.isEmpty()) "No fasts on this day" else "Day total ${fmtDur((dayHours * HOUR_MS).toLong())}",
                    Modifier.padding(top = 6.dp), size = 13,
                )
                if (dayFasts.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Bar(dayHours / 24f, primary, height = 8.dp)
                }
                for (f in dayFasts) {
                    val isLive = live != null && f == live
                    HorizontalDivider(Modifier.padding(top = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isLive) { editor = f }
                            .padding(top = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                (if (f.goal <= 0) "Flexi" else planLabel(f.goal)) + " fast",
                                fontSize = 15.sp, fontWeight = FontWeight.Bold, color = onSurface,
                            )
                            Sub(fmtDayClock(f.start) + " → " + (if (isLive) "ongoing" else fmtDayClock(f.end)), Modifier.padding(top = 2.dp))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            if (isLive) {
                                val part = hoursOnDay(listOf(f), sel)
                                Text(
                                    if (sel == today) fmtDur(now - f.start) + " so far" else fmtDur((part * HOUR_MS).toLong()) + " so far",
                                    fontSize = 15.sp, fontWeight = FontWeight.Bold, color = onSurface,
                                )
                                Sub(if (sel == today) "Goal ${if (f.goal > 0) planLabel(f.goal) else "none"}" else "By midnight")
                            } else {
                                Text(fmtDur(f.duration), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = onSurface)
                                Sub(if (f.goal <= 0) "Flexi" else if (f.completed) "Goal reached" else "Ended early")
                            }
                        }
                    }
                }
            }
        }

        // ---- check-ins ----
        val dayEntries = entries.filter { it.time >= sel && it.time < dayEnd }
        val checkTypes = setOf(Types.HUNGER, Types.ENERGY, Types.MOOD, Types.SYMPTOM)
        val checkGroups = dayEntries.filter { it.type in checkTypes }.groupBy { it.time }.toSortedMap()
        if (checkGroups.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        CardTitle("Check-ins")
                        Sub(if (sel == today) "${checkGroups.size} today" else "${checkGroups.size}")
                    }
                    Spacer(Modifier.height(8.dp))
                    for ((t, group) in checkGroups) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(fmtClock(t), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(44.dp))
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                for (e in group) {
                                    when (e.type) {
                                        Types.HUNGER -> FilledChipSmall("Hunger ${fmtNum(e.value)}")
                                        Types.ENERGY -> FilledChipSmall("Energy ${fmtNum(e.value)}")
                                        Types.MOOD -> FilledChipSmall("Mood ${listOf("Low", "Flat", "OK", "Good", "Great").getOrElse(e.value.toInt() - 1) { fmtNum(e.value) }}")
                                        else -> for (s in e.note.split(", ").filter { it.isNotBlank() }) OutlineChipSmall(s)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---- meals ----
        val meals = dayEntries.filter { it.type == Types.MEAL }.sortedBy { it.time }
        if (meals.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        CardTitle("Meals")
                        if (meals.size >= 2) {
                            Sub("Window ${fmtClock(meals.first().time)} – ${fmtClock(meals.last().time)} · ${fmtDur(meals.last().time - meals.first().time)}")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    meals.forEachIndexed { i, m ->
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (meals.size == 1) "Meal" else if (i == 0) "First meal" else if (i == meals.size - 1) "Last meal" else "Meal",
                                    fontSize = 14.sp, fontWeight = FontWeight.Bold, color = onSurface,
                                )
                                if (m.note.isNotBlank()) Sub(m.note)
                            }
                            Sub(fmtClock(m.time), size = 13)
                        }
                    }
                }
            }
        }

        // ---- water and electrolytes ----
        val water = dayEntries.filter { it.type == Types.WATER }.sumOf { it.value }
        val na = dayEntries.filter { it.type == Types.SODIUM }.sumOf { it.value }
        val k = dayEntries.filter { it.type == Types.POTASSIUM }.sumOf { it.value }
        val mg = dayEntries.filter { it.type == Types.MAGNESIUM }.sumOf { it.value }
        if (water + na + k + mg > 0.0) {
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CardTitle("Water and electrolytes")
                    LabeledBar("Water", "${fmtL(water)} / ${fmtL(waterGoal.toDouble())} L", (water / waterGoal).toFloat(), TrackBlue)
                    LabeledBar("Sodium", "${one(na)} / ${one(targets.sodium)} g", (na / targets.sodium).toFloat(), TrackBlue)
                    LabeledBar("Potassium", "${one(k)} / ${one(targets.potassium)} g", (k / targets.potassium).toFloat(), TrackAmber)
                    LabeledBar("Magnesium", "${fmtNum(Math.round(mg * 100) / 100.0)} / ${fmtNum(targets.magnesium)} g", (mg / targets.magnesium).toFloat(), TrackPurple)
                }
            }
        }

        // ---- body and blood ----
        val weight = dayEntries.lastOrNull { it.type == Types.WEIGHT }
        val sleep = dayEntries.lastOrNull { it.type == Types.SLEEP }
        val ket = dayEntries.lastOrNull { it.type == Types.KETONES }
        val glu = dayEntries.lastOrNull { it.type == Types.GLUCOSE }
        fun whenText(e: Entry): String {
            val f = all.firstOrNull { e.time >= it.start && e.time <= it.end }
            return timeOfDayWord(e.time) + if (f != null) ", ${(e.time - f.start) / HOUR_MS}h in" else ""
        }
        if (weight != null || sleep != null) {
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (weight != null) {
                    val before = entries.lastOrNull { it.type == Types.WEIGHT && it.time <= addDays(sel, -6) }
                    val diff = if (before != null) weight.value - before.value else null
                    BodyTile(
                        "Weight", String.format(Locale.US, "%.1f kg", weight.value),
                        if (diff == null) "" else (if (diff <= 0) "−" else "+") + String.format(Locale.US, "%.1f", abs(diff)) + " kg this week",
                        null, Modifier.weight(1f),
                    )
                }
                if (sleep != null) {
                    BodyTile(
                        "Sleep", fmtSleep(sleep.value),
                        fmtClock(sleep.time - (sleep.value * HOUR_MS).toLong()) + " → " + fmtClock(sleep.time),
                        null, Modifier.weight(1f),
                    )
                }
                if (weight == null || sleep == null) Spacer(Modifier.weight(1f))
            }
        }
        if (ket != null || glu != null) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (ket != null) {
                    BodyTile("Ketones", String.format(Locale.US, "%.1f mmol/L", ket.value), whenText(ket), Color(0xFF1FA05E), Modifier.weight(1f))
                }
                if (glu != null) {
                    BodyTile(
                        "Glucose",
                        if (mgdl) "${(glu.value * 18.016).roundToInt()} mg/dL" else String.format(Locale.US, "%.1f mmol/L", glu.value),
                        whenText(glu), null, Modifier.weight(1f),
                    )
                }
                if (ket == null || glu == null) Spacer(Modifier.weight(1f))
            }
        }

        // ---- workouts ----
        val firstMeal = meals.firstOrNull()
        for (w in dayEntries.filter { it.type == Types.WORKOUT }) {
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    FIcon(R.drawable.ic_dumbbell, size = 22.dp)
                    Column(Modifier.weight(1f)) {
                        Text(
                            fmtNum(w.value) + " min" + (if (w.note.isNotBlank()) " " + w.note.lowercase() else ""),
                            fontSize = 15.sp, fontWeight = FontWeight.Bold, color = onSurface,
                        )
                        Sub(
                            "From Exercises · " + fmtClock(w.time) +
                                (if (firstMeal != null && w.time > firstMeal.time) ", after the first meal" else ""),
                        )
                    }
                }
            }
        }

        // ---- notes ----
        val notes = dayEntries.filter { it.type == Types.NOTE && it.note.isNotBlank() }.map { it.note } +
            fasts.filter { it.end >= sel && it.end < dayEnd && it.note.isNotBlank() }.map { it.note }
        if (notes.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CardTitle("Note")
                    for (n in notes) {
                        Text(n, fontSize = 14.sp, lineHeight = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    // ---- editors ----
    val ed = editor
    if (ed != null) {
        FastEditor(
            title = "Edit fast",
            initial = ed,
            onSave = {
                repo.replaceFast(ed, it)
                editor = null
            },
            onDelete = {
                repo.deleteFast(ed)
                editor = null
            },
            onDismiss = { editor = null },
        )
    }
    if (adding) {
        val hours = if (goalCur > 0) goalCur else 16
        val endAt = if (sel == today) now else minOf(sel + 14 * HOUR_MS, now)
        FastEditor(
            title = "Add fast",
            initial = FastRecord(endAt - hours * HOUR_MS, endAt, goalCur),
            onSave = {
                repo.addFast(it)
                adding = false
            },
            onDelete = null,
            onDismiss = { adding = false },
        )
    }
    if (showCalendar) {
        MonthPicker(
            selected = sel,
            fastDays = all.flatMap { f ->
                val out = ArrayList<Long>()
                var d = dayStart(f.start)
                while (d <= dayStart(f.end) && out.size < 60) {
                    out.add(d)
                    d = addDays(d, 1)
                }
                out
            }.toSet(),
            onPick = {
                onDay(it)
                onCalendarClose()
            },
            onDismiss = onCalendarClose,
        )
    }
}

private fun one(v: Double): String = String.format(Locale.US, "%.1f", v)

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(color))
        Sub(label, size = 11)
    }
}

@Composable
private fun FilledChipSmall(text: String) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.outlineVariant)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) { Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface) }
}

@Composable
private fun OutlineChipSmall(text: String) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 3.dp),
    ) { Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface) }
}

@Composable
private fun BodyTile(label: String, value: String, sub: String, dot: Color?, modifier: Modifier) {
    SoftCard(modifier) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (dot != null) Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Sub(label)
            }
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 2.dp))
            if (sub.isNotEmpty()) Sub(sub)
        }
    }
}

/** A simple month calendar to jump to a day. */
@Composable
private fun MonthPicker(selected: Long, fastDays: Set<Long>, onPick: (Long) -> Unit, onDismiss: () -> Unit) {
    var month by remember {
        val c = Calendar.getInstance()
        c.timeInMillis = selected
        c.set(Calendar.DAY_OF_MONTH, 1)
        mutableStateOf(dayStart(c.timeInMillis))
    }
    val c = Calendar.getInstance()
    c.timeInMillis = month
    val first = month
    val offset = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val dim = c.getActualMaximum(Calendar.DAY_OF_MONTH)
    val today = dayStart(System.currentTimeMillis())
    val rows = (offset + dim + 6) / 7

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onPick(today) }) { Text("Today") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    val m = Calendar.getInstance()
                    m.timeInMillis = month
                    m.add(Calendar.MONTH, -1)
                    month = dayStart(m.timeInMillis)
                }) { Text("‹") }
                Text(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(month)), fontSize = 18.sp)
                TextButton(onClick = {
                    val m = Calendar.getInstance()
                    m.timeInMillis = month
                    m.add(Calendar.MONTH, 1)
                    month = dayStart(m.timeInMillis)
                }) { Text("›") }
            }
        },
        text = {
            Column {
                Row(Modifier.fillMaxWidth()) {
                    for (l in listOf("M", "T", "W", "T", "F", "S", "S")) {
                        Text(l, fontSize = 11.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    }
                }
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        for (col in 0..6) {
                            val n = r * 7 + col - offset + 1
                            Box(Modifier.weight(1f).height(40.dp), contentAlignment = Alignment.Center) {
                                if (n in 1..dim) {
                                    val d = addDays(first, n - 1)
                                    val on = d == selected
                                    Column(
                                        Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(if (on) MaterialTheme.colorScheme.primary else Color.Transparent)
                                            .then(if (d == today && !on) Modifier.border(1.5.dp, NodeStroke, CircleShape) else Modifier)
                                            .clickable { onPick(d) },
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                    ) {
                                        Text(
                                            "$n", fontSize = 14.sp,
                                            color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                        )
                                        Box(
                                            Modifier
                                                .size(4.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (d in fastDays) (if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary)
                                                    else Color.Transparent
                                                ),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
    )
}
