package ix.app.health.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import ix.app.health.R
import ix.app.health.data.dayStart
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ix.app.health.data.Repo
import ix.app.health.data.planGoalFor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Route { Main, Plans, Stages, Program }

@Composable
fun FastingScreen(repo: Repo) {
    var route by rememberSaveable { mutableStateOf(Route.Main) }
    var sub by rememberSaveable { mutableStateOf(0) }
    var logKind by remember { mutableStateOf<LogKind?>(null) }
    var checkIn by remember { mutableStateOf(false) }
    val ended by repo.justEnded.collectAsState()
    val request by repo.openRequest.collectAsState()

    // requests from notifications and widgets
    LaunchedEffect(request) {
        val r = request
        if (r != null) {
            when {
                r == "stages" -> route = Route.Stages
                r == "checkin" -> {
                    route = Route.Main
                    sub = 0
                    checkIn = true
                }
                r.startsWith("log:") -> {
                    val k = LogKind.values().firstOrNull { it.name == r.removePrefix("log:") }
                    route = Route.Main
                    sub = 0
                    if (k != null) logKind = k
                }
            }
            repo.requestOpen(null)
        }
    }

    val done = ended
    if (done != null) {
        BackHandler { repo.dismissJustEnded() }
        FastCompleteScreen(
            repo = repo,
            fast = done,
            onDone = { },
            onLogMeal = { logKind = LogKind.Meal },
        )
        val k2 = logKind
        if (k2 != null) FastLogSheet(repo, k2) { logKind = null }
        return
    }

    when (route) {
        Route.Main -> FastingMain(
            repo = repo,
            sub = sub,
            onSub = { sub = it },
            onPlans = { route = Route.Plans },
            onStages = { route = Route.Stages },
            onLog = { logKind = it },
            onCheckIn = { checkIn = true },
        )
        Route.Plans -> {
            BackHandler { route = Route.Main }
            PlansScreen(repo, onBack = { route = Route.Main }, onProgram = { route = Route.Program })
        }
        Route.Stages -> {
            BackHandler { route = Route.Main }
            StagesScreen(repo) { route = Route.Main }
        }
        Route.Program -> {
            BackHandler { route = Route.Plans }
            ProgramScreen(repo) { route = Route.Plans }
        }
    }

    val k = logKind
    if (k != null) FastLogSheet(repo, k) { logKind = null }
    if (checkIn) CheckInSheet(repo, onDismiss = { checkIn = false }, onEndFast = { repo.endFast() })
}

@Composable
private fun FastingMain(
    repo: Repo,
    sub: Int,
    onSub: (Int) -> Unit,
    onPlans: () -> Unit,
    onStages: () -> Unit,
    onLog: (LogKind) -> Unit,
    onCheckIn: () -> Unit,
) {
    val start by repo.fastStart.collectAsState()
    val goalCur by repo.goalHours.collectAsState()
    val base by repo.baseGoal.collectAsState()
    val same by repo.samePlan.collectAsState()
    val plans by repo.plans.collectAsState()
    val program by repo.program.collectAsState()

    val now = System.currentTimeMillis()
    val goal = if (start > 0L) goalCur else planGoalFor(now, base, same, plans, program)

    var journalDay by rememberSaveable { mutableStateOf(dayStart(now)) }
    var calendarOpen by remember { mutableStateOf(false) }
    var insightsRange by rememberSaveable { mutableStateOf(1) }

    val overline = when (sub) {
        0 -> SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(Date(now))
        1 -> SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(Date(journalDay))
        else -> insightsRangeText(insightsRange)
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 24.dp).padding(top = 16.dp)) {
            ScreenHeader(overline, "Fasting") {
                when (sub) {
                    0 -> Box(Modifier.padding(top = 6.dp)) { PlanPill(planLabel(goal), onPlans) }
                    1 -> Box(
                        Modifier
                            .padding(top = 6.dp)
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { calendarOpen = true },
                        contentAlignment = Alignment.Center,
                    ) { FIcon(R.drawable.ic_calendar, size = 20.dp) }
                    else -> {}
                }
            }
            Spacer(Modifier.height(14.dp))
            Segmented(listOf("Timer", "Journal", "Insights"), sub, onSub)
            Spacer(Modifier.height(8.dp))
        }
        when (sub) {
            0 -> TimerTab(repo, onStages, onLog, onCheckIn)
            1 -> JournalScreen(repo, journalDay, { journalDay = it }, calendarOpen) { calendarOpen = false }
            else -> InsightsScreen(repo, insightsRange) { insightsRange = it }
        }
    }
}
