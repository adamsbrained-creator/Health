package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.Types

private val hungerWords = listOf("Not hungry", "Slight", "Noticeable", "Strong", "Very strong")
private val energyWords = listOf("Drained", "Low", "Okay", "Good", "Great")
private val moodWords = listOf("Low", "Flat", "OK", "Good", "Great")
val symptomChoices = listOf(
    "Cravings", "Headache", "Dizzy", "Cold", "Irritable", "Brain fog", "Focused", "Calm", "Faint", "Nauseous",
)
private val warnSymptoms = setOf("Dizzy", "Faint", "Nauseous")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CheckInSheet(repo: Repo, onDismiss: () -> Unit, onEndFast: () -> Unit) {
    val start by repo.fastStart.collectAsState()
    val rem by repo.reminders.collectAsState()

    var hunger by remember { mutableStateOf(0) }
    var energy by remember { mutableStateOf(0) }
    var mood by remember { mutableStateOf(0) }
    var symptoms by remember { mutableStateOf(setOf<String>()) }
    var whenMs by remember { mutableStateOf(0L) }
    var editTime by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val at = if (whenMs == 0L) now else whenMs
    val fasting = start > 0L
    val elapsed = if (fasting) (at - start).coerceAtLeast(0L) else 0L
    val sub = if (fasting) "Hour ${elapsed / HOUR_MS} · ${fastingStages[stageIndexFor(elapsed)].name}" else "Not fasting right now"
    val warn = symptoms.any { it in warnSymptoms } && rem.suggestEnd && fasting
    val canSave = hunger > 0 || energy > 0 || mood > 0 || symptoms.isNotEmpty()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.background,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 20.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Check-in", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Sub(sub)
                }
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { editTime = true }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        if (whenMs == 0L) "Now · " + fmtClock(now) else fmtDateTime(at),
                        fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface,
                    )
                    FIcon(R.drawable.ic_pencil, size = 14.dp, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            ScaleBlock("Hunger", hunger, hungerWords, "Not hungry", "Very strong") { hunger = if (hunger == it) 0 else it }
            ScaleBlock("Energy", energy, energyWords, "Drained", "Great") { energy = if (energy == it) 0 else it }

            Spacer(Modifier.height(20.dp))
            Text("Mood", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                moodWords.forEachIndexed { i, w ->
                    val on = mood == i + 1
                    Box(
                        Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { mood = if (on) 0 else i + 1 },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            w, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                            color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Anything else?", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (s in symptomChoices) {
                    val on = s in symptoms
                    Box(
                        Modifier
                            .height(40.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { symptoms = if (on) symptoms - s else symptoms + s }
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            s, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                            color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }

            if (warn) {
                Spacer(Modifier.height(16.dp))
                SoftCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                        FIcon(R.drawable.ic_warn, size = 22.dp, tint = TrackAmber)
                        Column(Modifier.weight(1f)) {
                            Text("Feeling dizzy? Slow down.", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Sub(
                                "Sit down, drink water with a pinch of salt. If it doesn't pass, or you feel unwell, ending the fast is a good call.",
                                Modifier.padding(top = 2.dp), size = 13,
                            )
                            Spacer(Modifier.height(8.dp))
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(MaterialTheme.colorScheme.outlineVariant)
                                    .clickable {
                                        save(repo, at, hunger, energy, mood, symptoms)
                                        onEndFast()
                                        onDismiss()
                                    }
                                    .padding(horizontal = 14.dp, vertical = 11.dp),
                            ) { Text("End fast gently", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface) }
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            BlackButton("Save check-in") {
                if (canSave) {
                    save(repo, at, hunger, energy, mood, symptoms)
                    onDismiss()
                }
            }
        }
    }

    if (editTime) {
        AlertDialog(
            onDismissRequest = { editTime = false },
            confirmButton = { TextButton(onClick = { editTime = false }) { Text("Done") } },
            title = { Text("When") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(fmtFull(at), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Now", whenMs == 0L) { whenMs = 0L }
                        Pill("−15 m", false) { whenMs = shiftTime(whenMs, -15 * 60_000L) }
                        Pill("−1 h", false) { whenMs = shiftTime(whenMs, -HOUR_MS) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("+15 m", false) { whenMs = shiftTime(whenMs, 15 * 60_000L) }
                        Pill("+1 h", false) { whenMs = shiftTime(whenMs, HOUR_MS) }
                    }
                }
            },
        )
    }
}

private fun shiftTime(current: Long, delta: Long): Long {
    val now = System.currentTimeMillis()
    val next = (if (current == 0L) now else current) + delta
    return if (next >= now - 1000L) 0L else next
}

private fun save(repo: Repo, at: Long, hunger: Int, energy: Int, mood: Int, symptoms: Set<String>) {
    val t = minOf(at, System.currentTimeMillis())
    if (hunger > 0) repo.addEntry(Types.HUNGER, hunger.toDouble(), "", "app", t)
    if (energy > 0) repo.addEntry(Types.ENERGY, energy.toDouble(), "", "app", t)
    if (mood > 0) repo.addEntry(Types.MOOD, mood.toDouble(), "", "app", t)
    if (symptoms.isNotEmpty()) {
        val ordered = symptomChoices.filter { it in symptoms }
        repo.addEntry(Types.SYMPTOM, ordered.size.toDouble(), ordered.joinToString(", "), "app", t)
    }
}

@Composable
private fun ScaleBlock(
    title: String,
    value: Int,
    words: List<String>,
    low: String,
    high: String,
    onPick: (Int) -> Unit,
) {
    Spacer(Modifier.height(20.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        if (value > 0) Sub("$value · ${words[value - 1]}", size = 13)
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 1..5) {
            val on = value == i
            Box(
                Modifier
                    .weight(1f)
                    .height(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onPick(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "$i", fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    }
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Sub(low, size = 11)
        Sub(high, size = 11)
    }
}
