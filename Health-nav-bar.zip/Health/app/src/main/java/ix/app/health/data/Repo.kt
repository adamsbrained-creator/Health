package ix.app.health.data

import android.content.Context
import ix.app.health.widget.Widgets
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

object Types {
    const val WEIGHT = "weight"
    const val WATER = "water"
    const val SLEEP = "sleep"
    const val WORKOUT = "workout"
    const val SODIUM = "sodium"
    const val POTASSIUM = "potassium"
    const val MAGNESIUM = "magnesium"
    const val COFFEE = "coffee"
    const val KETONES = "ketones"
    const val GLUCOSE = "glucose"
    const val WAIST = "waist"
    const val MEAL = "meal"
    const val NOTE = "note"
    const val HUNGER = "hunger"
    const val ENERGY = "energy"
    const val MOOD = "mood"
    const val SYMPTOM = "symptom"

    val all = listOf(WEIGHT, WATER, SLEEP, WORKOUT)

    fun label(type: String): String = when (type) {
        WEIGHT -> "Weight"
        WATER -> "Water"
        SLEEP -> "Sleep"
        SODIUM -> "Sodium"
        POTASSIUM -> "Potassium"
        MAGNESIUM -> "Magnesium"
        COFFEE -> "Coffee"
        KETONES -> "Ketones"
        GLUCOSE -> "Glucose"
        WAIST -> "Waist"
        MEAL -> "Meal"
        NOTE -> "Note"
        HUNGER -> "Hunger"
        ENERGY -> "Energy"
        MOOD -> "Mood"
        SYMPTOM -> "Symptoms"
        else -> "Workout"
    }

    fun unit(type: String): String = when (type) {
        WEIGHT -> "kg"
        WATER -> "ml"
        SLEEP -> "h"
        SODIUM, POTASSIUM, MAGNESIUM -> "g"
        COFFEE -> "cup"
        KETONES, GLUCOSE -> "mmol/L"
        WAIST -> "cm"
        MEAL, NOTE -> ""
        HUNGER, ENERGY, MOOD -> "/5"
        SYMPTOM -> ""
        else -> "min"
    }
}

data class Entry(
    val id: Long,
    val type: String,
    val value: Double,
    val note: String,
    val time: Long,
    val source: String, // "app" or "widget"
)

data class FastRecord(
    val start: Long,
    val end: Long,
    val goal: Int = 23,
    val feel: Int = 0, // 0 not rated, 1 easy, 2 okay, 3 hard
    val note: String = "",
) {
    val duration: Long get() = end - start

    /** Reached its goal (30 min of slack). Flexi fasts count when they last 12 h or more. */
    val completed: Boolean
        get() = if (goal <= 0) duration >= 12 * HOUR_MS else duration >= goal * HOUR_MS - 30 * 60_000L
}

/** Everything on the Reminders screen. */
data class Reminders(
    val timerNotif: Boolean = true,
    val stageAlerts: Boolean = true,
    val halfwayGoal: Boolean = true,
    val checkIns: Boolean = true,
    val checkInChoices: List<Int> = listOf(6, 12, 14, 16),
    val checkInOn: List<Int> = listOf(12, 14),
    val hydration: Boolean = true,
    val hydrationEvery: Int = 2,
    val quietOn: Boolean = true,
    val quietStart: Int = 22 * 60 + 30,
    val quietEnd: Int = 7 * 60,
    val breakGuide: Boolean = true,
    val windowClosing: Boolean = true,
    val mealReminders: Boolean = false,
    val showReason: Boolean = true,
    val safetyCheck: Boolean = true,
    val suggestEnd: Boolean = true,
) {
    fun isQuiet(time: Long): Boolean {
        if (!quietOn) return false
        val c = Calendar.getInstance()
        c.timeInMillis = time
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return if (quietStart <= quietEnd) m in quietStart until quietEnd else (m >= quietStart || m < quietEnd)
    }
}

data class Targets(val sodium: Double, val potassium: Double, val magnesium: Double)

const val HOUR_MS = 3_600_000L
const val DAY_MS = 24L * HOUR_MS

fun dayStart(time: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = time
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun addDays(time: Long, days: Int): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = time
    c.add(Calendar.DAY_OF_YEAR, days)
    return c.timeInMillis
}

/**
 * Single source of truth. Everything is saved in SharedPreferences as small JSON strings.
 * The app screens and the home-screen widgets both go through this class,
 * so data logged from a widget shows up in the app straight away.
 */
class Repo private constructor(context: Context) {

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("health", Context.MODE_PRIVATE)

    private val _entries = MutableStateFlow(readEntries())
    val entries: StateFlow<List<Entry>> = _entries

    private val _fastStart = MutableStateFlow(prefs.getLong(K_FAST_START, 0L))
    val fastStart: StateFlow<Long> = _fastStart

    private val _fasts = MutableStateFlow(readFasts())
    val fasts: StateFlow<List<FastRecord>> = _fasts

    private val _goalHours = MutableStateFlow(prefs.getInt(K_GOAL, 23))
    val goalHours: StateFlow<Int> = _goalHours

    private val _waterGoal = MutableStateFlow(prefs.getInt(K_WATER_GOAL, 2500))
    val waterGoal: StateFlow<Int> = _waterGoal

    private val _accent = MutableStateFlow(prefs.getInt(K_ACCENT, 0))
    val accent: StateFlow<Int> = _accent

    private val _baseGoal = MutableStateFlow(prefs.getInt(K_BASE, prefs.getInt(K_GOAL, 23)))
    val baseGoal: StateFlow<Int> = _baseGoal

    private val _layout = MutableStateFlow(prefs.getInt(K_LAYOUT, 0))
    val layout: StateFlow<Int> = _layout

    /** 0 = Classic, 1 = Nothing. */
    private val _style = MutableStateFlow(prefs.getInt(K_STYLE, 0))
    val style: StateFlow<Int> = _style

    private val _reason = MutableStateFlow(prefs.getString(K_REASON, "") ?: "")
    val reason: StateFlow<String> = _reason

    private val _reminderOn = MutableStateFlow(prefs.getBoolean(K_REMIND_ON, true))
    val reminderOn: StateFlow<Boolean> = _reminderOn

    private val _reminderLead = MutableStateFlow(prefs.getInt(K_REMIND_LEAD, 15))
    val reminderLead: StateFlow<Int> = _reminderLead

    private val _targets = MutableStateFlow(
        Targets(
            prefs.getFloat(K_NA, 3.0f).toDouble(),
            prefs.getFloat(K_K, 3.0f).toDouble(),
            prefs.getFloat(K_MG, 0.3f).toDouble(),
        )
    )
    val targets: StateFlow<Targets> = _targets

    private val _samePlan = MutableStateFlow(prefs.getBoolean(K_SAME, true))
    val samePlan: StateFlow<Boolean> = _samePlan

    private val _plans = MutableStateFlow(readPlans())
    val plans: StateFlow<List<CustomPlan>> = _plans

    private val _program = MutableStateFlow(readProgram())
    val program: StateFlow<ProgramState?> = _program

    private val _scheduled = MutableStateFlow(prefs.getLong(K_SCHED, 0L))
    val scheduledStart: StateFlow<Long> = _scheduled

    private val _rem = MutableStateFlow(readReminders())
    val reminders: StateFlow<Reminders> = _rem

    fun updateReminders(f: (Reminders) -> Reminders) {
        _rem.value = f(_rem.value)
        val r = _rem.value
        val o = JSONObject()
        o.put("timerNotif", r.timerNotif)
        o.put("stageAlerts", r.stageAlerts)
        o.put("halfwayGoal", r.halfwayGoal)
        o.put("checkIns", r.checkIns)
        o.put("checkInChoices", JSONArray(r.checkInChoices))
        o.put("checkInOn", JSONArray(r.checkInOn))
        o.put("hydration", r.hydration)
        o.put("hydrationEvery", r.hydrationEvery)
        o.put("quietOn", r.quietOn)
        o.put("quietStart", r.quietStart)
        o.put("quietEnd", r.quietEnd)
        o.put("breakGuide", r.breakGuide)
        o.put("windowClosing", r.windowClosing)
        o.put("mealReminders", r.mealReminders)
        o.put("showReason", r.showReason)
        o.put("safetyCheck", r.safetyCheck)
        o.put("suggestEnd", r.suggestEnd)
        prefs.edit().putString(K_REM, o.toString()).apply()
        Widgets.updateAll(app)
    }

    private fun readReminders(): Reminders {
        val raw = prefs.getString(K_REM, null) ?: return Reminders()
        return try {
            val o = JSONObject(raw)
            val d = Reminders()
            fun ints(name: String, def: List<Int>): List<Int> {
                val a = o.optJSONArray(name) ?: return def
                val out = ArrayList<Int>()
                for (i in 0 until a.length()) out.add(a.getInt(i))
                return out
            }
            Reminders(
                o.optBoolean("timerNotif", d.timerNotif),
                o.optBoolean("stageAlerts", d.stageAlerts),
                o.optBoolean("halfwayGoal", d.halfwayGoal),
                o.optBoolean("checkIns", d.checkIns),
                ints("checkInChoices", d.checkInChoices),
                ints("checkInOn", d.checkInOn),
                o.optBoolean("hydration", d.hydration),
                o.optInt("hydrationEvery", d.hydrationEvery),
                o.optBoolean("quietOn", d.quietOn),
                o.optInt("quietStart", d.quietStart),
                o.optInt("quietEnd", d.quietEnd),
                o.optBoolean("breakGuide", d.breakGuide),
                o.optBoolean("windowClosing", d.windowClosing),
                o.optBoolean("mealReminders", d.mealReminders),
                o.optBoolean("showReason", d.showReason),
                o.optBoolean("safetyCheck", d.safetyCheck),
                o.optBoolean("suggestEnd", d.suggestEnd),
            )
        } catch (e: Exception) {
            Reminders()
        }
    }

    // ---- glucose unit, last-ended fast, deep links, fired alerts ----

    private val _glucoseMgdl = MutableStateFlow(prefs.getBoolean(K_GLU, false))
    val glucoseMgdl: StateFlow<Boolean> = _glucoseMgdl

    fun setGlucoseMgdl(on: Boolean) {
        _glucoseMgdl.value = on
        prefs.edit().putBoolean(K_GLU, on).apply()
    }

    private val _justEnded = MutableStateFlow<FastRecord?>(null)
    /** Set when a fast ends; the "Fast complete" screen shows it until it is dismissed. */
    val justEnded: StateFlow<FastRecord?> = _justEnded

    fun dismissJustEnded() {
        _justEnded.value = null
    }

    private val _open = MutableStateFlow<String?>(null)
    /** A request from a notification or widget to open something, e.g. "stages" or "log:Meal". */
    val openRequest: StateFlow<String?> = _open

    fun requestOpen(what: String?) {
        _open.value = what
    }

    fun hasFired(key: String): Boolean = prefs.getStringSet(K_FIRED, emptySet())?.contains(key) == true

    fun markFired(key: String) {
        val cur = HashSet(prefs.getStringSet(K_FIRED, emptySet()) ?: emptySet())
        cur.add(key)
        // keep this small: drop the oldest when it grows
        val keep = if (cur.size > 200) cur.toList().takeLast(120).toHashSet() else cur
        prefs.edit().putStringSet(K_FIRED, keep).apply()
    }

    fun setLayout(i: Int) {
        _layout.value = i
        prefs.edit().putInt(K_LAYOUT, i).apply()
    }

    fun setReason(text: String) {
        _reason.value = text.trim()
        prefs.edit().putString(K_REASON, _reason.value).apply()
    }

    fun setReminderOn(on: Boolean) {
        _reminderOn.value = on
        prefs.edit().putBoolean(K_REMIND_ON, on).apply()
        Widgets.updateAll(app)
    }

    fun setReminderLead(min: Int) {
        _reminderLead.value = min.coerceIn(5, 60)
        prefs.edit().putInt(K_REMIND_LEAD, _reminderLead.value).apply()
        Widgets.updateAll(app)
    }

    fun setTargets(t: Targets) {
        val n = Targets(
            t.sodium.coerceIn(0.5, 10.0),
            t.potassium.coerceIn(0.5, 10.0),
            t.magnesium.coerceIn(0.1, 2.0),
        )
        _targets.value = n
        prefs.edit()
            .putFloat(K_NA, n.sodium.toFloat())
            .putFloat(K_K, n.potassium.toFloat())
            .putFloat(K_MG, n.magnesium.toFloat())
            .apply()
    }

    fun setSamePlan(same: Boolean) {
        _samePlan.value = same
        prefs.edit().putBoolean(K_SAME, same).apply()
    }

    fun goalFor(time: Long): Int =
        planGoalFor(time, _baseGoal.value, _samePlan.value, _plans.value, _program.value)

    // ---- custom plans ----

    fun savePlan(p: CustomPlan) {
        _plans.value = _plans.value.filter { it.id != p.id } + p
        savePlans()
    }

    fun deletePlan(id: Long) {
        _plans.value = _plans.value.filter { it.id != id }
        savePlans()
    }

    // ---- programs ----

    fun startProgram(id: String) {
        setProgram(ProgramState(id, dayStart(System.currentTimeMillis())))
    }

    fun endProgram() = setProgram(null)

    fun pauseProgram(paused: Boolean) {
        _program.value?.let { setProgram(it.copy(paused = paused)) }
    }

    fun skipProgramDay(idx: Int) {
        _program.value?.let { setProgram(it.copy(skipped = it.skipped + idx)) }
    }

    fun lighterProgramDay(idx: Int) {
        _program.value?.let { setProgram(it.copy(lighter = it.lighter + idx, skipped = it.skipped - idx)) }
    }

    private fun setProgram(p: ProgramState?) {
        _program.value = p
        if (p == null) {
            prefs.edit().remove(K_PROGRAM).apply()
        } else {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("start", p.startDay)
            o.put("skipped", JSONArray(p.skipped.toList()))
            o.put("lighter", JSONArray(p.lighter.toList()))
            o.put("paused", p.paused)
            prefs.edit().putString(K_PROGRAM, o.toString()).apply()
        }
        Widgets.updateAll(app)
    }

    // ---- planned start ----

    fun scheduleStart(at: Long) {
        _scheduled.value = at
        prefs.edit().putLong(K_SCHED, at).apply()
        Widgets.updateAll(app)
    }

    fun cancelScheduledStart() = scheduleStart(0L)

    /** Starts the fast if its planned time has come. Safe to call at any moment. */
    fun applyScheduledStart(): Boolean {
        val at = _scheduled.value
        if (at <= 0L || at > System.currentTimeMillis()) return false
        _scheduled.value = 0L
        prefs.edit().putLong(K_SCHED, 0L).apply()
        if (_fastStart.value == 0L) {
            startFast(at)
            return true
        }
        Widgets.updateAll(app)
        return false
    }

    // ---- quick sums ----

    fun sum(type: String, from: Long, to: Long = Long.MAX_VALUE): Double {
        var t = 0.0
        for (e in _entries.value) if (e.type == type && e.time >= from && e.time < to) t += e.value
        return t
    }

    fun count(type: String, from: Long, to: Long = Long.MAX_VALUE): Int =
        _entries.value.count { it.type == type && it.time >= from && it.time < to }

    fun setAccent(index: Int) {
        _accent.value = index
        prefs.edit().putInt(K_ACCENT, index).apply()
    }

    fun setStyle(index: Int) {
        _style.value = index
        prefs.edit().putInt(K_STYLE, index).apply()
        Widgets.updateAll(app)
    }

    // ---- entries -------------------------------------------------------

    fun addEntry(
        type: String,
        value: Double,
        note: String = "",
        source: String = "app",
        time: Long = System.currentTimeMillis(),
    ) {
        val now = System.currentTimeMillis()
        // ids are timestamps; make sure two entries saved together never share one
        val id = maxOf(now, (_entries.value.maxOfOrNull { it.id } ?: 0L) + 1L)
        val entry = Entry(id, type, value, note, time, source)
        _entries.value = (_entries.value + entry).sortedBy { it.time }
        saveEntries()
        Widgets.updateAll(app)
    }

    fun deleteEntry(id: Long) {
        _entries.value = _entries.value.filter { it.id != id }
        saveEntries()
        Widgets.updateAll(app)
    }

    fun latest(type: String): Entry? = _entries.value.lastOrNull { it.type == type }

    fun waterToday(): Int {
        val from = dayStart(System.currentTimeMillis())
        var sum = 0.0
        for (e in _entries.value) {
            if (e.type == Types.WATER && e.time >= from) sum += e.value
        }
        return sum.toInt()
    }

    // ---- fasting -------------------------------------------------------

    fun startFast(at: Long = System.currentTimeMillis()) {
        val start = minOf(at, System.currentTimeMillis())
        if (_fastStart.value == 0L) {
            val g = goalFor(start)
            if (g != _goalHours.value) {
                _goalHours.value = g
                prefs.edit().putInt(K_GOAL, g).apply()
            }
            if (_scheduled.value > 0L) {
                _scheduled.value = 0L
                prefs.edit().putLong(K_SCHED, 0L).apply()
            }
        }
        _fastStart.value = start
        prefs.edit().putLong(K_FAST_START, start).apply()
        Widgets.updateAll(app)
    }

    fun endFast() {
        val start = _fastStart.value
        if (start > 0L) {
            val rec = FastRecord(start, System.currentTimeMillis(), _goalHours.value)
            _fasts.value = (_fasts.value + rec).sortedBy { it.start }.takeLast(1000)
            _justEnded.value = rec
            saveFasts()
        }
        _fastStart.value = 0L
        prefs.edit().putLong(K_FAST_START, 0L).apply()
        Widgets.updateAll(app)
    }

    fun toggleFast() {
        if (_fastStart.value > 0L) endFast() else startFast()
    }

    fun addFast(f: FastRecord) {
        _fasts.value = (_fasts.value + f).sortedBy { it.start }.takeLast(1000)
        saveFasts()
        Widgets.updateAll(app)
    }

    /** Saves how a fast felt and a note about it. */
    fun rateFast(f: FastRecord, feel: Int, note: String) {
        val upd = f.copy(feel = feel, note = note.trim())
        replaceFast(f, upd)
        if (_justEnded.value == f) _justEnded.value = upd
    }

    fun deleteFast(f: FastRecord) {
        _fasts.value = _fasts.value.filter { it != f }
        saveFasts()
        Widgets.updateAll(app)
    }

    fun replaceFast(old: FastRecord, new: FastRecord) {
        _fasts.value = (_fasts.value.filter { it != old } + new).sortedBy { it.start }
        saveFasts()
        Widgets.updateAll(app)
    }

    /** 0 = Flexi (no goal), otherwise the fasting hours (1..72). */
    fun setGoalHours(hours: Int) {
        val h = hours.coerceIn(0, 72)
        _goalHours.value = h
        _baseGoal.value = h
        prefs.edit().putInt(K_GOAL, h).putInt(K_BASE, h).apply()
        Widgets.updateAll(app)
    }

    fun setWaterGoal(ml: Int) {
        val v = ml.coerceIn(1000, 6000)
        _waterGoal.value = v
        prefs.edit().putInt(K_WATER_GOAL, v).apply()
        Widgets.updateAll(app)
    }

    // ---- storage -------------------------------------------------------

    private fun readEntries(): List<Entry> {
        val raw = prefs.getString(K_ENTRIES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Entry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Entry(
                        id = o.getLong("id"),
                        type = o.getString("type"),
                        value = o.getDouble("value"),
                        note = o.optString("note", ""),
                        time = o.getLong("time"),
                        source = o.optString("source", "app"),
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveEntries() {
        val arr = JSONArray()
        for (e in _entries.value) {
            val o = JSONObject()
            o.put("id", e.id)
            o.put("type", e.type)
            o.put("value", e.value)
            o.put("note", e.note)
            o.put("time", e.time)
            o.put("source", e.source)
            arr.put(o)
        }
        prefs.edit().putString(K_ENTRIES, arr.toString()).apply()
    }

    private fun readFasts(): List<FastRecord> {
        val raw = prefs.getString(K_FASTS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<FastRecord>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    FastRecord(
                        o.getLong("start"), o.getLong("end"), o.optInt("goal", 23),
                        o.optInt("feel", 0), o.optString("note", ""),
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveFasts() {
        val arr = JSONArray()
        for (f in _fasts.value) {
            val o = JSONObject()
            o.put("start", f.start)
            o.put("end", f.end)
            o.put("goal", f.goal)
            if (f.feel != 0) o.put("feel", f.feel)
            if (f.note.isNotEmpty()) o.put("note", f.note)
            arr.put(o)
        }
        prefs.edit().putString(K_FASTS, arr.toString()).apply()
    }

    private fun readPlans(): List<CustomPlan> {
        val raw = prefs.getString(K_PLANS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<CustomPlan>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(CustomPlan(o.getLong("id"), o.getString("name"), o.getInt("fast"), o.getInt("eat"), o.getInt("days")))
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun savePlans() {
        val arr = JSONArray()
        for (p in _plans.value) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            o.put("fast", p.fastHours)
            o.put("eat", p.eatStartMin)
            o.put("days", p.days)
            arr.put(o)
        }
        prefs.edit().putString(K_PLANS, arr.toString()).apply()
    }

    private fun intSet(a: JSONArray?): Set<Int> {
        val s = HashSet<Int>()
        if (a != null) for (i in 0 until a.length()) s.add(a.getInt(i))
        return s
    }

    private fun readProgram(): ProgramState? {
        val raw = prefs.getString(K_PROGRAM, null) ?: return null
        return try {
            val o = JSONObject(raw)
            ProgramState(
                o.getString("id"),
                o.getLong("start"),
                intSet(o.optJSONArray("skipped")),
                intSet(o.optJSONArray("lighter")),
                o.optBoolean("paused", false),
            )
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        private const val K_REM = "reminders"
        private const val K_GLU = "glucose_mgdl"
        private const val K_FIRED = "fired_alerts"
        private const val K_BASE = "base_goal"
        private const val K_LAYOUT = "layout"
        private const val K_REASON = "reason"
        private const val K_REMIND_ON = "remind_on"
        private const val K_REMIND_LEAD = "remind_lead"
        private const val K_NA = "target_na"
        private const val K_K = "target_k"
        private const val K_MG = "target_mg"
        private const val K_SAME = "same_plan"
        private const val K_PLANS = "custom_plans"
        private const val K_PROGRAM = "program"
        private const val K_SCHED = "scheduled_start"

        private const val K_ENTRIES = "entries"
        private const val K_FASTS = "fasts"
        private const val K_FAST_START = "fast_start"
        private const val K_GOAL = "goal_hours"
        private const val K_WATER_GOAL = "water_goal_ml"
        private const val K_ACCENT = "accent"
        private const val K_STYLE = "style"

        @Volatile
        private var instance: Repo? = null

        fun get(context: Context): Repo {
            return instance ?: synchronized(this) {
                instance ?: Repo(context).also { instance = it }
            }
        }
    }
}
