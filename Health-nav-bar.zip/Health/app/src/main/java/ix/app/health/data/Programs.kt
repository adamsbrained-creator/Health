package ix.app.health.data

import java.util.Calendar

/** Monday = 0 ... Sunday = 6 */
fun weekdayIndex(time: Long): Int {
    val c = Calendar.getInstance()
    c.timeInMillis = time
    return (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
}

fun weekStart(time: Long): Long = addDays(dayStart(time), -weekdayIndex(time))

/** A plan you built yourself. [days] is a bit mask: bit 0 = Monday ... bit 6 = Sunday. */
data class CustomPlan(
    val id: Long,
    val name: String,
    val fastHours: Int,
    val eatStartMin: Int, // minute of the day when eating starts
    val days: Int,
) {
    fun covers(dayIdx: Int): Boolean = (days and (1 shl dayIdx)) != 0
}

data class Program(
    val id: String,
    val name: String,
    val days: Int,
    val level: String,
    val blurb: String,
    val range: String,
    val lightHours: Int,
    val baseHours: (Int) -> Int,
    val lighterByDefault: (Int) -> Boolean,
)

val programs: List<Program> = listOf(
    Program(
        id = "easy",
        name = "7-day Easy Start",
        days = 7,
        level = "Beginner",
        blurb = "Ease in gently, from 12 : 12 up to 14 : 10 over one week.",
        range = "1 week · 12:12 up to 14:10",
        lightHours = 12,
        baseHours = { d -> listOf(12, 12, 13, 13, 14, 14, 14).getOrElse(d) { 14 } },
        lighterByDefault = { false },
    ),
    Program(
        id = "step",
        name = "14-day Step Up",
        days = 14,
        level = "Beginner",
        blurb = "Build from 14 : 10 up to 16 : 8 over two weeks.",
        range = "2 weeks · 14:10 up to 16:8",
        lightHours = 14,
        baseHours = { d -> if (d < 4) 14 else if (d < 9) 15 else 16 },
        lighterByDefault = { false },
    ),
    Program(
        id = "rhythm",
        name = "21-day Rhythm",
        days = 21,
        level = "Intermediate",
        blurb = "Hold 18 : 6 for three weeks, with one lighter 14 : 10 day each week.",
        range = "3 weeks · 18:6 with a lighter day a week",
        lightHours = 14,
        baseHours = { 18 },
        lighterByDefault = { d -> d % 7 == 2 },
    ),
)

fun programById(id: String): Program? = programs.firstOrNull { it.id == id }

data class ProgramState(
    val id: String,
    val startDay: Long,
    val skipped: Set<Int> = emptySet(),
    val lighter: Set<Int> = emptySet(),
    val paused: Boolean = false,
)

/** 0-based day of the program for [time]. */
fun programDay(state: ProgramState, time: Long): Int =
    Math.round((dayStart(time) - state.startDay) / DAY_MS.toDouble()).toInt()

fun programIsLighter(def: Program, st: ProgramState, idx: Int): Boolean =
    idx in st.lighter || def.lighterByDefault(idx)

fun programHours(def: Program, st: ProgramState, idx: Int): Int {
    val base = def.baseHours(idx)
    return if (programIsLighter(def, st, idx)) minOf(base, def.lightHours) else base
}

/** The plan (fast hours, 0 = Flexi) that applies on the day of [time]. */
fun planGoalFor(
    time: Long,
    base: Int,
    same: Boolean,
    plans: List<CustomPlan>,
    program: ProgramState?,
): Int {
    if (program != null && !program.paused) {
        val def = programById(program.id)
        val idx = programDay(program, time)
        if (def != null && idx in 0 until def.days && idx !in program.skipped) {
            return programHours(def, program, idx)
        }
    }
    if (!same) {
        val p = plans.firstOrNull { it.covers(weekdayIndex(time)) }
        if (p != null) return p.fastHours
    }
    return base
}
