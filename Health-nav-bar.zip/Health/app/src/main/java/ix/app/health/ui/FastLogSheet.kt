package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.Types
import ix.app.health.data.dayStart
import kotlin.math.roundToInt

enum class LogKind(val label: String) {
    Water("Water"),
    Electrolytes("Electrolytes"),
    Coffee("Coffee & tea"),
    Ketones("Ketones"),
    Glucose("Glucose"),
    Weight("Weight"),
    Waist("Waist & body"),
    Sleep("Sleep"),
    Meal("Meal"),
    Note("Note"),
}

private data class Pick(
    val title: String,
    val sub: String,
    val na: Double = 0.0,
    val k: Double = 0.0,
    val mg: Double = 0.0,
    val value: Double = 0.0,
    val note: String = "",
)

private fun picksFor(kind: LogKind): List<Pick> = when (kind) {
    LogKind.Electrolytes -> listOf(
        Pick("Salt pinch", "0.6 g sodium", na = 0.6),
        Pick("Electrolyte drink", "0.5 g Na · 0.2 g K", na = 0.5, k = 0.2),
        Pick("Magnesium capsule", "0.1 g magnesium", mg = 0.1),
    )
    LogKind.Water -> listOf(
        Pick("Glass", "250 ml", value = 250.0),
        Pick("Mug", "350 ml", value = 350.0),
        Pick("Bottle", "500 ml", value = 500.0),
    )
    LogKind.Coffee -> listOf(
        Pick("Black coffee", "1 cup", value = 1.0, note = "Black coffee"),
        Pick("Espresso", "1 cup", value = 1.0, note = "Espresso"),
        Pick("Tea", "1 cup", value = 1.0, note = "Tea"),
    )
    else -> emptyList()
}

private fun type(kind: LogKind): String = when (kind) {
    LogKind.Water -> Types.WATER
    LogKind.Coffee -> Types.COFFEE
    LogKind.Ketones -> Types.KETONES
    LogKind.Glucose -> Types.GLUCOSE
    LogKind.Weight -> Types.WEIGHT
    LogKind.Waist -> Types.WAIST
    LogKind.Sleep -> Types.SLEEP
    LogKind.Meal -> Types.MEAL
    LogKind.Note -> Types.NOTE
    LogKind.Electrolytes -> Types.SODIUM
}

private fun stepOf(kind: LogKind): Double = when (kind) {
    LogKind.Water -> 50.0
    LogKind.Coffee -> 1.0
    LogKind.Ketones, LogKind.Glucose, LogKind.Weight -> 0.1
    LogKind.Waist -> 0.5
    LogKind.Sleep -> 5.0 / 60.0
    else -> 1.0
}

private fun defaultOf(kind: LogKind, repo: Repo): Double = when (kind) {
    LogKind.Water -> 250.0
    LogKind.Coffee -> 1.0
    LogKind.Ketones -> 0.5
    LogKind.Glucose -> 4.8
    LogKind.Weight -> repo.latest(Types.WEIGHT)?.value ?: 70.0
    LogKind.Waist -> repo.latest(Types.WAIST)?.value ?: 80.0
    LogKind.Sleep -> 7.5
    else -> 0.0
}

private fun roundTo(kind: LogKind, v: Double): Double = when (kind) {
    LogKind.Water -> (v / 50.0).roundToInt() * 50.0
    LogKind.Coffee -> v.roundToInt().toDouble()
    LogKind.Waist -> (v * 2).roundToInt() / 2.0
    LogKind.Sleep -> (v * 60).roundToInt() / 60.0
    else -> (v * 10).roundToInt() / 10.0
}

private fun round2(v: Double): Double = (v * 100).roundToInt() / 100.0

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FastLogSheet(repo: Repo, initial: LogKind, onDismiss: () -> Unit) {
    val targets by repo.targets.collectAsState()
    val waterGoal by repo.waterGoal.collectAsState()

    var kind by remember { mutableStateOf(initial) }
    var whenMs by remember { mutableStateOf(0L) }
    var editTime by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var single by remember(kind) { mutableStateOf(defaultOf(kind, repo)) }
    var na by remember(kind) { mutableStateOf(0.5) }
    var pot by remember(kind) { mutableStateOf(0.2) }
    var mg by remember(kind) { mutableStateOf(0.0) }
    var pick by remember(kind) { mutableStateOf(if (kind == LogKind.Electrolytes) 1 else -1) }
    var mgdl by remember(kind) { mutableStateOf(repo.glucoseMgdl.value) }

    val now = System.currentTimeMillis()
    val at = if (whenMs == 0L) now else whenMs
    val today = dayStart(at)
    val tomorrow = today + 24 * HOUR_MS

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .imePadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 20.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Log", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { editTime = true }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        if (whenMs == 0L) "Now · " + fmtClock(now) else fmtDateTime(at),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    FIcon(ix.app.health.R.drawable.ic_pencil, size = 14.dp, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(12.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for (k in LogKind.values()) {
                    val on = k == kind
                    Box(
                        modifier = Modifier
                            .height(40.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { kind = k }
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            k.label,
                            fontSize = 14.sp,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                            color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }

            // ---- quick picks ----
            val picks = picksFor(kind)
            if (picks.isNotEmpty()) {
                Spacer(Modifier.height(20.dp))
                Sub("Quick picks")
                Spacer(Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    picks.forEachIndexed { i, p ->
                        val on = i == pick
                        Column(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .border(
                                    if (on) 2.dp else 1.5.dp,
                                    if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    RoundedCornerShape(14.dp),
                                )
                                .clickable {
                                    pick = i
                                    if (kind == LogKind.Electrolytes) {
                                        na = p.na
                                        pot = p.k
                                        mg = p.mg
                                    } else {
                                        single = p.value
                                        note = p.note
                                    }
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                        ) {
                            Text(p.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Sub(p.sub, size = 11)
                        }
                    }
                }
            }

            // ---- steppers ----
            if (kind != LogKind.Meal && kind != LogKind.Note) {
                Spacer(Modifier.height(18.dp))
                SoftCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        if (kind == LogKind.Electrolytes) {
                            val sNa = repo.sum(Types.SODIUM, today, tomorrow)
                            val sK = repo.sum(Types.POTASSIUM, today, tomorrow)
                            val sMg = repo.sum(Types.MAGNESIUM, today, tomorrow)
                            StepRow(
                                TrackBlue, "Sodium",
                                "Today ${fmtNum(round2(sNa))} g → ${fmtNum(round2(sNa + na))} g of ${fmtNum(targets.sodium)} g",
                                fmtG(na), { na = round2((na - 0.1).coerceAtLeast(0.0)); pick = -1 }, { na = round2(na + 0.1); pick = -1 },
                            )
                            StepRow(
                                TrackAmber, "Potassium",
                                "Today ${fmtNum(round2(sK))} g → ${fmtNum(round2(sK + pot))} g of ${fmtNum(targets.potassium)} g",
                                fmtG(pot), { pot = round2((pot - 0.1).coerceAtLeast(0.0)); pick = -1 }, { pot = round2(pot + 0.1); pick = -1 },
                            )
                            StepRow(
                                TrackPurple, "Magnesium",
                                "Today ${fmtNum(round2(sMg))} g → ${fmtNum(round2(sMg + mg))} g of ${fmtNum(targets.magnesium)} g",
                                fmtG(mg), { mg = round2((mg - 0.05).coerceAtLeast(0.0)); pick = -1 }, { mg = round2(mg + 0.05); pick = -1 },
                                last = true,
                            )
                        } else {
                            val factor = when {
                                !mgdl -> 1.0
                                kind == LogKind.Glucose -> 18.016
                                else -> 10.4
                            }
                            val shown = when (kind) {
                                LogKind.Water -> fmtNum(single)
                                LogKind.Coffee -> fmtNum(single)
                                LogKind.Sleep -> fmtSleep(single)
                                LogKind.Waist -> fmtNum(single)
                                else -> if (mgdl) (single * factor).roundToInt().toString()
                                else String.format(java.util.Locale.US, "%.1f", single)
                            }
                            val unit = when (kind) {
                                LogKind.Water -> "ml"
                                LogKind.Coffee -> "cups"
                                LogKind.Sleep -> "hours and minutes"
                                LogKind.Waist -> "cm"
                                LogKind.Weight -> "kg"
                                else -> if (mgdl) "mg/dL" else "mmol/L"
                            }
                            val dot = when (kind) {
                                LogKind.Water -> TrackBlue
                                LogKind.Coffee -> MaterialTheme.colorScheme.onSurfaceVariant
                                else -> MaterialTheme.colorScheme.primary
                            }
                            val sub = when (kind) {
                                LogKind.Water -> {
                                    val w = repo.sum(Types.WATER, today, tomorrow)
                                    "Today ${fmtL(w)} L → ${fmtL(w + single)} L of ${fmtL(waterGoal.toDouble())} L"
                                }
                                LogKind.Coffee -> "Today ${fmtNum(repo.sum(Types.COFFEE, today, tomorrow))} cups"
                                else -> unit
                            }
                            val step = if (mgdl && (kind == LogKind.Glucose || kind == LogKind.Ketones)) 1.0 / factor else stepOf(kind)
                            StepRow(
                                dot, kind.label, sub, shown,
                                { single = roundStep(kind, (single - step).coerceAtLeast(0.0), mgdl); pick = -1 },
                                { single = roundStep(kind, single + step, mgdl); pick = -1 },
                                last = true,
                            )
                        }
                    }
                }
                if (kind == LogKind.Ketones || kind == LogKind.Glucose) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("mmol/L", !mgdl) { mgdl = false; repo.setGlucoseMgdl(false) }
                        Pill("mg/dL", mgdl) { mgdl = true; repo.setGlucoseMgdl(true) }
                    }
                }
            }

            // ---- note ----
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                placeholder = {
                    Text(if (kind == LogKind.Note) "Write your note" else if (kind == LogKind.Meal) "What did you eat? (optional)" else "Add a note (optional)")
                },
                singleLine = kind != LogKind.Note,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FIcon(ix.app.health.R.drawable.ic_info, size = 16.dp, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Sub(
                    "Targets are yours to set in Settings. Blood ketones and glucose accept mmol/L or mg/dL.",
                    size = 12,
                )
            }

            Spacer(Modifier.height(18.dp))
            val canSave = when (kind) {
                LogKind.Electrolytes -> na > 0 || pot > 0 || mg > 0
                LogKind.Note -> note.isNotBlank()
                else -> true
            }
            BlackButton("Save " + kind.label.lowercase().replace(" & body", "")) {
                if (!canSave) return@BlackButton
                val n = note.trim()
                val t = minOf(at, System.currentTimeMillis())
                when (kind) {
                    LogKind.Electrolytes -> {
                        if (na > 0) repo.addEntry(Types.SODIUM, na, n, "app", t)
                        if (pot > 0) repo.addEntry(Types.POTASSIUM, pot, "", "app", t)
                        if (mg > 0) repo.addEntry(Types.MAGNESIUM, mg, "", "app", t)
                    }
                    LogKind.Meal -> repo.addEntry(Types.MEAL, 1.0, n, "app", t)
                    LogKind.Note -> repo.addEntry(Types.NOTE, 0.0, n, "app", t)
                    else -> repo.addEntry(type(kind), single, n, "app", t)
                }
                onDismiss()
            }
        }
    }

    if (editTime) {
        AlertDialog(
            onDismissRequest = { editTime = false },
            confirmButton = { TextButton(onClick = { editTime = false }) { Text("Done") } },
            title = { Text("When") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(fmtFull(at), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Now", whenMs == 0L) { whenMs = 0L }
                        Pill("−15 m", false) { whenMs = shift(whenMs, -15 * 60_000L) }
                        Pill("−1 h", false) { whenMs = shift(whenMs, -HOUR_MS) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("+15 m", false) { whenMs = shift(whenMs, 15 * 60_000L) }
                        Pill("+1 h", false) { whenMs = shift(whenMs, HOUR_MS) }
                        Pill("−1 day", false) { whenMs = shift(whenMs, -24 * HOUR_MS) }
                    }
                }
            },
        )
    }
}

private fun shift(current: Long, delta: Long): Long {
    val now = System.currentTimeMillis()
    val next = (if (current == 0L) now else current) + delta
    return if (next >= now - 1000L) 0L else next
}

private fun roundStep(kind: LogKind, v: Double, mgdl: Boolean): Double =
    if (mgdl && (kind == LogKind.Glucose || kind == LogKind.Ketones)) v else roundTo(kind, v)

@Composable
private fun StepRow(
    dot: Color,
    name: String,
    sub: String,
    value: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit,
    last: Boolean = false,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
                Text(name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            }
            Sub(sub, Modifier.padding(top = 2.dp))
        }
        RepeatStepButton("−", onMinus)
        Text(
            value,
            fontSize = if (value.length > 6) 17.sp else 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.width(64.dp),
        )
        RepeatStepButton("+", onPlus)
    }
    if (!last) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(MaterialTheme.colorScheme.outlineVariant),
        )
    }
}
