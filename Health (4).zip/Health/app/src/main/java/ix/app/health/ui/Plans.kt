package ix.app.health.ui

import ix.app.health.data.FastRecord
import ix.app.health.data.HOUR_MS
import ix.app.health.data.addDays
import ix.app.health.data.dayStart

/** 0 = Flexi. 16 -> "16 : 8". 36 -> "36h". */
fun planLabel(goal: Int): String = when {
    goal <= 0 -> "Flexi"
    goal < 24 -> "$goal : ${24 - goal}"
    else -> "${goal}h"
}

/** Second line of a plan tile. */
fun planDetail(goal: Int): String = when {
    goal <= 0 -> "Fast as long as you want"
    goal < 24 -> "${goal}h fast · ${24 - goal}h eating"
    else -> "${goal}h fast"
}

val planGroups: List<Pair<String, List<Int>>> = listOf(
    "Beginner" to listOf(11, 12, 13, 14, 15),
    "Intermediate" to listOf(16, 17, 18, 19),
    "Advanced" to listOf(20, 21, 22, 23),
    "Long fasts" to listOf(24, 36, 42, 48, 72),
)

data class Stage(val hour: Int, val name: String, val text: String)

/** A general, typical timeline. It differs from person to person. */
val fastingStages = listOf(
    Stage(0, "Digesting", "Your body is processing your last meal and blood sugar is higher."),
    Stage(4, "Sugar settling", "Insulin falls and blood sugar starts to come back down."),
    Stage(8, "Using stored sugar", "Your body draws on stored glycogen for energy."),
    Stage(12, "Switching to fat", "Glycogen runs lower and fat burning picks up."),
    Stage(16, "Ketones rising", "Your liver makes more ketones from fat."),
    Stage(24, "Deep fast", "Ketones climb further. Cells step up routine cleanup (mostly shown in animal studies)."),
    Stage(48, "Extended fast", "A long fast. Stay hydrated and listen to your body."),
)

fun stageIndexFor(elapsedMs: Long): Int {
    var idx = 0
    for (i in fastingStages.indices) {
        if (elapsedMs >= fastingStages[i].hour * HOUR_MS) idx = i
    }
    return idx
}

/** Days in a row (ending today or yesterday) with a fast that reached its goal. */
fun fastStreak(fasts: List<FastRecord>, now: Long): Int {
    val done = fasts.filter { it.completed }.map { dayStart(it.end) }.toSet()
    val today = dayStart(now)
    var d = if (today in done) today else addDays(today, -1)
    var n = 0
    while (d in done) {
        n++
        d = addDays(d, -1)
    }
    return n
}
