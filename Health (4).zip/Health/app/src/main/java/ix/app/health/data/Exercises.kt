package ix.app.health.data

data class Exercise(
    val name: String,
    val category: String,
    val muscles: String,
    val equipment: String,
    val steps: List<String>,
)

object ExerciseBase {

    val categories = listOf("Strength", "Cardio", "Core", "Mobility")

    val all: List<Exercise> = listOf(
        // ---- Strength
        Exercise(
            "Push-ups", "Strength", "Chest, triceps, shoulders", "Bodyweight",
            listOf(
                "Hands slightly wider than shoulders, body in one straight line.",
                "Lower your chest to just above the floor, elbows about 45° from your body.",
                "Press back up without letting your hips sag.",
            ),
        ),
        Exercise(
            "Pull-ups", "Strength", "Back, biceps", "Pull-up bar",
            listOf(
                "Hang from the bar with an overhand grip, slightly wider than shoulders.",
                "Pull your chest towards the bar, leading with your elbows.",
                "Lower slowly until your arms are straight.",
            ),
        ),
        Exercise(
            "Squats", "Strength", "Legs, glutes", "Bodyweight",
            listOf(
                "Feet shoulder-width apart, toes slightly out.",
                "Sit your hips back and down until thighs are about parallel to the floor.",
                "Keep your chest up and knees tracking over your toes, then stand.",
            ),
        ),
        Exercise(
            "Lunges", "Strength", "Legs, glutes", "Bodyweight",
            listOf(
                "Step forward into a long stride.",
                "Lower your back knee towards the floor, front knee over the ankle.",
                "Push through the front heel to return, then switch legs.",
            ),
        ),
        Exercise(
            "Glute bridge", "Strength", "Glutes, hamstrings", "Bodyweight",
            listOf(
                "Lie on your back, knees bent, feet flat on the floor.",
                "Drive through your heels and lift your hips until your body is straight.",
                "Squeeze at the top for a second, then lower with control.",
            ),
        ),
        Exercise(
            "Bench dips", "Strength", "Triceps, chest", "Bench or chair",
            listOf(
                "Hands on the edge of a bench behind you, legs out in front.",
                "Bend your elbows to about 90°, keeping your back close to the bench.",
                "Press back up until your arms are straight.",
            ),
        ),
        Exercise(
            "Kettlebell swing", "Strength", "Hips, back, shoulders", "Kettlebell",
            listOf(
                "Feet wider than shoulders, hinge at the hips with a flat back.",
                "Snap your hips forward to swing the bell to chest height.",
                "Let it fall back between your legs and hinge again. Arms are just hooks.",
            ),
        ),
        Exercise(
            "Dumbbell row", "Strength", "Back, biceps", "Dumbbell, bench",
            listOf(
                "One hand and knee on a bench, other hand holding the dumbbell.",
                "Pull the weight towards your hip, keeping your back flat.",
                "Lower slowly, finish your reps, then switch sides.",
            ),
        ),
        Exercise(
            "Overhead press", "Strength", "Shoulders, triceps", "Dumbbells",
            listOf(
                "Hold dumbbells at shoulder height, core tight.",
                "Press straight up until your arms are fully extended.",
                "Lower back to your shoulders with control.",
            ),
        ),
        // ---- Core
        Exercise(
            "Plank", "Core", "Core, shoulders", "Bodyweight",
            listOf(
                "Forearms on the floor, elbows under your shoulders.",
                "Body in one straight line from head to heels.",
                "Squeeze your abs and glutes and hold. Log the time in minutes.",
            ),
        ),
        Exercise(
            "Side plank", "Core", "Obliques, hips", "Bodyweight",
            listOf(
                "Lie on your side, forearm under your shoulder.",
                "Lift your hips so your body forms a straight line.",
                "Hold, then switch sides.",
            ),
        ),
        Exercise(
            "Crunches", "Core", "Abs", "Bodyweight",
            listOf(
                "Lie on your back, knees bent, hands by your temples.",
                "Curl your shoulders off the floor using your abs.",
                "Lower slowly without pulling on your neck.",
            ),
        ),
        Exercise(
            "Leg raises", "Core", "Lower abs, hip flexors", "Bodyweight",
            listOf(
                "Lie on your back with legs straight, hands under your hips.",
                "Raise your legs to vertical, keeping your lower back on the floor.",
                "Lower them slowly, stopping just above the floor.",
            ),
        ),
        Exercise(
            "Dead bug", "Core", "Deep core", "Bodyweight",
            listOf(
                "Lie on your back, arms up, knees bent at 90° above your hips.",
                "Lower the opposite arm and leg towards the floor.",
                "Return and switch sides, keeping your lower back pressed down.",
            ),
        ),
        // ---- Cardio
        Exercise(
            "Brisk walk", "Cardio", "Legs, heart", "Outdoor",
            listOf(
                "Walk at a pace where you can talk but not sing.",
                "Keep your shoulders relaxed and swing your arms.",
                "Aim for 30 minutes or more.",
            ),
        ),
        Exercise(
            "Running", "Cardio", "Legs, heart", "Outdoor or treadmill",
            listOf(
                "Start with a few minutes of easy walking.",
                "Run at a comfortable, steady pace with short quick steps.",
                "Finish with a slow walk to bring your pulse down.",
            ),
        ),
        Exercise(
            "Jump rope", "Cardio", "Calves, shoulders, heart", "Jump rope",
            listOf(
                "Keep your elbows close and turn the rope with your wrists.",
                "Jump just high enough to clear the rope, landing softly on the balls of your feet.",
                "Work in rounds of 30 to 60 seconds.",
            ),
        ),
        Exercise(
            "Burpees", "Cardio", "Full body", "Bodyweight",
            listOf(
                "From standing, drop your hands to the floor and jump your feet back.",
                "Do a push-up, then jump your feet back in.",
                "Jump up with your arms overhead.",
            ),
        ),
        Exercise(
            "Cycling", "Cardio", "Legs, heart", "Bike",
            listOf(
                "Set the saddle so your knee is slightly bent at the bottom of the stroke.",
                "Keep a steady, smooth cadence.",
                "Log the total time in minutes.",
            ),
        ),
        // ---- Mobility
        Exercise(
            "Cat-cow", "Mobility", "Spine", "Bodyweight",
            listOf(
                "On hands and knees, wrists under shoulders, knees under hips.",
                "Inhale: drop your belly and lift your chest and tailbone.",
                "Exhale: round your back towards the ceiling. Repeat slowly.",
            ),
        ),
        Exercise(
            "Child's pose", "Mobility", "Back, hips", "Bodyweight",
            listOf(
                "Kneel and sit your hips back towards your heels.",
                "Reach your arms forward and rest your forehead on the floor.",
                "Breathe slowly and hold for 30 to 60 seconds.",
            ),
        ),
        Exercise(
            "Hip flexor stretch", "Mobility", "Hips, thighs", "Bodyweight",
            listOf(
                "Kneel on one knee with the other foot in front.",
                "Tuck your pelvis under and shift your weight forward gently.",
                "Hold 30 seconds, then switch sides.",
            ),
        ),
        Exercise(
            "World's greatest stretch", "Mobility", "Hips, spine, hamstrings", "Bodyweight",
            listOf(
                "From a lunge, place both hands inside your front foot.",
                "Rotate your chest up and reach the inside arm to the ceiling.",
                "Return, then switch sides.",
            ),
        ),
        Exercise(
            "Shoulder circles", "Mobility", "Shoulders", "Bodyweight",
            listOf(
                "Stand tall with your arms relaxed.",
                "Roll your shoulders up, back and down in big slow circles.",
                "Do 10 forwards and 10 backwards.",
            ),
        ),
    )
}
