package ix.app.health.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.Repo
import ix.app.health.data.Types
import java.util.Locale
import kotlin.math.roundToInt

enum class HealthTab(val label: String, val icon: Int) {
    Fasting("Fasting", R.drawable.ic_fasting),
    Stats("Stats", R.drawable.ic_stats),
    Exercises("Exercises", R.drawable.ic_dumbbell),
    Settings("Settings", R.drawable.ic_settings),
}

@Composable
fun BottomBar(selected: HealthTab, onSelect: (HealthTab) -> Unit) {
    Column {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        NavigationBar(
            containerColor = MaterialTheme.colorScheme.background,
            tonalElevation = 0.dp,
        ) {
            for (tab in HealthTab.values()) {
                NavigationBarItem(
                    selected = tab == selected,
                    onClick = { onSelect(tab) },
                    icon = { Icon(painterResource(tab.icon), contentDescription = tab.label) },
                    label = { Text(tab.label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Color.Transparent,
                        selectedIconColor = MaterialTheme.colorScheme.onSurface,
                        selectedTextColor = MaterialTheme.colorScheme.onSurface,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    ),
                )
            }
        }
    }
}

@Composable
fun ScreenHeader(
    overline: String,
    title: String,
    modifier: Modifier = Modifier,
    trailing: @Composable () -> Unit = {},
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
    ) {
        Column {
            Text(
                overline.uppercase(),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                title,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
        trailing()
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = fg,
        )
    }
}

@Composable
fun SoftCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
    ) {
        content()
    }
}

@Composable
fun Ring(
    progress: Float,
    modifier: Modifier = Modifier,
    strokeWidth: Dp = 14.dp,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val track = MaterialTheme.colorScheme.outlineVariant
    val fill = MaterialTheme.colorScheme.primary
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val sw = strokeWidth.toPx()
            val inset = sw / 2f
            val arcSize = Size(size.width - sw, size.height - sw)
            drawCircle(
                color = track,
                radius = (size.minDimension - sw) / 2f,
                center = center,
                style = Stroke(width = sw),
            )
            if (progress > 0.01f) {
                drawArc(
                    color = fill,
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arcSize,
                    style = Stroke(width = sw, cap = StrokeCap.Round),
                )
            }
        }
        content()
    }
}

@Composable
fun RoundStepButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 26.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun BlackButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
    ) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun defaultValue(type: String, repo: Repo): Double = when (type) {
    Types.WEIGHT -> repo.latest(Types.WEIGHT)?.value ?: 70.0
    Types.WATER -> 250.0
    Types.SLEEP -> 7.5
    else -> 30.0
}

private fun stepFor(type: String): Double = when (type) {
    Types.WEIGHT -> 0.1
    Types.WATER -> 50.0
    Types.SLEEP -> 5.0 / 60.0
    else -> 5.0
}

private fun roundFor(type: String, v: Double): Double = when (type) {
    Types.WEIGHT -> (v * 10).roundToInt() / 10.0
    Types.SLEEP -> (v * 60).roundToInt() / 60.0
    else -> v.roundToInt().toDouble()
}

/** Reads what you typed. Sleep also accepts 7:45. */
private fun parseTyped(type: String, text: String): Double? {
    val t = text.trim().replace(',', '.')
    if (t.isEmpty()) return null
    if (type == Types.SLEEP && t.contains(':')) {
        val p = t.split(':')
        val h = p[0].toIntOrNull() ?: return null
        val m = p.getOrNull(1)?.toIntOrNull() ?: 0
        return roundFor(type, (h * 60 + m) / 60.0)
    }
    val d = t.toDoubleOrNull() ?: return null
    return roundFor(type, d).coerceAtLeast(0.0)
}

private fun shiftWhen(current: Long, delta: Long): Long {
    val now = System.currentTimeMillis()
    val base = if (current == 0L) now else current
    val next = base + delta
    return if (next >= now - 1000L) 0L else next
}

/** Round button: one tap = one step, hold it to keep going. */
@Composable
fun RepeatStepButton(label: String, onStep: () -> Unit) {
    val step by rememberUpdatedState(onStep)
    Box(
        modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        step()
                        coroutineScope {
                            val job = launch {
                                delay(400L)
                                while (true) {
                                    step()
                                    delay(80L)
                                }
                            }
                            tryAwaitRelease()
                            job.cancel()
                        }
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 26.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

/**
 * The "Log entry" form. Used as a bottom sheet inside the app
 * and as a small pop-up when opened from a home-screen widget.
 */
@Composable
fun LogForm(
    initialType: String,
    initialNote: String,
    repo: Repo,
    source: String,
    onDone: () -> Unit,
) {
    var type by remember { mutableStateOf(initialType) }
    var note by remember { mutableStateOf(initialNote) }
    var value by remember(type) { mutableStateOf(defaultValue(type, repo)) }
    var typing by remember(type) { mutableStateOf(false) }
    var typed by remember(type) { mutableStateOf("") }
    var whenMs by remember { mutableStateOf(0L) }

    val shown = when (type) {
        Types.WEIGHT -> String.format(Locale.US, "%.1f", value)
        Types.SLEEP -> fmtSleep(value)
        else -> fmtNum(value)
    }
    val unitText = when (type) {
        Types.SLEEP -> "hours and minutes"
        else -> Types.unit(type)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Text(
            "Log entry",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (t in Types.all) {
                Pill(Types.label(t), t == type) { type = t }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            RepeatStepButton("−") {
                typing = false
                value = roundFor(type, maxOf(value - stepFor(type), 0.0))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (typing) {
                    val focus = remember { FocusRequester() }
                    OutlinedTextField(
                        value = typed,
                        onValueChange = { text ->
                            typed = text.filter { c -> c.isDigit() || c == '.' || c == ',' || c == ':' }
                        },
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 34.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                        ),
                        placeholder = {
                            Text(
                                if (type == Types.SLEEP) "7:45" else shown,
                                fontSize = 34.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = if (type == Types.SLEEP) KeyboardType.Text else KeyboardType.Decimal,
                            imeAction = ImeAction.Done,
                        ),
                        keyboardActions = KeyboardActions(onDone = {
                            parseTyped(type, typed)?.let { value = it }
                            typing = false
                        }),
                        modifier = Modifier
                            .width(150.dp)
                            .focusRequester(focus),
                    )
                    LaunchedEffect(Unit) { focus.requestFocus() }
                } else {
                    Text(
                        shown,
                        fontSize = if (type == Types.SLEEP) 46.sp else 60.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                typed = ""
                                typing = true
                            }
                            .padding(horizontal = 8.dp),
                    )
                }
                Text(
                    unitText,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    if (typing) "Press Done on the keyboard" else "Tap the number to type it",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            RepeatStepButton("+") {
                typing = false
                value = roundFor(type, value + stepFor(type))
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Pill("Now", whenMs == 0L) { whenMs = 0L }
                Pill("−15 m", false) { whenMs = shiftWhen(whenMs, -15 * 60_000L) }
                Pill("−1 h", false) { whenMs = shiftWhen(whenMs, -60 * 60_000L) }
                Pill("−1 day", false) { whenMs = shiftWhen(whenMs, -24 * 60 * 60_000L) }
            }
            Text(
                if (whenMs == 0L) "Logging now" else "Logging for " + fmtDateTime(whenMs),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            placeholder = { Text("Note (optional)") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        )

        BlackButton("Save") {
            val v = if (typing) (parseTyped(type, typed) ?: value) else value
            repo.addEntry(
                type,
                v,
                note.trim(),
                source,
                if (whenMs == 0L) System.currentTimeMillis() else whenMs,
            )
            onDone()
        }
    }
}
