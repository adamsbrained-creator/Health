package ix.app.health.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import ix.app.health.MainActivity
import ix.app.health.QuickLogActivity
import ix.app.health.R
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.DAY_MS
import ix.app.health.data.Types
import ix.app.health.ui.planLabel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class QuickLogWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Widgets.render(context, manager, javaClass, ids)
    }
}

class WaterWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Widgets.render(context, manager, javaClass, ids)
    }
}

class FastingWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Widgets.render(context, manager, javaClass, ids)
    }
}

/** Handles the buttons on the widgets that save data without opening anything. */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val repo = Repo.get(context)
        when (intent.action) {
            Widgets.ACTION_WATER -> repo.addEntry(Types.WATER, 250.0, source = "widget")
            Widgets.ACTION_TOGGLE_FAST -> repo.toggleFast()
        }
    }
}

object Widgets {
    const val ACTION_WATER = "ix.app.health.ACTION_WATER"
    const val ACTION_TOGGLE_FAST = "ix.app.health.ACTION_TOGGLE_FAST"

    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    /** Refresh every placed widget. Called whenever data changes. */
    fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val classes = listOf<Class<*>>(
            QuickLogWidget::class.java,
            WaterWidget::class.java,
            FastingWidget::class.java,
        )
        for (cls in classes) {
            val ids = manager.getAppWidgetIds(ComponentName(context, cls))
            if (ids.isNotEmpty()) render(context, manager, cls, ids)
        }
        Notifier.update(context)
    }

    /** Asks the launcher to place a widget on the home screen. False if it can't. */
    fun requestPin(context: Context, cls: Class<*>): Boolean {
        val manager = AppWidgetManager.getInstance(context)
        if (!manager.isRequestPinAppWidgetSupported) return false
        return manager.requestPinAppWidget(ComponentName(context, cls), null, null)
    }

    fun render(context: Context, manager: AppWidgetManager, cls: Class<*>, ids: IntArray) {
        val views = when (cls) {
            QuickLogWidget::class.java -> quickViews(context)
            WaterWidget::class.java -> waterViews(context)
            else -> fastingViews(context)
        }
        for (id in ids) {
            try {
                manager.updateAppWidget(id, views)
            } catch (e: Exception) {
                // never let a widget problem crash the app
            }
        }
    }

    // ---- Quick log 2x2 -------------------------------------------------

    private fun quickViews(context: Context): RemoteViews {
        val v = RemoteViews(context.packageName, R.layout.widget_quick)
        v.setOnClickPendingIntent(R.id.btn_weight, logPopup(context, Types.WEIGHT, 1))
        v.setOnClickPendingIntent(R.id.btn_sleep, logPopup(context, Types.SLEEP, 2))
        v.setOnClickPendingIntent(R.id.btn_workout, logPopup(context, Types.WORKOUT, 3))
        v.setOnClickPendingIntent(R.id.btn_water, actionIntent(context, ACTION_WATER, 4))
        v.setOnClickPendingIntent(R.id.quick_title, openApp(context, 5))
        return v
    }

    // ---- Water 2x2 -----------------------------------------------------

    private fun waterViews(context: Context): RemoteViews {
        val repo = Repo.get(context)
        val goal = repo.waterGoal.value
        val today = repo.waterToday()
        val v = RemoteViews(context.packageName, R.layout.widget_water)
        val liters = String.format(Locale.US, "%.1f", today / 1000.0)
        val goalLiters = String.format(Locale.US, "%.1f", goal / 1000.0)
        v.setTextViewText(R.id.water_value, "$liters / $goalLiters L")
        v.setProgressBar(R.id.water_bar, goal, today.coerceAtMost(goal), false)
        v.setOnClickPendingIntent(R.id.water_add, actionIntent(context, ACTION_WATER, 6))
        v.setOnClickPendingIntent(R.id.water_value, openApp(context, 7))
        return v
    }

    // ---- Fasting 4x2 ---------------------------------------------------

    private fun fastingViews(context: Context): RemoteViews {
        val repo = Repo.get(context)
        val start = repo.fastStart.value
        val goal = repo.goalHours.value
        val v = RemoteViews(context.packageName, R.layout.widget_fasting)
        v.setTextViewText(R.id.fast_title, "Fasting · " + planLabel(goal))

        if (start > 0L) {
            val now = System.currentTimeMillis()
            val elapsed = (now - start).coerceAtLeast(0L)
            // The Chronometer ticks by itself, so the widget needs no constant updates.
            v.setViewVisibility(R.id.fast_chrono, View.VISIBLE)
            v.setViewVisibility(R.id.fast_idle, View.GONE)
            v.setChronometer(R.id.fast_chrono, SystemClock.elapsedRealtime() - elapsed, null, true)
            if (goal > 0) {
                val end = SimpleDateFormat("EEE HH:mm", Locale.getDefault()).format(Date(start + goal * HOUR_MS))
                v.setTextViewText(R.id.fast_sub, "Goal at $end")
                val goalMinutes = goal * 60
                val elapsedMinutes = (elapsed / 60_000L).toInt()
                v.setProgressBar(R.id.fast_bar, goalMinutes, elapsedMinutes.coerceAtMost(goalMinutes), false)
            } else {
                v.setTextViewText(R.id.fast_sub, "No goal")
                val dayMinutes = (DAY_MS / 60_000L).toInt()
                v.setProgressBar(R.id.fast_bar, dayMinutes, ((elapsed % DAY_MS) / 60_000L).toInt(), false)
            }
            v.setTextViewText(R.id.fast_btn, "End fast")
        } else {
            v.setViewVisibility(R.id.fast_chrono, View.GONE)
            v.setViewVisibility(R.id.fast_idle, View.VISIBLE)
            v.setTextViewText(R.id.fast_sub, "Eating window")
            v.setProgressBar(R.id.fast_bar, 100, 0, false)
            v.setTextViewText(R.id.fast_btn, "Start fast")
        }
        v.setOnClickPendingIntent(R.id.fast_btn, actionIntent(context, ACTION_TOGGLE_FAST, 8))
        v.setOnClickPendingIntent(R.id.fast_title, openApp(context, 9))
        return v
    }

    // ---- intents -------------------------------------------------------

    private fun logPopup(context: Context, type: String, code: Int): PendingIntent {
        val intent = Intent(context, QuickLogActivity::class.java)
            .putExtra(QuickLogActivity.EXTRA_TYPE, type)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(context, code, intent, FLAGS)
    }

    private fun actionIntent(context: Context, action: String, code: Int): PendingIntent {
        val intent = Intent(context, WidgetActionReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(context, code, intent, FLAGS)
    }

    private fun openApp(context: Context, code: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(context, code, intent, FLAGS)
    }
}
