package ix.app.health

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ix.app.health.data.Repo
import ix.app.health.data.Types
import ix.app.health.ui.HealthTheme
import ix.app.health.ui.LogForm

/**
 * Small pop-up shown on top of the home screen when you tap
 * Weight / Sleep / Workout on the Quick log widget.
 */
class QuickLogActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val type = intent.getStringExtra(EXTRA_TYPE) ?: Types.WEIGHT
        val repo = Repo.get(this)
        setContent {
            HealthTheme {
                Dialog(
                    onDismissRequest = { finish() },
                    properties = DialogProperties(usePlatformDefaultWidth = false),
                ) {
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                    ) {
                        LogForm(
                            initialType = type,
                            initialNote = "",
                            repo = repo,
                            source = "widget",
                            onDone = { finish() },
                        )
                    }
                }
            }
        }
    }

    companion object {
        const val EXTRA_TYPE = "type"
    }
}
