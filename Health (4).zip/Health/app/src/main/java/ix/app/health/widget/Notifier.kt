package ix.app.health.widget

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ix.app.health.MainActivity
import ix.app.health.R
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.ui.planLabel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The ongoing "Fasting" notification with a live timer, plus the alert when the goal is reached. */
object Notifier {
    private const val CHANNEL_RUNNING = "fasting_running"
    private const val CHANNEL_GOAL = "fasting_goal"
    private const val ID_RUNNING = 1
    private const val ID_GOAL = 2
    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    fun update(context: Context) {
        try {
            val app = context.applicationContext
            val nm = app.getSystemService(NotificationManager::class.java) ?: return
            val am = app.getSystemService(AlarmManager::class.java)
            val repo = Repo.get(app)
            val start = repo.fastStart.value
            val goal = repo.goalHours.value
            val alarm = PendingIntent.getBroadcast(app, 20, Intent(app, GoalReceiver::class.java), FLAGS)

            if (start <= 0L) {
                nm.cancel(ID_RUNNING)
                am?.cancel(alarm)
                return
            }

            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_RUNNING, "Fasting timer", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                app, 21,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                FLAGS,
            )
            val text = if (goal > 0) {
                "Goal at " + SimpleDateFormat("EEE HH:mm", Locale.getDefault()).format(Date(start + goal * HOUR_MS))
            } else {
                "No goal"
            }
            val n = Notification.Builder(app, CHANNEL_RUNNING)
                .setSmallIcon(R.drawable.ic_fasting)
                .setContentTitle("Fasting · " + planLabel(goal))
                .setContentText(text)
                .setUsesChronometer(true)
                .setShowWhen(true)
                .setWhen(start)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .build()
            nm.notify(ID_RUNNING, n)

            val at = start + goal * HOUR_MS
            if (goal > 0 && at > System.currentTimeMillis()) {
                am?.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarm)
            } else {
                am?.cancel(alarm)
            }
        } catch (e: Exception) {
            // notifications are a bonus, never crash because of them
        }
    }

    fun postGoalReached(context: Context) {
        try {
            val app = context.applicationContext
            val repo = Repo.get(app)
            if (repo.fastStart.value <= 0L) return
            val nm = app.getSystemService(NotificationManager::class.java) ?: return
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_GOAL, "Goal reached", NotificationManager.IMPORTANCE_DEFAULT)
            )
            val open = PendingIntent.getActivity(
                app, 22,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                FLAGS,
            )
            val n = Notification.Builder(app, CHANNEL_GOAL)
                .setSmallIcon(R.drawable.ic_fasting)
                .setContentTitle("Goal reached")
                .setContentText("You've finished your " + planLabel(repo.goalHours.value) + " fast. Nice work!")
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(ID_GOAL, n)
        } catch (e: Exception) {
        }
    }
}

class GoalReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.postGoalReached(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Widgets.updateAll(context)
    }
}
