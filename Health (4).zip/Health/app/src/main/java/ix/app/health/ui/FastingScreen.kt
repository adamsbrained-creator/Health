package ix.app.health.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.data.DAY_MS
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.addDays
import ix.app.health.data.dayStart
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun FastingScreen(repo: Repo) {
    var showHistory by remember { mutableStateOf(false) }
    if (showHistory) {
        BackHandler { showHistory = false }
        HistoryScreen(repo) { showHistory = false }
    } else {
        FastingMain(repo) { showHistory = true }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FastingMain(repo: Repo, onHistory: () -> Unit) {
    val start by repo.fastStart.collectAsState()
    val goal by repo.goalHours.collectAsState()
    val fasts by repo.fasts.collectAsState()
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(1000L)
            value = System.currentTimeMillis()
        }
    }
    var editing by remember { mutableStateOf(false) }
    var plans by remember { mutableStateOf(false) }
    var confirmEnd by remember { mutableStateOf(false) }

    val fasting = start > 0L
    val flexi = goal <= 0
    val goalMs = goal * HOUR_MS
    val elapsed = if (fasting) (now - start).coerceAtLeast(0L) else 0L
    val progress = when {
        !fasting -> 0f
        flexi -> ((elapsed % DAY_MS).toFloat() / DAY_MS.toFloat()).coerceIn(0f, 1f)
        else -> (elapsed.toFloat() / goalMs.toFloat()).coerceIn(0f, 1f)
    }
    val left = goalMs - elapsed
    val stage = stageIndexFor(elapsed)

    val timeFmt = SimpleDateFormat("EEE HH:mm", Locale.getDefault())
    val clockFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 16.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val dateText = SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(Date(now))
        ScreenHeader(dateText, "Fasting") {
            Row(
                modifier = Modifier.padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable(onClick = onHistory)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                ) {
                    Text(
                        "History",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.primary)
                        .clickable { plans = true }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                ) {
                    Text(
                        planLabel(goal),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }
        }

        Spacer(Modifier.height(28.dp))

        // ---- eating window after the last fast ----
        val lastEnd = fasts.maxOfOrNull { it.end } ?: 0L
        val windowEnd = if (lastEnd > 0L && goal in 1..23) lastEnd + (24 - goal) * HOUR_MS else 0L
        val inWindow = !fasting && windowEnd > now

        Ring(progress = progress, modifier = Modifier.size(248.dp), strokeWidth = 14.dp) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (fasting) {
                    Text(
                        fastingStages[stage].name,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        fmtHms(elapsed),
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        when {
                            flexi -> "No goal"
                            left > 0 -> "${fmtHm(left + 59_999L)} left"
                            else -> "Goal reached · +${fmtHm(-left)}"
                        },
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else if (inWindow) {
                    Text("Eating window", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        fmtHm(windowEnd - now + 59_999L),
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        "Next fast from ${clockFmt.format(Date(windowEnd))}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Text(
                        if (lastEnd > 0L) "Last fast ended" else "Eating window",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        if (lastEnd > 0L) fmtHm(now - lastEnd) else "Ready",
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        if (lastEnd > 0L) "ago · start when you are" else "Start when you are",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SoftCard(
                modifier = Modifier
                    .weight(1f)
                    .clickable(enabled = fasting) { editing = true },
            ) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                    Text(
                        if (fasting) "Started · tap to edit" else "Started",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        if (fasting) timeFmt.format(Date(start)) else "—",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
            SoftCard(modifier = Modifier.weight(1f)) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                    Text(
                        if (fasting && !flexi) "Goal at" else "Goal",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        when {
                            flexi -> "No goal"
                            fasting -> timeFmt.format(Date(start + goalMs))
                            else -> "$goal h"
                        },
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        BlackButton(if (fasting) "End fast" else "Start fast") {
            if (!fasting) {
                repo.startFast()
            } else if (!flexi && left > 0) {
                confirmEnd = true
            } else {
                repo.endFast()
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---- stages ----
        SoftCard(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    "Fasting stages",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                if (fasting) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        fastingStages[stage].text,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(12.dp))
                for (i in fastingStages.indices) {
                    val st = fastingStages[i]
                    val reached = fasting && i <= stage
                    val current = fasting && i == stage
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        val dotMod = Modifier.size(12.dp).clip(CircleShape)
                        if (reached) {
                            Box(dotMod.background(MaterialTheme.colorScheme.primary))
                        } else {
                            Box(dotMod.background(MaterialTheme.colorScheme.outlineVariant))
                        }
                        Spacer(Modifier.size(12.dp))
                        Text(
                            st.name,
                            fontSize = 14.sp,
                            fontWeight = if (current) FontWeight.Bold else FontWeight.Medium,
                            color = if (reached) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            "${st.hour}h",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "A general timeline. It varies from person to person and is not medical advice.",
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---- this week ----
        val today = dayStart(now)
        val cal = Calendar.getInstance()
        cal.firstDayOfWeek = Calendar.MONDAY
        cal.timeInMillis = now
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val weekStart = dayStart(cal.timeInMillis)
        val days = (0..6).map { addDays(weekStart, it) }
        val done = fasts.filter { it.completed }.map { dayStart(it.end) }.toSet()
        val streak = fastStreak(fasts, now)
        val letters = listOf("M", "T", "W", "T", "F", "S", "S")

        SoftCard(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        "This week",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        if (streak == 1) "1 day streak" else "$streak day streak",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    for (i in 0..6) {
                        val day = days[i]
                        val isDone = day in done
                        val isToday = day == today
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            val dot = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                            when {
                                isDone -> Box(dot.background(MaterialTheme.colorScheme.primary))
                                isToday -> Box(
                                    dot.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                )
                                else -> Box(dot.background(MaterialTheme.colorScheme.outlineVariant))
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                letters[i],
                                fontSize = 12.sp,
                                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                                color = if (isToday) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }

    // ---- confirm ending early ----
    if (confirmEnd) {
        AlertDialog(
            onDismissRequest = { confirmEnd = false },
            title = { Text("End this fast?") },
            text = {
                Text(
                    "You're at ${fmtHm(elapsed)} of $goal:00. " +
                        "Ending now saves it as ended early. You can edit it later in History."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmEnd = false
                    repo.endFast()
                }) { Text("End fast") }
            },
            dismissButton = {
                TextButton(onClick = { confirmEnd = false }) { Text("Keep fasting") }
            },
        )
    }

    // ---- edit start time ----
    if (editing && fasting) {
        AlertDialog(
            onDismissRequest = { editing = false },
            confirmButton = { TextButton(onClick = { editing = false }) { Text("Done") } },
            title = { Text("Fast started") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(fmtFull(start), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("−12 h", false) { repo.startFast(start - 12 * HOUR_MS) }
                        Pill("−3 h", false) { repo.startFast(start - 3 * HOUR_MS) }
                        Pill("−1 h", false) { repo.startFast(start - HOUR_MS) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("−15 m", false) { repo.startFast(start - 15 * 60_000L) }
                        Pill("+15 m", false) { repo.startFast(start + 15 * 60_000L) }
                        Pill("+1 h", false) { repo.startFast(start + HOUR_MS) }
                    }
                }
            },
        )
    }

    // ---- plan picker ----
    if (plans) {
        ModalBottomSheet(
            onDismissRequest = { plans = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
            ) {
                Text(
                    "Choose a plan",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.height(14.dp))
                PlanTile(0, goal == 0, Modifier.fillMaxWidth()) {
                    repo.setGoalHours(0)
                    plans = false
                }
                for ((group, list) in planGroups) {
                    Spacer(Modifier.height(18.dp))
                    Text(
                        group,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    for (pair in list.chunked(2)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            for (g in pair) {
                                PlanTile(g, g == goal, Modifier.weight(1f)) {
                                    repo.setGoalHours(g)
                                    plans = false
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun PlanTile(goal: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val borderColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    Box(
        modifier = modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(2.dp, borderColor, shape)
            .clickable(onClick = onClick),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text(
                planLabel(goal),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                planDetail(goal),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
