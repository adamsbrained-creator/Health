package ix.app.health.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.data.FastRecord
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.addDays
import ix.app.health.data.dayStart
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(repo: Repo, onBack: () -> Unit) {
    val fasts by repo.fasts.collectAsState()
    val liveStart by repo.fastStart.collectAsState()
    val goal by repo.goalHours.collectAsState()
    val now = System.currentTimeMillis()

    var range by remember { mutableStateOf(7) }
    var editor by remember { mutableStateOf<FastRecord?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleted by remember { mutableStateOf<FastRecord?>(null) }

    LaunchedEffect(deleted) {
        if (deleted != null) {
            delay(5000L)
            deleted = null
        }
    }

    val sorted = fasts.sortedByDescending { it.start }
    val completed = fasts.count { it.completed }
    val early = fasts.size - completed
    val longest = fasts.maxOfOrNull { it.duration } ?: 0L
    val total = fasts.sumOf { it.duration }
    val avg = if (fasts.isEmpty()) 0L else total / fasts.size
    val streak = fastStreak(fasts, now)
    val chartFasts = if (liveStart > 0L) fasts + FastRecord(liveStart, now, goal) else fasts

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 24.dp, end = 24.dp, top = 16.dp, bottom = 96.dp,
            ),
        ) {
            item {
                Column {
                    Text(
                        "‹ Back",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable(onClick = onBack)
                            .padding(vertical = 6.dp, horizontal = 4.dp),
                    )
                    Spacer(Modifier.height(8.dp))
                    ScreenHeader(if (fasts.size == 1) "1 fast" else "${fasts.size} fasts", "History") {
                        Box(Modifier.padding(top = 6.dp)) { Pill("Add fast", true) { adding = true } }
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }
            item {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatTile("Goal reached", completed.toString(), Modifier.weight(1f))
                        StatTile("Ended early", early.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatTile("Longest", if (fasts.isEmpty()) "—" else fmtDur(longest), Modifier.weight(1f))
                        StatTile("Average", if (fasts.isEmpty()) "—" else fmtDur(avg), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatTile("Total fasted", "${total / HOUR_MS} h", Modifier.weight(1f))
                        StatTile("Streak", if (streak == 1) "1 day" else "$streak days", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "Hours fasted per day",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Pill("7 d", range == 7) { range = 7 }
                            Pill("30 d", range == 30) { range = 30 }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    HoursChart(chartFasts, range, now)
                    Spacer(Modifier.height(24.dp))
                    Text(
                        "All fasts",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    if (sorted.isEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Nothing here yet. Fasts you finish show up in this list, and you can add or fix one by hand.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            items(sorted) { f ->
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { editor = f }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                fmtDur(f.duration),
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Text(
                                fmtFull(f.start) + " → " + fmtFull(f.end),
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        val label = when {
                            f.goal <= 0 -> "Flexi"
                            f.completed -> "Goal reached"
                            else -> "Ended early"
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (f.completed) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                        ) {
                            Text(
                                label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (f.completed) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }

        val gone = deleted
        if (gone != null) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.onSurface)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Fast deleted", color = MaterialTheme.colorScheme.surface, fontSize = 14.sp)
                Text(
                    "Undo",
                    color = MaterialTheme.colorScheme.surface,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable {
                            repo.addFast(gone)
                            deleted = null
                        }
                        .padding(4.dp),
                )
            }
        }
    }

    val ed = editor
    if (ed != null) {
        FastEditor(
            title = "Edit fast",
            initial = ed,
            onSave = {
                repo.replaceFast(ed, it)
                editor = null
            },
            onDelete = {
                repo.deleteFast(ed)
                deleted = ed
                editor = null
            },
            onDismiss = { editor = null },
        )
    }
    if (adding) {
        val hours = if (goal > 0) goal else 16
        FastEditor(
            title = "Add fast",
            initial = FastRecord(now - hours * HOUR_MS, now, goal),
            onSave = {
                repo.addFast(it)
                adding = false
            },
            onDelete = null,
            onDismiss = { adding = false },
        )
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    SoftCard(modifier = modifier) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                value,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
private fun HoursChart(fasts: List<FastRecord>, days: Int, now: Long) {
    val today = dayStart(now)
    val starts = (0 until days).map { addDays(today, -(days - 1 - it)) }
    val hours = starts.map { d ->
        val e = addDays(d, 1)
        var ms = 0L
        for (f in fasts) {
            val a = maxOf(f.start, d)
            val b = minOf(f.end, e)
            if (b > a) ms += b - a
        }
        ms.toFloat() / HOUR_MS.toFloat()
    }
    val bar = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.outlineVariant
    val labelFmt = if (days == 7) SimpleDateFormat("EEE", Locale.getDefault()) else SimpleDateFormat("d", Locale.getDefault())

    Column {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
        ) {
            val gap = if (days > 10) 3.dp.toPx() else 8.dp.toPx()
            val w = (size.width - gap * (days - 1)) / days
            for (i in 0 until days) {
                val x = i * (w + gap)
                drawRoundRect(track, Offset(x, 0f), Size(w, size.height), CornerRadius(w / 2f))
                val h = (hours[i] / 24f).coerceIn(0f, 1f) * size.height
                if (h > 0f) {
                    drawRoundRect(bar, Offset(x, size.height - h), Size(w, h), CornerRadius(w / 2f))
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            for (i in 0 until days) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    if (days == 7 || i % 5 == 0) {
                        Text(
                            labelFmt.format(Date(starts[i])),
                            fontSize = 10.sp,
                            maxLines = 1,
                            softWrap = false,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FastEditor(
    title: String,
    initial: FastRecord,
    onSave: (FastRecord) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    var start by remember { mutableStateOf(initial.start) }
    var end by remember { mutableStateOf(initial.end) }
    val now = System.currentTimeMillis()
    val valid = end > start && end <= now + 60_000L

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = { onSave(initial.copy(start = start, end = end)) },
            ) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Delete") }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                TimeBlock("Start", start) { start += it }
                TimeBlock("End", end) { end += it }
                Text(
                    if (valid) "Length ${fmtDur(end - start)}"
                    else "The end must be after the start and not in the future.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
    )
}

@Composable
private fun TimeBlock(label: String, time: Long, onShift: (Long) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(fmtFull(time), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Pill("−1 d", false) { onShift(-24 * HOUR_MS) }
            Pill("−1 h", false) { onShift(-HOUR_MS) }
            Pill("−15 m", false) { onShift(-15 * 60_000L) }
            Pill("+15 m", false) { onShift(15 * 60_000L) }
            Pill("+1 h", false) { onShift(HOUR_MS) }
            Pill("+1 d", false) { onShift(24 * HOUR_MS) }
        }
    }
}
