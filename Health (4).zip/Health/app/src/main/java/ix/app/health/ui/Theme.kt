package ix.app.health.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import ix.app.health.data.Repo
import androidx.compose.ui.graphics.Color

val HealthRed = Color(0xFFFF2D3F)

/** Accent colours you can pick in Settings. Index 0 (red, the icon's heart) is the default. */
data class Accent(val name: String, val color: Color?)

val Accents = listOf(
    Accent("Red", HealthRed),
    Accent("Orange", Color(0xFFFF9500)),
    Accent("Green", Color(0xFF30B350)),
    Accent("Blue", Color(0xFF0A84FF)),
    Accent("Purple", Color(0xFFAF52DE)),
    Accent("Pink", Color(0xFFFF4F9A)),
    Accent("Mono", null),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF000000),
    onPrimary = Color(0xFFFFFFFF),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF000000),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF000000),
    surfaceVariant = Color(0xFFF2F2F7),
    onSurfaceVariant = Color(0xFF6C6C70),
    outline = Color(0xFFC7C7CC),
    outlineVariant = Color(0xFFE5E5EA),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFFFFF),
    onPrimary = Color(0xFF000000),
    background = Color(0xFF000000),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF1C1C1E),
    onSurfaceVariant = Color(0xFF98989D),
    outline = Color(0xFF48484A),
    outlineVariant = Color(0xFF2C2C2E),
)

@Composable
fun HealthTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val repo = Repo.get(LocalContext.current)
    val index by repo.accent.collectAsState()
    val base = if (dark) DarkColors else LightColors
    val accent = Accents.getOrNull(index)?.color
    val scheme = if (accent == null) base else base.copy(primary = accent, onPrimary = Color.White)
    MaterialTheme(colorScheme = scheme, content = content)
}
