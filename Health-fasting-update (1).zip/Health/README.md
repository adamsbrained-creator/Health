# Health

Personal Android app (Kotlin, Jetpack Compose). Package: `ix.app.health`.

- **Fasting**: any plan (11:13 to 72h, or Flexi), ring timer with fasting stages, notification with live timer and goal alert, editable start, weekly streak, History (stats, chart, add/edit/delete fasts)
- **Stats**: weight chart, water / sleep / workouts / fasts, recent entries (widget entries are tagged)
- **Exercises**: built-in exercise base with search, categories and how-to steps
- **Widgets**: Quick log, Water, Fasting (long-press home screen > Widgets > Health)
- **Settings**: accent colour, daily water goal, add-widget buttons

## Build on GitHub

1. Put these files in a repo (the `.github/workflows/build.yml` file must be in the repo),
   or upload `Health.zip` to the repo root next to `.github/workflows/build.yml`.
2. Push to `main` (or run the workflow by hand from the Actions tab).
3. Download `Health.apk` from the Releases page and install it.

## About the signing key

`keystore/health.jks` is a **temporary** key, committed on purpose, with the password `healthtemp`
(alias `health`). It only exists so that every new build is signed the same way and installs over
the previous one. If this app is ever published, generate a new private key, keep it out of the
repo, store it as GitHub secrets, and delete this one. Note that apps signed with a different key
cannot be updated in place, so the old install would have to be removed first.


## Fasting update

The Fasting tab follows the new mock-ups:

- **Timer / Journal / Insights** tabs. Journal and Insights reuse the old History screen (fast list and logs, stats and chart).
- **Eating window** view with a last-meal reminder, planned start, last fast, streak with a weekly grace day, and a three-step checklist.
- **Fasting ring** with stage markers, next-up card, quick log tiles, "Right now" with what you may feel and what helps, a "During this fast" tracker for water and electrolytes, and a reason card. A **Focus** layout is available in Settings.
- **Stages** screen, **Plans** screen (custom plans per weekday, programs, plan groups, safety check for long fasts) and **Program** screen.
- **Log sheet**: water, electrolytes, coffee and tea, ketones, glucose, weight, waist, sleep, meal and note.

### Second batch (mock-ups 8 to 13)

- **Check-in** sheet: hunger, energy, mood, symptoms, and an "end fast gently" suggestion when you feel dizzy.
- **Fast complete** summary after a fast ends: totals, averages, how it felt, a note, streak and a break-the-fast guide.
- **Journal**: week strip with daily bars, a month calendar, and a day view with fasts, check-ins, meals, water and electrolytes, body and blood, workouts and notes.
- **Insights**: week, month and year ranges, hours chart, hunger and energy by hour, next-day energy by fast length, a 12-week heat map and "what we noticed".
- **Reminders** (Settings): nudges, stage alerts, check-in prompts, hydration, quiet hours, meal reminders, safety options and widgets.
- **Notifications**: a live timer notification with buttons, plus stage, check-in, hydration and eating-window alerts.
- **Widgets**: new Timer ring, and Fasting, Water and Quick log restyled to the mock-ups.
