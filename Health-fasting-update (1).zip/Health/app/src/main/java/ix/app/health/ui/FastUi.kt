package ix.app.health.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Sub(text: String, modifier: Modifier = Modifier, size: Int = 12) {
    Text(
        text,
        fontSize = size.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier,
    )
}

@Composable
fun CardTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = modifier,
    )
}

@Composable
fun FIcon(
    res: Int,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    tint: Color = MaterialTheme.colorScheme.onSurface,
) {
    Icon(
        painterResource(res),
        contentDescription = null,
        tint = tint,
        modifier = modifier.size(size),
    )
}

@Composable
fun IconCircle(
    res: Int,
    modifier: Modifier = Modifier,
    box: Dp = 44.dp,
    size: Dp = 22.dp,
    tint: Color = MaterialTheme.colorScheme.onSurface,
) {
    Box(
        modifier = modifier
            .size(box)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.outlineVariant),
        contentAlignment = Alignment.Center,
    ) {
        FIcon(res, size = size, tint = tint)
    }
}

/** Soft filled chip, for "You may feel". */
@Composable
fun FilledChip(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.outlineVariant)
            .padding(horizontal = 12.dp, vertical = 7.dp),
    ) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
    }
}

/** Outlined chip, for "What helps". */
@Composable
fun OutlineChip(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChipRow(items: List<String>, outlined: Boolean) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (t in items) if (outlined) OutlineChip(t) else FilledChip(t)
    }
}

/** Stage description with "You may feel" and "What helps". */
@Composable
fun StageDetails(stage: Stage) {
    Sub("You may feel")
    Spacer(Modifier.height(6.dp))
    ChipRow(stage.feel, outlined = false)
    Spacer(Modifier.height(12.dp))
    Sub("What helps")
    Spacer(Modifier.height(6.dp))
    ChipRow(stage.helps, outlined = true)
}

@Composable
fun Bar(frac: Float, color: Color, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    val r = RoundedCornerShape(height / 2)
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(r)
            .background(MaterialTheme.colorScheme.outlineVariant),
    ) {
        Box(
            Modifier
                .fillMaxWidth(frac.coerceIn(0f, 1f))
                .height(height)
                .clip(r)
                .background(color),
        )
    }
}

@Composable
fun LabeledBar(label: String, value: String, frac: Float, color: Color) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Sub(value, size = 13)
        }
        Spacer(Modifier.height(6.dp))
        Bar(frac, color, height = 8.dp)
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(4.dp),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (on) segmentSelected() else Color.Transparent)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    fontSize = 14.sp,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                    color = if (on) MaterialTheme.colorScheme.onSurface
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** The accent pill with the plan name and a small arrow. */
@Composable
fun PlanPill(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.primary)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
        FIcon(R.drawable.ic_chev_down, size = 14.dp, tint = MaterialTheme.colorScheme.onPrimary)
    }
}

/** Small back arrow row used by pushed screens. */
@Composable
fun BackRow(onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(onClick = onBack),
        contentAlignment = Alignment.Center,
    ) {
        FIcon(R.drawable.ic_back, size = 24.dp)
    }
}

/** The row of days (Monday first) with a filled dot for each day a fast reached its goal. */
@Composable
fun WeekCard(done: Set<Long>, days: List<Long>, today: Long, trailing: String, title: String = "This week") {
    val letters = listOf("M", "T", "W", "T", "F", "S", "S")
    SoftCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CardTitle(title)
                Sub(trailing, size = 13)
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for (i in 0..6) {
                    val day = days[i]
                    val isToday = day == today
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val dot = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                        when {
                            day in done -> Box(dot.background(MaterialTheme.colorScheme.primary))
                            isToday -> Box(dot.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape))
                            else -> Box(dot.background(MaterialTheme.colorScheme.outlineVariant))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            letters[i],
                            fontSize = 12.sp,
                            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                            color = if (isToday) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

data class RingNode(val frac: Float, val state: Int) // 0 reached, 1 current, 2 upcoming

/** Progress ring with optional stage markers sitting on it. */
@Composable
fun FastRing(
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier,
    nodes: List<RingNode> = emptyList(),
    content: @Composable BoxScope.() -> Unit,
) {
    val track = MaterialTheme.colorScheme.outlineVariant
    val bg = MaterialTheme.colorScheme.background
    val upFill = MaterialTheme.colorScheme.surfaceVariant
    val ringEdge = MaterialTheme.colorScheme.onSurface
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val s = size.minDimension / 260f
            val sw = 14f * s
            val r = 110f * s
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(track, r, c, style = Stroke(width = sw))
            if (progress > 0.005f) {
                drawArc(
                    color,
                    -90f,
                    360f * progress.coerceAtMost(1f),
                    false,
                    topLeft = Offset(c.x - r, c.y - r),
                    size = Size(2f * r, 2f * r),
                    style = Stroke(width = sw, cap = StrokeCap.Round),
                )
            }
            val twoPi = (2.0 * PI).toFloat()
            val quarter = (PI / 2.0).toFloat()
            for (n in nodes) {
                val a = n.frac * twoPi - quarter
                val p = Offset(c.x + r * cos(a), c.y + r * sin(a))
                when (n.state) {
                    0 -> {
                        drawCircle(bg, 10.5f * s, p)
                        drawCircle(color, 7.5f * s, p)
                    }
                    1 -> {
                        drawCircle(ringEdge, 14.5f * s, p)
                        drawCircle(color, 11.5f * s, p)
                    }
                    else -> {
                        drawCircle(NodeStroke, 11.25f * s, p)
                        drawCircle(upFill, 8.75f * s, p)
                    }
                }
            }
        }
        content()
    }
}
