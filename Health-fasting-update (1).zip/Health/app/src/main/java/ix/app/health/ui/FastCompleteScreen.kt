package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.DAY_MS
import ix.app.health.data.FastRecord
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Repo
import ix.app.health.data.Types
import ix.app.health.data.addDays
import ix.app.health.data.dayStart
import ix.app.health.data.weekStart
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FastCompleteScreen(repo: Repo, fast: FastRecord, onDone: () -> Unit, onLogMeal: () -> Unit) {
    val entries by repo.entries.collectAsState()
    val fasts by repo.fasts.collectAsState()
    val targets by repo.targets.collectAsState()
    val waterGoal by repo.waterGoal.collectAsState()
    val rem by repo.reminders.collectAsState()
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface

    var feel by remember { mutableStateOf(fast.feel) }
    var note by remember { mutableStateOf(fast.note) }

    fun finish(then: () -> Unit) {
        if (feel != fast.feel || note.trim() != fast.note) repo.rateFast(fast, feel, note)
        repo.dismissJustEnded()
        then()
    }

    val dur = fast.duration
    val goal = fast.goal
    val goalMs = goal * HOUR_MS
    val reachedIdx = stageIndexFor(dur)
    val stage = fastingStages[reachedIdx]
    val reached = fast.completed
    val progress = if (goal <= 0) 1f else (dur.toFloat() / goalMs.toFloat()).coerceIn(0f, 1f)
    val nodes = if (goal <= 0) emptyList() else fastingStages
        .filter { it.hour * HOUR_MS < goalMs }
        .map { RingNode(it.hour.toFloat() / goal, if (it.hour * HOUR_MS <= dur) 0 else 2) }

    // numbers for the fast
    val inFast = entries.filter { it.time >= fast.start && it.time <= fast.end }
    val days = ((dur + DAY_MS - 1) / DAY_MS).toInt().coerceAtLeast(1)
    val water = inFast.filter { it.type == Types.WATER }.sumOf { it.value }
    val waterGoalMl = waterGoal.toDouble() * days
    val salts = inFast.filter { it.type == Types.SODIUM || it.type == Types.POTASSIUM || it.type == Types.MAGNESIUM }
        .map { it.time }.distinct().size
    val sodium = inFast.filter { it.type == Types.SODIUM }.sumOf { it.value }
    val hungers = inFast.filter { it.type == Types.HUNGER }
    val energies = inFast.filter { it.type == Types.ENERGY }
    val hungerAvg = if (hungers.isEmpty()) 0.0 else hungers.sumOf { it.value } / hungers.size
    val energyAvg = if (energies.isEmpty()) 0.0 else energies.sumOf { it.value } / energies.size
    val hungerPeak = hungers.maxByOrNull { it.value }
    val energyBest = energies.maxByOrNull { it.value }

    val fmtDate = SimpleDateFormat("EEEE, d MMM", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 16.dp, bottom = 24.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Column {
                Sub(fmtDate.format(Date(fast.end)) + " · " + planLabel(goal))
                Text("Fast complete", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = onSurface)
            }
            Box(
                Modifier
                    .padding(top = 6.dp)
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { finish(onDone) },
                contentAlignment = Alignment.Center,
            ) { FIcon(R.drawable.ic_close, size = 18.dp) }
        }

        Spacer(Modifier.height(16.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            FastRing(progress = progress, color = primary, modifier = Modifier.size(216.dp), nodes = nodes) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (reached) FIcon(R.drawable.ic_check, size = 20.dp, tint = primary)
                    Text(fmtDur(dur), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = onSurface)
                    Sub(if (goal <= 0) "Fast complete" else if (reached) "Goal reached" else "Ended early", size = 13)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            fmtDayClock(fast.start) + " – " + fmtDayClock(fast.end) +
                (if (reachedIdx > 0) " · you reached ${stage.name} at ${stage.hour}h" else ""),
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )

        // ---- numbers ----
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CompleteTile(
                "Water", TrackBlue, "${fmtL(water)} L",
                if (waterGoalMl > 0) "${(water / waterGoalMl * 100).toInt()}% of ${fmtL(waterGoalMl)} L" else "",
                Modifier.weight(1f),
            )
            CompleteTile(
                "Electrolytes", TrackAmber, "$salts logged",
                "Sodium ${String.format(Locale.US, "%.1f", sodium)} of ${String.format(Locale.US, "%.1f", targets.sodium * days)} g",
                Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CompleteTile(
                "Average hunger", null,
                if (hungers.isEmpty()) "—" else String.format(Locale.US, "%.1f / 5", hungerAvg),
                if (hungerPeak == null) "No check-ins" else "Peaked at ${fmtNum(hungerPeak.value)} around ${(hungerPeak.time - fast.start) / HOUR_MS}h",
                Modifier.weight(1f),
            )
            CompleteTile(
                "Average energy", null,
                if (energies.isEmpty()) "—" else String.format(Locale.US, "%.1f / 5", energyAvg),
                if (energyBest == null) "No check-ins" else "Best around ${(energyBest.time - fast.start) / HOUR_MS}h",
                Modifier.weight(1f),
            )
        }

        // ---- how did it feel ----
        Spacer(Modifier.height(20.dp))
        CardTitle("How did this fast feel?")
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Easy", "Okay", "Hard").forEachIndexed { i, w ->
                val on = feel == i + 1
                Box(
                    Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (on) primary else MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { feel = if (on) 0 else i + 1 },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        w, fontSize = 15.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                        color = if (on) MaterialTheme.colorScheme.onPrimary else onSurface,
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            placeholder = { Text("Add a note about this fast") },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        )

        // ---- streak ----
        Spacer(Modifier.height(16.dp))
        val monday = weekStart(fast.end)
        val weekDays = (0..6).map { addDays(monday, it) }
        val done = fasts.filter { it.completed }.map { dayStart(it.end) }.toSet()
        val streak = streakInfo(fasts, fast.end)
        WeekCard(
            done = done,
            days = weekDays,
            today = dayStart(fast.end),
            trailing = "Best: ${bestStreak(fasts)} days",
            title = if (streak.days == 1) "1 day streak" else "${streak.days} day streak",
        )

        // ---- break the fast ----
        if (rem.breakGuide) {
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        CardTitle("Break your fast gently")
                        Sub(if (goal in 1..23) "Eating window open · ${24 - goal}h" else "Go slowly", size = 13)
                    }
                    listOf(
                        "A glass of water, a pinch of salt",
                        "Protein and vegetables before carbs",
                        "Eat slowly and stop at about 80% full",
                    ).forEachIndexed { i, t ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                Modifier.size(26.dp).clip(CircleShape).background(MaterialTheme.colorScheme.outlineVariant),
                                contentAlignment = Alignment.Center,
                            ) { Text("${i + 1}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = onSurface) }
                            Text(t, fontSize = 14.sp, color = onSurface)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier
                    .weight(1f)
                    .height(54.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { finish(onLogMeal) },
                contentAlignment = Alignment.Center,
            ) { Text("Log first meal", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = onSurface) }
            BlackButton("Done", Modifier.weight(1f)) { finish(onDone) }
        }
    }
}

@Composable
private fun CompleteTile(label: String, dot: androidx.compose.ui.graphics.Color?, value: String, sub: String, modifier: Modifier) {
    SoftCard(modifier) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (dot != null) Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Sub(label)
            }
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Sub(sub, size = 11)
        }
    }
}
