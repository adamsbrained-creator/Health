package ix.app.health.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.health.R
import ix.app.health.data.CustomPlan
import ix.app.health.data.HOUR_MS
import ix.app.health.data.Program
import ix.app.health.data.Repo
import ix.app.health.data.planGoalFor
import ix.app.health.data.programById
import ix.app.health.data.programDay
import ix.app.health.data.programs
import java.util.Calendar

private fun minOfDay(t: Long): Int {
    val c = Calendar.getInstance()
    c.timeInMillis = t
    return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
}

private val dayLetters = listOf("M", "T", "W", "T", "F", "S", "S")
private val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

private fun daysText(mask: Int): String = when (mask) {
    127 -> "Every day"
    31 -> "Mon – Fri"
    96 -> "Sat – Sun"
    else -> dayNames.filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(", ")
}

private fun eatText(p: CustomPlan): String =
    if (p.fastHours >= 24) "fast ${p.fastHours}h"
    else "eat ${fmtMinOfDay(p.eatStartMin)} – ${fmtMinOfDay(p.eatStartMin + (24 - p.fastHours) * 60)}"

private fun programIcon(id: String): Int = when (id) {
    "easy" -> R.drawable.ic_leaf
    "step" -> R.drawable.ic_steps
    else -> R.drawable.ic_clock
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlansScreen(repo: Repo, onBack: () -> Unit, onProgram: () -> Unit) {
    val start by repo.fastStart.collectAsState()
    val goalCur by repo.goalHours.collectAsState()
    val base by repo.baseGoal.collectAsState()
    val same by repo.samePlan.collectAsState()
    val plans by repo.plans.collectAsState()
    val program by repo.program.collectAsState()
    val fasts by repo.fasts.collectAsState()
    val rem by repo.reminders.collectAsState()

    val now = System.currentTimeMillis()
    val planToday = planGoalFor(now, base, same, plans, program)
    val current = if (start > 0L) goalCur else planToday
    val prog = program
    val progActive = prog != null && !prog.paused

    var editHours by remember { mutableStateOf<Int?>(null) }
    var builder by remember { mutableStateOf<CustomPlan?>(null) }
    var building by remember { mutableStateOf(false) }
    var actions by remember { mutableStateOf<CustomPlan?>(null) }
    var safety by remember { mutableStateOf<Int?>(null) }
    var startProg by remember { mutableStateOf<Program?>(null) }

    fun choose(g: Int) {
        if (g >= 24 && g != current && rem.safetyCheck) {
            safety = g
        } else {
            repo.setGoalHours(g)
            onBack()
        }
    }

    // where the day clock starts: the planned start of the next fast
    val lastEnd = fasts.maxOfOrNull { it.end } ?: 0L
    val startMin = if (lastEnd > 0L && current in 1..23) {
        minOfDay(lastEnd + (24 - current) * HOUR_MS)
    } else {
        20 * 60
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 8.dp, bottom = 24.dp),
    ) {
        Box(Modifier.offset(x = (-12).dp)) { BackRow(onBack) }
        Sub("Pick how you fast")
        Text("Plans", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)

        // ---- current plan ----
        Spacer(Modifier.height(16.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Sub(if (start > 0L) "Current plan" else "Plan for today")
                        Text(
                            planLabel(current),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.outlineVariant)
                            .clickable { editHours = if (current <= 0) 16 else current },
                        contentAlignment = Alignment.Center,
                    ) { FIcon(R.drawable.ic_pencil, size = 18.dp) }
                }
                if (current > 0) {
                    Spacer(Modifier.height(12.dp))
                    val fastShare = if (current >= 24) 1f else current / 24f
                    Row(Modifier.fillMaxWidth().height(10.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Box(
                            Modifier
                                .weight(fastShare)
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(MaterialTheme.colorScheme.primary),
                        )
                        if (current < 24) {
                            Box(
                                Modifier
                                    .weight(1f - fastShare)
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(MaterialTheme.colorScheme.onSurface),
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Sub("Fast ${fmtMinOfDay(startMin)} – ${fmtMinOfDay(startMin + current * 60)}")
                        if (current < 24) {
                            Sub("Eat ${fmtMinOfDay(startMin + current * 60)} – ${fmtMinOfDay(startMin)}")
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Same plan every day", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Sub("Or set a different plan per weekday")
                    }
                    Switch(
                        checked = same,
                        onCheckedChange = { repo.setSamePlan(it) },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                    )
                }
                if (!same && plans.isEmpty()) {
                    Sub("Build a plan below and pick its days. Days without a plan use your base plan.", Modifier.padding(top = 6.dp))
                }
                if (progActive) {
                    Sub("A program is running and sets today's plan.", Modifier.padding(top = 6.dp))
                }
            }
        }

        // ---- flexi ----
        Spacer(Modifier.height(12.dp))
        SoftCard(Modifier.fillMaxWidth().clickable { choose(0) }) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                IconCircle(R.drawable.ic_flexi, size = 24.dp)
                Column(Modifier.weight(1f)) {
                    Text("Flexi", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Sub("Fast as long as you want", size = 13)
                }
                FIcon(R.drawable.ic_chev_right, size = 18.dp, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // ---- my plans ----
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("My plans", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            TextButton(onClick = { building = true }) {
                Text("Build a plan", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
        if (plans.isEmpty()) {
            Sub("Plans you build show up here, for example 16 : 8 on workdays and 14 : 10 at the weekend.", size = 13)
        }
        for (pair in plans.chunked(2)) {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (p in pair) {
                    SoftCard(Modifier.weight(1f).clickable { actions = p }) {
                        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                            Text(p.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Sub(daysText(p.days) + " · " + eatText(p), Modifier.padding(top = 2.dp))
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        // ---- programs ----
        Spacer(Modifier.height(22.dp))
        Text("Programs", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (def in programs) {
                val active = prog != null && prog.id == def.id
                val shape = RoundedCornerShape(16.dp)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .then(if (active) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, shape) else Modifier)
                        .clickable { if (active) onProgram() else startProg = def }
                        .padding(14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        IconCircle(programIcon(def.id), box = 40.dp, size = 20.dp)
                        Column(Modifier.weight(1f)) {
                            Text(def.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Sub(def.range)
                        }
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                        ) {
                            Text(
                                if (active && prog!!.paused) "Paused" else if (active) "In progress" else def.level,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                    if (active) {
                        val day = (programDay(prog!!, now) + 1).coerceIn(1, def.days)
                        Spacer(Modifier.height(12.dp))
                        Bar(day.toFloat() / def.days, MaterialTheme.colorScheme.primary)
                        Sub("Day $day of ${def.days}", Modifier.padding(top = 6.dp))
                    }
                }
            }
        }

        // ---- plan groups ----
        for ((gi, group) in planGroups.withIndex()) {
            Spacer(Modifier.height(if (gi == 0) 24.dp else 20.dp))
            Text(group.first, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            if (gi < 2) {
                for (pair in group.second.chunked(2)) {
                    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        for (g in pair) {
                            PlanTile(g, g == current, Modifier.weight(1f)) { choose(g) }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (g in group.second) {
                        val on = g == current
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .then(if (on) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(50)) else Modifier)
                                .clickable { choose(g) }
                                .padding(horizontal = 18.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(planLabel(g), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            if (g == 23) Sub("OMAD", size = 11)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                FIcon(R.drawable.ic_warn, size = 22.dp, tint = TrackAmber)
                Text(
                    "Fasts of 24 hours or more ask for a quick safety check before you start, and a break-the-fast guide when you finish.",
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    }

    // ---- dialogs ----
    val eh = editHours
    if (eh != null) {
        AlertDialog(
            onDismissRequest = { editHours = null },
            title = { Text("Fast length") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        RepeatStepButton("−") { editHours = (eh - 1).coerceAtLeast(1) }
                        Text("${eh}h", fontSize = 34.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.width(96.dp))
                        RepeatStepButton("+") { editHours = (eh + 1).coerceAtMost(72) }
                    }
                    Sub(planDetail(eh), Modifier.padding(top = 8.dp), size = 13)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    editHours = null
                    choose(eh)
                }) { Text("Set plan") }
            },
            dismissButton = { TextButton(onClick = { editHours = null }) { Text("Cancel") } },
        )
    }

    val sg = safety
    if (sg != null) {
        AlertDialog(
            onDismissRequest = { safety = null },
            title = { Text("Before a ${sg}h fast") },
            text = {
                Text(
                    "Long fasts are not for everyone. Talk to a doctor first if you take medicine, have diabetes, " +
                        "are pregnant or have had an eating disorder. Keep up water and salts, stop if you feel unwell, " +
                        "and break the fast gently with a small, light meal."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    safety = null
                    repo.setGoalHours(sg)
                    onBack()
                }) { Text("I understand") }
            },
            dismissButton = { TextButton(onClick = { safety = null }) { Text("Cancel") } },
        )
    }

    val act = actions
    if (act != null) {
        AlertDialog(
            onDismissRequest = { actions = null },
            title = { Text(act.name) },
            text = { Text(daysText(act.days) + " · " + eatText(act)) },
            confirmButton = {
                TextButton(onClick = {
                    actions = null
                    choose(act.fastHours)
                }) { Text("Use now") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        repo.deletePlan(act.id)
                        actions = null
                    }) { Text("Delete") }
                    TextButton(onClick = {
                        builder = act
                        actions = null
                    }) { Text("Edit") }
                }
            },
        )
    }

    if (building || builder != null) {
        PlanBuilder(
            initial = builder,
            onSave = {
                repo.savePlan(it)
                building = false
                builder = null
            },
            onDismiss = {
                building = false
                builder = null
            },
        )
    }

    val sp = startProg
    if (sp != null) {
        AlertDialog(
            onDismissRequest = { startProg = null },
            title = { Text("Start ${sp.name}?") },
            text = {
                Text(
                    sp.blurb + if (prog != null) " This replaces your current program." else ""
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    startProg = null
                    repo.startProgram(sp.id)
                    onProgram()
                }) { Text("Start today") }
            },
            dismissButton = { TextButton(onClick = { startProg = null }) { Text("Not now") } },
        )
    }
}

@Composable
private fun PlanTile(goal: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .then(if (selected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(planLabel(goal), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            if (selected) Text("Selected", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
        Sub(planDetail(goal))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(4.dp)) {
            Box(Modifier.weight(goal / 24f).height(4.dp).background(MaterialTheme.colorScheme.onSurface))
            Box(Modifier.weight(1f - goal / 24f).height(4.dp).background(MaterialTheme.colorScheme.outline))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlanBuilder(initial: CustomPlan?, onSave: (CustomPlan) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var fast by remember { mutableStateOf(initial?.fastHours ?: 16) }
    var eat by remember { mutableStateOf(initial?.eatStartMin ?: 12 * 60) }
    var days by remember { mutableStateOf(initial?.days ?: 31) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Build a plan" else "Edit plan") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = { Text("Name, e.g. Workdays") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Sub("Fast")
                        Text(planLabel(fast), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        RepeatStepButton("−") { fast = (fast - 1).coerceAtLeast(1) }
                        RepeatStepButton("+") { fast = (fast + 1).coerceAtMost(72) }
                    }
                }
                if (fast < 24) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Sub("Eating starts")
                            Text(
                                fmtMinOfDay(eat) + " – " + fmtMinOfDay(eat + (24 - fast) * 60),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            RepeatStepButton("−") { eat = (eat - 30 + 1440) % 1440 }
                            RepeatStepButton("+") { eat = (eat + 30) % 1440 }
                        }
                    }
                }
                Sub("Days")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in 0..6) {
                        val on = (days and (1 shl i)) != 0
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                                .clickable { days = days xor (1 shl i) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                dayLetters[i],
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = days != 0,
                onClick = {
                    val n = name.trim().ifEmpty { planLabel(fast).replace(" ", "") }
                    onSave(CustomPlan(initial?.id ?: System.currentTimeMillis(), n, fast, eat, days))
                },
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
